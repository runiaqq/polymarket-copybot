# CURSOR.md — PolyMind AI (Polymarket Copy-Trading SaaS)

> **Read this file fully before writing any code.** It is the single source of truth for
> architecture, current state, and **mandatory** safety rules. This system moves **real user
> money** on-chain. A wrong edit can drain a subscriber's deposit. When unsure, STOP and ask —
> do not guess or hallucinate APIs, contract addresses, or DB columns.

Product aliases seen in code: **PolyMind AI** (product name), `PolyMind` (user-facing bot copy),
`Polymarket CopyBot` (FastAPI title). They are the same project.

---

## 1. Project Overview

PolyMind AI is a **commercial subscription (SaaS) copy-trading bot for [Polymarket](https://polymarket.com)**,
operated entirely through **Telegram**.

**What it does, end to end:**
1. A curated whitelist of proven profitable wallets ("master accounts" / "whales") is stored in
   the `tracked_wallets` table.
2. A background worker **polls each tracked wallet's recent on-chain trades** every ~15 seconds.
3. When a tracked wallet makes a fresh **BUY** on a fast-resolving market, the bot generates a
   **signal** and **mirrors that trade onto every active paying subscriber's wallet** with real
   funds, via the Polymarket CLOB V2.
4. Positions are **held to resolution** (binary markets pay $1 or $0). On resolution, winnings are
   **auto-redeemed** on-chain and converted back to tradeable collateral (pUSD).
5. Subscribers pay for access; subscription state gates whether their account is copied.

**Custodial model:** the bot **generates and holds each user's wallet private key** (encrypted).
This is the highest-risk part of the system — see §5.

**Business model:** single subscription tier, time-based expiry, activated by an admin or a
one-time access code.

---

## 2. Current Architecture & Modules

### 2.1 Process topology

Four processes (see `docker-compose.yml`):

| Process | Entrypoint | Role |
|---|---|---|
| **api** | `api/main.py` (uvicorn) | Telegram bots (user + admin), health, webhook/polling |
| **worker** | `worker/entrypoint.py` | Celery worker, **gevent** pool, concurrency 100, queues `trades,ai,periodic` |
| **beat** | `worker/beat.py` | Celery beat scheduler — **MUST be exactly ONE replica** (gevent pool cannot embed `--beat`) |
| **redis** | redis:7 | Celery broker/backend + cross-process dedup guards |

**Data store:** Supabase (Postgres) accessed at runtime via the **supabase client** (`core/db/queries.py`).
`core/db/models.py` (SQLAlchemy) is **schema reference only** — not used at runtime. Schema changes are
manual SQL in `migrations/*.sql` (applied by hand in the Supabase SQL editor).

**Deploy targets:** self-hosted `docker-compose` on a VPS in a **non-geoblocked region** (Polymarket
geoblocks some countries; trading must run where it's allowed). `fly.toml`/`railway.toml` exist for
split hosting but compose is the primary path.

### 2.2 Copy-trading flow (Model B — the PRIMARY strategy)

```
beat → poll_tracked_wallets (every tracked_poll_sec = 15s)
        │  for each tracked wallet:
        │    fetch_donor_recent_trades(addr)            # Polymarket Data API /activity
        │    aggregate sliced BUY fills per (market, outcome)   # one entry = many tiny fills
        │    filters: side==BUY, age < tracked_max_trade_age_sec (2h),
        │             aggregate size >= tracked_min_copy_usdc ($50),
        │             market in get_fast_markets() (resolves within window & liquid),
        │             dedup (in-memory _seen + DB trade_signals lookup, reentry 12h)
        │    insert trade_signals row, compute consensus count
        └──> for EACH active subscriber: execute_copy_trade.delay(uid, signal)   # queue=trades

execute_copy_trade(user_id, signal):                     # worker/tasks/execute_copy.py
    load user; require deposit_wallet_address
    only BUY (SELL/NO skipped — we don't hold the token to sell)
    compute size (see §2.3)
    balance check: ensure deposit wallet has enough pUSD (sweep EOA→DW on demand)
    portfolio guards: skip if already in this market (send consensus boost instead),
                      skip if open positions >= max_open_positions (15)
    ensure CLOB API creds (generate + persist if missing)
    re-check order book (price in band, depth cap)
    insert copy_trades row (idempotency guard against Celery retries)
    place_order(...)  → CLOB V2 marketable FAK BUY, slippage-protected
    confirm fill from on-chain positions; notify user (trade + AI + remaining balance)
```

`scan_markets.py` (global REST whale scanner), `ws_listener.py`/`signals.py` (real-time WS whale
detector), and `poll_donors.py` (donor wallets) are **Model A / legacy**. They are **not on the beat
schedule** and are effectively dormant. Do not extend them without explicit instruction.

### 2.3 Copy sizing — IMPORTANT: FIXED CAP, **not** proportional

The bot does **NOT** size proportionally to the whale's stake. Sizing is a **fixed per-user cap,
then clamped down by liquidity**:

1. Start at `user.max_position_usdc` (default **$25** per position).
2. Clamp by the signal's depth-derived cap (`max_copy_usdc`) if present.
3. Clamp by order-book depth: `book_safe_frac` (**0.25**) of the fillable ask depth within the
   slippage band (`order_slippage_pct` = 2%).
4. Require `>= $1.0`, else skip.

The whale's size is only a **trigger + conviction floor** (`tracked_min_copy_usdc` = $50 aggregate),
**not** a multiplier. `copy_scale` exists in config (default 1.0) but proportional sizing is not the
active model. If you implement proportional sizing, treat it as a **new feature**, gate it behind a
config flag, and never let it bypass the depth/balance caps.

### 2.4 On-chain trading path (Polymarket V2)

- Each user has a generated **EOA** (`users.wallet_address`, key encrypted in `wallet_private_key_enc`).
- Each user trades through a deterministic **deposit wallet** (`users.deposit_wallet_address`) — an
  ERC-1967 proxy owned by the EOA, deployed gaslessly via the **relayer/Builder** (`core/relayer.py`).
- Collateral is **pUSD** (`0xC011a7E12a19f7B1f670d46F03B03f3342E82DFB`). Deposits arrive as USDC/USDC.e
  and are converted (`core/polygon.py`: swap → wrap → sweep into the deposit wallet).
- Orders are signed **POLY_1271** with the deposit wallet as `funder` (`core/clob.py`). Plain EOA
  makers are rejected by V2.
- Contract addresses live in `core/clob.py` (`CTF_EXCHANGE`, `NEG_RISK_CTF_EXCHANGE`,
  `NEG_RISK_ADAPTER`, `CONDITIONAL_TOKENS`, `PUSD_ADDRESS`). **Never hardcode new addresses elsewhere —
  import from `core/clob.py`.**

### 2.5 Exits, resolution & redemption (`worker/tasks/manage_positions.py`)

- Strategy = **hold to resolution**. Percentage TP/SL are disabled.
- Single early exit: **hard stop** when the market prices the held outcome below
  `hard_stop_abs_price` (0.07) and we're not within `tp_sl_min_hours` of resolution.
- `sync_positions` (beat, every 120s) detects resolved positions and:
  - sends win/loss notifications,
  - if won + `auto_redeem_enabled`, dispatches `redeem_position` (queue `trades`).
- `redeem_winnings` (`core/relayer.py`) **auto-detects** market type on-chain (matches the held
  token's `positionId` against candidate collaterals): WrappedCollateral → neg-risk
  (`NegRiskAdapter.redeemPositions`), pUSD/USDC.e/USDC → binary (`ConditionalTokens.redeemPositions`).
  **Do NOT trust the `negativeRisk` flag from the Data API — it is often null/missing.**
- Redeemed funds arrive as **USDC.e**, then `convert_dw_usdce_to_pusd` wraps them to pUSD so they're
  tradeable again. Both steps run gaslessly through the relayer batch.

### 2.6 Whitelist discovery (`core/wallet_discovery.py`)

`discover_quality()` builds/cleans the `tracked_wallets` whitelist from Polymarket leaderboards and
filters out market makers / arbitrageurs / gamblers using:
- profit/volume ratio (`discovery_min_profit_volume_ratio` 0.15),
- trade density (`discovery_max_trades_per_day` 20),
- average trade size (`discovery_min_avg_trade_size` $300),
- **directionality score** D = |V_yes − V_no| / (V_yes + V_no), min 0.5,
- **scattershot/hedge** filter: max distinct markets per event (`discovery_max_event_outcomes` 3).

Triggered from the admin bot (`/refresh`, `/top`) and `scripts/seed_quality.py`.

### 2.7 Subscriptions & admin

- Single tier: `users.sub_tier = "active"` with `users.sub_expires_at`. Anyone non-`free` and
  unexpired is "active". `get_active_subscribers()` is the gate for copying.
- Activation: admin `/grant` or `/sub` (by `@username` or numeric id) → `set_subscription(days)`,
  or one-time **access codes** (`access_codes`, redeemed via deep-link). Expiry reminders run every 6h.
- Auth guard on admin commands: `is_admin(telegram_id)` — covers `settings.admin_telegram_id` (super-admin)
  plus any row in `admins` table (multi-admin, invited via one-time codes).
- Two Telegram bots: **user bot** (`api/routers/telegram.py`) and an optional **admin bot**
  (`api/routers/admin_bot.py`, separate token) for subscriptions + whitelist management.
- There is also a Bearer-auth REST admin API (`api/routers/admin.py`).

### 2.8 Key config flags (`core/config.py`)

- `auto_copy_enabled` — master switch for custodial auto-copy (must be ON only where Polymarket is
  not geoblocked). When OFF, beat schedule is empty.
- `use_polling` — Telegram polling vs webhook.
- `auto_redeem_enabled` — on-chain winnings redemption (default ON).
- `wallet_filter_mode` — `off | observe | enforce` for the buyer track-record filter (default `observe`).
- Strategy knobs: market window, dynamic large-buy detection, break-even guards, copy sizing,
  exits, Model-B polling, discovery thresholds, AI risk threshold.

### 2.9 Core module index

| Module | Responsibility |
|---|---|
| `core/config.py` | Pydantic settings from `.env` (all thresholds live here) |
| `core/wallet.py` | EOA generation + Fernet encrypt/decrypt of private keys |
| `core/clob.py` | CLOB V2 client, API creds, `place_order`/`sell_position`, contract addresses |
| `core/relayer.py` | Gasless deposit-wallet deploy/approve/transfer + `redeem_winnings` + USDC.e→pUSD wrap |
| `core/polygon.py` | Balances, transfers, swaps (Uniswap), wrap/unwrap (CollateralOnramp/Offramp) |
| `core/polymarket.py` | Data/Gamma API: fast markets, positions, closed positions, recent trades |
| `core/detector.py` | Pure whale-detection logic (depth/volume significance, break-even) |
| `core/leaderboard.py` | Profit/volume leaderboard fetch + cache |
| `core/wallet_discovery.py` | Quality-trader discovery + MM/arb/gambler filters |
| `core/wallet_score.py` | Score a buyer's track record (observe/enforce filter) |
| `core/cache.py` | Redis one-shot guards (`notify_once`, `claim`) + BP2 accumulator helpers |
| `core/sizing.py` | **[BP3]** Pure fractional Kelly sizing (`kelly_stake`) — no I/O |
| `core/risk.py` | **[BP4]** Pure tail-risk gate evaluator (`check_risk_gates`) — no I/O |
| `core/db/queries.py` | All runtime Supabase reads/writes |

---

## 3. Working Features (stable, running on real funds)

- Custodial wallet lifecycle: EOA generation, encrypted key storage, gasless deposit-wallet deploy +
  approvals, deposit detection, USDC/USDC.e → pUSD conversion and sweep into the deposit wallet.
- **Model B copy-trading**: poll tracked wallets → aggregate sliced fills → dedup → fast-market filter
  → fan-out to all subscribers → CLOB V2 FAK BUY with slippage + depth caps → fill confirmation →
  combined Telegram notification (trade + AI risk + remaining balance).
- Portfolio guards: per-market single-entry (with consensus boost), max open positions, balance checks.
- Position management: hold-to-resolution, hard-stop exit, resolution win/loss detection.
- **On-chain redemption**: auto-detecting binary vs neg-risk redeem, then USDC.e→pUSD wrap (gasless).
- Subscriptions: single tier, admin grant + access codes, expiry reminders, separate admin bot.
- Whitelist discovery with MM/arb/gambler filtering (ratio, density, size, directionality, scattershot).
- AI risk analysis per signal (OpenAI), informational by default (`ai_block_enabled=false`).
- Redis-backed dedup across restarts for notifications and settlements.
- **[BP1] Deterministic on-chain settlement reconciler** (`reconcile_settlements`, beat every 120s):
  reads `payoutDenominator`/`payoutNumerators` directly from the CTF contract, so neg-risk positions
  that disappear from the Data API are settled deterministically. Settlement fields
  (`condition_id`, `token_id`, `outcome_index`, `neg_risk`, `entry_price`, `shares`, `result`,
  `realized_pnl`, `resolved_at`, `redeemed_at`, `redeem_tx`) persisted on `copy_trades`
  (migration 008). `execute_copy_trade` denormalizes these at fill time.
- **[BP2] Redis accumulation tracker with quiet-period debounce**: replaces the in-memory `_seen`
  map with cross-process Redis buckets per `(wallet, cond, token)`. Signal fires once after the
  whale's slicing settles (`slice_quiet_period_sec=45s`) or hits the hard window cap
  (`slice_max_window_sec=180s`). VWAP of the full burst is used as signal price. Dynamic
  conviction threshold: `max(abs_floor, conviction_frac × whale_avg_size)`. Pre-fan-out balance
  gate skips users below `min_balance_usdc` with a throttled nudge; `_notify_low_balance` also
  throttled to ≤1 alert per `lowbal_alert_throttle_sec` (6h). Migration 009 adds
  `tracked_wallets.avg_trade_usdc`.
- **[BP3] Fractional Kelly position sizing** (`core/sizing.py`, `sizing_mode="kelly"`):
  Bayesian-shrunk winrate → bounded edge estimate (`edge_hat ≤ kelly_edge_cap=0.06`) → quarter-Kelly
  (`kelly_lambda=0.25`) → hard cap at `max_risk_per_trade=0.05` of equity. `sizing_mode="fixed"`
  reproduces the legacy flat-cap behaviour for instant rollback. Copying disabled below
  `min_balance_usdc=$100` to avoid dust trades eaten by fees.
- **[BP3.1] Soft minimum-balance + minimum-order fallback**: removed the hard `$100` block.
  Below `recommended_min_balance_usdc=$100` a throttled soft warning is sent and the bot trades
  at the exchange minimum (`exchange_min_order_usdc=$1`). Copying is only skipped when
  `free_pusd < $1` (cannot afford even the platform minimum). `_notify_trading_at_minimum`
  replaces the old hard `below_min_balance` skip.
- **[BP1-GAP] Backfill legacy redemptions** (`backfill_legacy_redemptions`, beat every 600s):
  recovers funds for positions opened before migration 008 (NULL ledger fields). Enumerates
  resolved-won holdings from the Data API and on-chain CTF contract, dispatches `redeem_position`
  for each. Self-healing USDC.e sweep also added to `monitor_deposits` (every 120s).
- **[BP4] Tail-risk portfolio controls** (`core/risk.py`): four pre-trade gates —
  aggregate exposure cap (60% of equity), per-event correlation cap (15% of equity), drawdown
  circuit breaker (25% drawdown from HWM → 24h pause), daily loss limit (10% of equity → pause
  to 00:00 UTC). `equity_hwm` and `copy_paused_until` stored on `users` (migration 010).
  `get_active_subscribers` honors `copy_paused_until`; `sync_positions` refreshes HWM each cycle.
- **[BP5] Correct time-to-resolution parsing** (`core/polymarket.py`): `resolution_dt()` selects
  the authoritative end datetime from market + event fields, prioritising `events[0].endDate`
  (the event boundary) over the per-market `endDate` which is often an understated placeholder.
  Date-only strings are treated as 23:59:59Z (end of day, never midnight). `format_time_left()`
  computes the human-readable countdown fresh at notification send time — never a cached scalar.
  `resolution_iso` is carried on the signal dict; all notification sites (`execute_copy._notify`,
  `ai_filter._call_gpt`, `ai_filter.run_ai_analysis`) call `format_time_left` at send time.
  Migration 012 is not required (signal is an in-memory dict).
- **[BP6] Position state machine & terminal P&L** (`worker/tasks/manage_positions.py`): `close_position`
  now books realized P&L from the actual sale proceeds (`shares_sold × best_bid − entry_cost`) and
  calls `mark_trade_closed` (sets `status='closed'`, `result='closed'`, `redeemed_at=now`), removing
  the row from `get_outstanding_copy_trades` permanently. Defense-in-depth guards added to
  `reconcile_settlements` and `backfill_legacy_redemptions`: terminal-state check
  (`has_terminal_trade`) and on-chain dust check (`ctf_token_balance / 1e6 < claim_dust_min_shares`)
  block phantom re-claims. `redeem_position` applies the same guards plus hydrates the market
  title from `trade_signals` when called from the on-chain reconciler path. `_resolve_user_for_notification`
  hydrates the title from the ledger. New helpers: `get_open_trade_by_token`, `mark_trade_closed`,
  `has_terminal_trade` in `core/db/queries.py`. Migration 012 (`exit_tx` column +
  `(user_id, condition_id)` index) applied (see §6.9).
- **[BP7] Small-balance silent-skip fix: exposure-cap clamping + sizing-mode-aware messaging**
  (`core/risk.py`, `worker/tasks/execute_copy.py`, `worker/celery_app.py`): Eliminated the prod
  silent-skip where BP4's Gate 1 (`exposure_cap`) hard-blocked every trade for sub-$100 balances.
  Gates 1 & 2 (`RiskDecision`) now carry `max_stake` and `warn` fields and clamp instead of blocking:
  if headroom ≥ exchange_min → clamp stake to headroom; if headroom < exchange_min and
  equity < recommended → enter at the platform minimum (`exchange_min_order_usdc`) with
  `warn="concentration_over_60"`; if equity ≥ $100 → still block (funded but fully deployed).
  The concentration warning is appended inline to the existing trade success notification — no
  separate spam message. Soft-limit "$100" warning (`_notify_trading_at_minimum`) is now
  mode-aware: fires only in `kelly` mode (rationale holds for Kelly; in `fixed` mode the user
  set their own size → stay silent). `result_expires=3600` added to Celery to prevent
  `celery-task-meta-*` key explosion in Redis. No new migration required.

- **[BP9] Release-integrity: fail-loud architecture + money-safety win invariant**:
  global PTB error handler on both bots (`add_error_handler`) converts silent dead buttons
  into logged + user-visible fallbacks; boot self-check (`_check_core_imports`) fails the
  container immediately if `core.db` exports are missing; Celery `task_failure` signal
  escalates crashed periodic tasks; `_emit_win_pending` + `_emit_win_retry_failed` replace
  false-success notifications — "✅ Выигрыш зачислен" is only ever sent after the
  `redeemPositions` + `convert_dw_usdce_to_pusd` batch confirms on-chain.

- **[BP14] Signal-Only Mode + Subscription Enforcer** (migration **014**):
  **(A) Signal-Only Mode** — per-user `users.is_signal_only` flag. When `true`,
  `execute_copy_trade` short-circuits **before any wallet/balance/risk/CLOB path**
  and sends a rich manual-trade brief via `_notify_signal_only` (event title,
  concrete outcome, live order-book price + implied probability, whale size /
  fills / consensus, market link) — **zero on-chain / Web3 calls**. The flag gates
  **ENTRY only**: open positions are still synced, exited on TP/SL and redeemed by
  `sync_positions` (which must never skip `is_signal_only` users). `get_active_subscribers`
  includes signal-only users in auto-copy mode regardless of `copy_active`/`wallet_address`,
  and `poll_tracked_wallets` fans signals out to them bypassing the balance gate.
  Toggle UI lives in `/settings` (🤖 Копитрейдинг / 🔔 Только сигналы → `mode_copy`/`mode_signal`).
  **(B) Subscription Enforcer** — `_subscription_guard(user)` in `execute_copy.py` checks
  `is_subscription_active(user)` before copying **or** signalling; expired users are skipped
  and alerted **exactly once** via the DB-backed `users.subscription_notified_expired` flag
  (no per-trade spam). The flag auto-resets to `false` whenever an active subscription is
  observed and on renewal (`set_subscription`). `check_subscription_expiry` shares the same
  flag for its "just expired" branch so the cron and the guard never double-notify.
  New `core/db/queries.py` helpers (re-exported from `core/db/__init__.py`):
  `is_subscription_active`, `set_subscription_notified_expired`, `set_signal_only`.
  **This release replaces a temporary hardcoded signal-only hack (single client by
  Telegram ID) with the production flag-driven feature.** Migration 014 must be applied
  to the live DB before deploying this code.

- **[BP12] Close-handler import fix + withdrawal balance fix & FSM redesign**:
  **(A)** `get_open_trade_by_token` re-exported from `core/db/__init__.py`; boot self-checks
  in `api/main.py` and `worker/celery_app.py` extended with an explicit required-name set so
  the drift regression class fails loud at container start, not at runtime on the money path.
  **(B)** `withdrawable_usdc(db_user)` added to `core/polygon.py` — single source of truth
  (deposit-wallet pUSD + EOA pusd/usdc_e/usdc); `transfer_usdc` now waits for the on-chain
  receipt; `withdraw_funds` task rewritten as fail-loud: pre-flight balance gate, POL gas
  check, per-leg error propagation (no swallowing), Polygonscan link on success. Withdrawal
  FSM in `telegram.py`: stale-state reset on re-entry, real "Доступно" balance from
  `withdrawable_usdc`, pre-flight amount validation, confirm step kept. `min_withdraw_usdc`
  config constant added. No new migration required.

- **[BP17] Spread-Trap stop-loss hardening + Broken-Override state reset** (2026-07-02):
  **(A — Spread Trap)** Four-layer Delta-Drop hardening in `manage_positions.py`: Layer 1 —
  drop computed from mid `(bid+ask)/2` instead of raw best_bid; Layer 2 — spread veto skips
  the stop when `(ask-bid)/mid > max_spread_for_stop_pct (0.08)`, logging
  `stop_skipped_wide_spread`; Layer 3 — optional bid-vs-bid comparison using `entry_bid`
  persisted at fill time; Layer 4 — persistence debounce requires `delta_drop_confirm_ticks
  (2)` consecutive breaching polls, logging `delta_drop_confirming` on unconfirmed ticks.
  Hold-time anchor moved from in-process `_first_seen` dict to `copy_trades.created_at`
  (survives worker restarts); `delta_drop_min_hold_sec` raised 600 → 900 s. Five new config
  knobs in `core/config.py`. Migration `016_entry_bid.sql` adds `copy_trades.entry_bid`.
  **(B — Broken Override)** `risk_override_until timestamptz` added to `users`
  (migration 016). `unlock_drawdown` handler now sets this flag to next 00:00 UTC via
  `set_risk_override_until`. The `_update_hwm_and_check_breakers` monitor returns immediately
  while the flag is active, suppressing both the drawdown and daily-loss breakers. The
  `execute_copy` pre-trade path passes `daily_pnl=0` to `check_risk_gates` while the override
  is active, so gate 4 does not block new entries. Confirmation message updated to state
  "принято до 00:00 UTC". Two new DB helpers (`get_risk_override_until`,
  `set_risk_override_until`) exported from `core/db`.

- **[BP19] Global Stop-Loss Invariant — DB-first effective-entry resolver** (2026-07-03):
  Closed the **Stop-Loss Leak**: `sync_positions` previously read cost basis exclusively from
  the Data-API `avg_price` which is `0` for POLY_1271 proxy wallets (indexing lag), causing
  the `entry_px > 0` Delta-Drop guard to silently skip every poll — positions rode to
  resolution without being stopped. **5-tier fallback chain** implemented in
  `worker/tasks/manage_positions.py` (`_db_entry_prices` fetched once per user per cycle via
  `get_entry_prices_by_token`):
  **Tier 1** — `copy_trades.entry_price` (DB, our true fill cost — preferred for risk path);
  **Tier 2** — Data-API `avg_price` (only when Tier 1 is 0/NULL);
  **Tier 3** — `size_usdc / shares` (ledger-derived, when both are present);
  **Tier 4** — `trade_signals.price` (VWAP entry from the originating signal, via new
  `get_signal_price` helper in `core/db/queries.py`);
  **Tier 5** — hard floor `0.01` + `log.error("stop_no_cost_basis", …)` — a skipped stop
  is **never silent again**.
  `position_mark` log ungated (now fires for every position regardless of API avg) and
  extended with `entry_source` field showing which tier resolved the value.
  Fix 3 (defence-in-depth): `stop_mid_floor_enabled` fires `hard_stop` when `mid <
  hard_stop_abs_price` even before `best_bid` reaches the floor; hollow-book positions
  (`best_bid == 0`) emit `stop_unsellable_hollow_book` (throttled via `notify_once`) for ops
  visibility. Three new config knobs added to `core/config.py`:
  `stop_use_db_entry` (default `True`), `stop_mid_floor_enabled` (default `True`),
  `stop_no_cost_basis_alert` (default `True`). No DB migration required — `entry_price`,
  `size_usdc`, `shares`, `signal_id` already exist (migration 008).

- **[BP20] Redeem-Hang Self-Healing + Win-Notification UX** (2026-07-03):
  Fixed four prod defects; **20.A is money-critical** (real winnings were stuck on-chain
  for up to 7 days due to a stale Redis dedup key, never self-healing):
  **A1 — Short lease TTL**: `once:redeem:{uid}:{cond}` now uses `redeem_lease_sec=900 s`
  (15 min) instead of the 7-day default. The key is also **cleared** (`clear_once`) in
  `redeem_position` failure/skip paths and inside `reconcile_settlements` A3 so the
  reconciler re-attempts on the next cycle instead of waiting a week.
  **A2 — trade_id always passed**: `sync_positions` now calls `get_open_trade_by_condition`
  before dispatching `redeem_position` to pass the real `trade_id` + `entry_cost` (via the
  BP19 5-tier resolver). The `mark_trade_settled` ledger update that was silently skipped
  for the `sync_positions` redeem path now runs on every successful on-chain redeem.
  **A3 — ledger-desync drain**: `reconcile_settlements` detects `won && shares_on_chain==0`
  (tokens already redeemed on-chain, ledger never settled) and calls `mark_trade_settled`
  directly without dispatching a second redeem, clearing the stale key and notifying the user.
  **A4 — loud logs**: every silent `continue` in the redeem/reconcile win branch is replaced
  with throttled `reconcile_redeem_blocked` / `redeem_skipped_reason` / `reconcile_user_not_found`
  log lines so a stuck claim is visible within minutes.
  **B — Outcome fallback**: centralized `resolve_outcome_name(outcome, outcome_index,
  condition_id, signal_id)` in `core/polymarket.py` with 5-tier chain (API → signal DB →
  Gamma outcomes[idx] → Gamma groupItemTitle → Yes/No); applied in all `_emit_*` notifiers
  and `redeem_position`.
  **C — Word-boundary truncation**: `smart_truncate(text, limit=50)` in `core/polymarket.py`
  replaces all scattered `[:N]` hard-slices on title strings throughout notifications.
  **D — Net PnL**: "Выигрыш зачислен" now shows `🏆 Net PnL: +$X.XX$ (выплата − вход)` using
  the BP19 cost-basis; renders `—` when `entry_cost` is unknown (legacy rows).
  New helpers: `clear_once` in `core/cache.py`; `get_open_trade_by_condition` in
  `core/db/queries.py`; `redeem_lease_sec=900` in `core/config.py`. No new DB migration.

- **[BP21] The Great Leak Plug & Risk Revamp** (2026-07-06): closes the three
  stop-loss leaks proven on prod for @sto1ner (id 891787021) and decouples position
  monitoring from the risk pause. **Root-cause context:** BP19 correctly wired the
  DB-first cost basis (`entry_source=db` on every mark), so the stop *ran* — but it
  still leaked money through three holes in `worker/tasks/manage_positions.py`.
  **(A) Stop-net — 3 leaks plugged:**
  **A1 — Phantom resolved-book guard (Fix 1):** a market whose `end_date` has passed
  (`hours < 0`) can keep returning a stale one-sided CLOB book (`best_ask==0`,
  `best_bid≈0.999`) for hours after it actually resolved. The stop math read that as
  "position up +30..150%" and silently disarmed — this is what let `80327923422237`
  (−$5.21) and `80084323272370` (−$4.94) ride to a $0 loss. Now, when
  `phantom_book_guard_enabled` and `hours<0` and `best_ask==0` and
  `best_bid >= phantom_book_bid_min` (0.90), the stop is skipped for that garbage price
  (`stop_skipped_phantom_book`, throttled) and the position is left to the
  redeemable/`reconcile_settlements` settlement path.
  **A2 — Hard-stop before spread-veto (Fix 2):** the catastrophic `hard_stop` floor
  block was moved to run **before** the Layer-2 spread veto and now `continue`s on fire.
  Previously a book collapsing to `best_bid=0.001` was vetoed by the wide-spread guard
  and never hard-stopped (`66649395439683`, −$4.92). The floor now pierces every spread
  protection.
  **A3 — Smart spread-veto bypass (Fix 3):** the veto no longer blocks emergency exits
  on a real collapse. When `drop_pct >= spread_veto_bypass_drop_mult (2.0) ×
  delta_drop_stop_pct` **or** `mid < hard_stop_abs_price`, the wide spread is ignored and
  the stop proceeds (`spread_veto_bypassed`). Rationale: on a genuine crash the spread
  widens precisely when we must sell.
  **A4 — Confirm-tick persistence (Fix 4):** a spread-vetoed poll no longer pops
  `_drop_ticks`. Before, an illiquid fast crash could never accumulate the two
  consecutive breaching ticks it needed because each intervening veto reset the counter
  (`11482573122404`, −$6.61). Non-breaching (recovered) polls still reset it.
  **(B) Monitoring decoupled from pause:** new `get_users_for_monitoring()` in
  `core/db/queries.py` returns every paying, unexpired subscriber with a deposit wallet,
  **without** the `copy_paused_until` / `copy_active` filters. `sync_positions` now uses
  it so a drawdown/daily-loss pause (`paused_drawdown`/`paused_daily_loss`) blocks
  **only new entries** — open positions of a paused user are still stop-lossed and their
  wins still redeemed. New entries stay blocked because both `get_active_subscribers`
  (fan-out gate) and `execute_copy_trade` (L124-140 belt-and-suspenders pause check)
  are unchanged; `get_active_subscribers` was deliberately **not** loosened, to avoid
  resurfacing new trades/signals to paused users through the shared fan-out path.
  Three new config knobs in `core/config.py`: `phantom_book_guard_enabled` (True),
  `phantom_book_bid_min` (0.90), `spread_veto_bypass_drop_mult` (2.0). New helper
  `get_users_for_monitoring` re-exported from `core/db/__init__.py` (import block **and**
  `__all__`, per the BP12-A drift guard). **No DB migration required** — read-path rewire
  only. The −EV entry root-cause (single-whale consensus on high-priced fast-resolving
  favorites) is intentionally **out of scope** for this release (no market/price/consensus
  filter yet).

---

## 4. Known Bugs & Missing Features

This section contains **implementation blueprints**. Each is precise enough to implement directly.
Treat every formula and contract call as authoritative; do not substitute your own. All money-moving
code MUST follow §5 (idempotency, fail-closed, key safety).

**Conventions used below**
- `equity(user)` = pUSD in the deposit wallet **+** value of open positions. For **display/info**, value
  positions at mark (`get_balances(dw).pusd + Σ position.current_value`). For the **drawdown breaker, HWM,
  and exposure gates**, value open positions at **cost basis** (filled entry cost), not at the depressed
  mark — see **Blueprint 8** (`drawdown_equity_mode="cost_basis"`). Marking open, un-resolved positions to
  the live bid fabricated a phantom drawdown in live tests. Use **free pUSD only** where a cash balance is
  required (placing a new order). Never count unredeemed/illiquid tokens as free cash.
- `p` = entry price of a YES/NO share (0–1). `q` = estimated true win probability.
- All new tunables live in `core/config.py`; all new columns in a new `migrations/00X_*.sql` + a helper
  in `core/db/queries.py`. Never hardcode magic numbers in task logic.

---

> **Blueprints 1–6 have been implemented** (see §3 Working Features for details).
> Migrations 008–012 are defined below and must be applied manually in the Supabase SQL editor.
> Migration 012 (exit_tx + user/condition index) must be applied to the live DB before deploying
> this code (see §6.9 / §7.4).
>
> ✅ **Blueprint 7 is IMPLEMENTED** — fixes the prod silent-skip where Blueprint 4's
> exposure cap hard-blocked every trade on small balances. Gates 1 & 2 now clamp.
> No new migration required.
>
> ✅ **Blueprint 8 is IMPLEMENTED** — fixes the live-test
> **phantom drawdown** (cost-basis equity replaces mark-to-market on open positions),
> the **block-alert spam** (compare-and-set state machine, notify only on transition),
> the **mode-asymmetric per-trade risk cap** (unified cap applies in both fixed and Kelly),
> and adds a **manual "🔓 Снять блокировку" inline button** with consent audit trail.
> **Migration 013 applied** (`risk_state`, `risk_override_at`, `risk_override_count`,
> `realized_baseline` columns on `users`).
>
> ✅ **Blueprint 9 is IMPLEMENTED** — three-layer fix for the live-test prod failures
> caused by **release drift**: **(Layer 1)** working-tree untracked files committed and
> deployed (no `settings` shadow in `callback_handler`, `has_terminal_trade` exported
> from `core.db`); **(Layer 2)** fail-loud architecture: global PTB `add_error_handler`
> on both bots, boot self-check `_check_core_imports()` in api+worker, `task_failure`
> Celery signal escalating crashed periodic tasks; **(Layer 3)** money-safety invariant:
> `_emit_win_pending` replaces false-success `_emit_win` at resolution detection in all
> three paths (`sync_positions` redeemable branch, closed-positions branch,
> `reconcile_settlements`), final "✅ Выигрыш зачислен" fires only from `redeem_position`
> after on-chain tx + pUSD balance change confirmed, retry-exhausted sends
> `_emit_win_retry_failed`. No new migration required.
>
> 🟢 **Blueprint 10 is IMPLEMENTED** — RCA of the 2026-06-30 prod incident
> where one losing outcome erased the profit of multiple wins by riding to $0 with **no stop-loss
> sell ever attempted** (`close_position` never invoked, ledger `exit_tx=0`; monitoring loop was
> healthy the whole night). The only exit was a dead-deep `hard_stop_abs_price=0.07` floor,
> disabled in the final `tp_sl_min_hours` and blind to neg-risk tokens that delist from the Data
> API. **Product decision: ship a simple "Delta-Drop" stop, not heavy quant.** Approved params:
> relative **X = 0.30** (exit when `best_bid ≤ entry×0.70`, caps loss ≈30% of stake — a relative
> stop fixes dollar risk at `X·size` regardless of entry); **`min_entry_price` raised 0.05 → 0.40**
> (don't enter dead-zone outcomes where the book is empty); `hard_stop 0.07` kept as floor; one
> `position_mark` log line/cycle for future data-driven tuning of X. Implementation = Delta-Drop
> check in `sync_positions` on the **live CLOB best_bid** + reuse of existing `close_position` for
> the on-chain sell. **X could NOT be fitted to history** — the P&L ledger is corrupt (see
> Blueprint 11) and the intra-trade price path is not stored; only `entry_price` is reliable.
>
> 🟢 **Blueprint 11 is IMPLEMENTED** — P&L booking bug surfaced during BP10
> data-mining: `copy_trades.realized_pnl` is computed from a fragile wallet **balance-delta**
> (`credited = bal_after − bal_before`), so on-chain-confirmed **wins are booked as −100%** (e.g.
> id 695: real `redeem_tx`, `realized_pnl=-4.88`) or left NULL, while losses book correctly. The
> ledger shows a false net-negative and **feeds phantom losses to the Blueprint 4/8 circuit
> breakers**. Fix: source `realized_pnl` from actual redeemed proceeds / `sell_position` fill, not
> a balance delta.
>
> ✅ **Blueprint 12 is IMPLEMENTED** — two prod operational failures reported 2026-06-30.
> **(Bug A — close crash)** `get_open_trade_by_token` added to `core/db/__init__.py` imports and
> `__all__`; boot self-checks in `api/main.py` and `worker/celery_app.py` extended with explicit
> required-name sets so this class of regression fails loud at container start.
> **(Bug B — broken withdrawal + UX redesign)** `withdrawable_usdc(db_user)` helper added to
> `core/polygon.py` as single source of truth (deposit-wallet pUSD + EOA pusd/usdc_e/usdc);
> `transfer_usdc` now waits for the on-chain receipt before returning; `withdraw_funds` task
> (fail-loud): pre-flight balance gate, POL gas check, per-leg error propagation (no silent
> swallow), on-chain receipt confirmed before "✅ Вывод успешно завершён + Polygonscan" notify;
> withdrawal FSM in `telegram.py` uses `withdrawable_usdc` for the "Доступно" display and
> pre-flight amount validation, stale state reset on re-entry, confirm step kept.
> `core/config.py` gains `min_withdraw_usdc = 1.0`. No new migration required.
> *(Numbered 12 because Blueprint 11 was already taken by the P&L-booking fix above.)*

---

### Blueprint 1 — Deterministic resolution tracking & auto-redeem ✅ IMPLEMENTED

**Current state (read before changing):** redemption already exists — `manage_positions.sync_positions`
→ `redeem_position` → `core.relayer.redeem_winnings` (auto-detects binary vs neg-risk on-chain) →
`convert_dw_usdce_to_pusd`. **Do not rewrite this; it works.**

**Why the bug persists — the real root cause:** the trigger is `position.redeemable == True` from the
Polymarket **Data API**. For neg-risk markets the position **disappears from the Data API** once the
parent event fully resolves, so `sync_positions` never sees it as redeemable and never fires the
redeem. Result: winnings sit as unredeemed CTF tokens (or as already-redeemed **USDC.e** that was
never wrapped) and the pUSD balance never updates — exactly the reported symptom. **Trusting the Data
API for settlement is the architectural defect. Settlement must be sourced on-chain.**

**Design — make our own `copy_trades` ledger the source of truth, confirm resolution on-chain:**

1. **Persist what we need to redeem at trade time.** In `execute_copy_trade`, when a fill is confirmed,
   denormalize onto the `copy_trades` row: `condition_id`, `token_id`, `outcome_index`, `neg_risk`,
   `entry_price`, `shares`. (Today these live only on the linked `trade_signals`; we need them on the
   trade for deterministic redeem without API lookups.)
2. **New periodic task `reconcile_settlements`** (beat, every 120s, queue `periodic`,
   `worker/tasks/manage_positions.py`). For every `copy_trades` row with
   `status='confirmed' AND redeemed_at IS NULL`:
   - Read on-chain resolution from the CTF contract (`CONDITIONAL_TOKENS` in `core/clob.py`):
     - `payoutDenominator(bytes32 conditionId) -> uint` — `> 0` ⟺ **resolved**.
     - `payoutNumerators(bytes32 conditionId, uint256 index) -> uint` — winning index has `> 0`.
   - If `payoutDenominator == 0`: not resolved, skip.
   - If resolved: `won = payoutNumerators(cond, outcome_index) > 0`.
     - **Loss:** set `result='loss'`, `realized_pnl = -entry_cost`, `resolved_at=now`,
       `redeemed_at=now` (nothing to claim), notify once.
     - **Win:** dispatch `redeem_position` (existing, idempotent). On success set `result='win'`,
       `realized_pnl`, `resolved_at`, `redeemed_at`, `redeem_tx`.
   - This is independent of Data API visibility → deterministic and self-healing across restarts.
3. **Self-healing sweep (catch stranded value).** Add `convert_dw_usdce_to_pusd` to the redeem path
   AND run it opportunistically in `monitor_deposits`: if the deposit wallet holds USDC.e with no
   pending external deposit, wrap it to pUSD (covers funds redeemed by Polymarket's UI/keeper or by a
   prior partial run). This alone recovers the "money is there as USDC.e" case.
4. **Keep the existing Data-API path as a fast complement,** but the on-chain reconciler is the
   guarantee. Dedup across both with Redis `claim(f"settle:{user_id}:{condition_id}")` /
   `notify_once` so a position is never redeemed or notified twice.

**Contract ABIs to add (in `core/relayer.py`, alongside `_CTF_ABI`):**
```json
[
  {"inputs":[{"name":"conditionId","type":"bytes32"}],"name":"payoutDenominator",
   "outputs":[{"name":"","type":"uint256"}],"stateMutability":"view","type":"function"},
  {"inputs":[{"name":"conditionId","type":"bytes32"},{"name":"index","type":"uint256"}],
   "name":"payoutNumerators","outputs":[{"name":"","type":"uint256"}],
   "stateMutability":"view","type":"function"}
]
```

**Files:** `worker/tasks/manage_positions.py` (new `reconcile_settlements`, wire into beat in
`worker/celery_app.py`), `worker/tasks/execute_copy.py` (denormalize fields), `core/relayer.py`
(resolution read helpers), `core/db/queries.py` (+ `get_outstanding_copy_trades`,
`mark_trade_settled`), `migrations/008_settlement_ledger.sql`.

**Migration 008 (idempotent):**
```sql
alter table copy_trades add column if not exists condition_id text;
alter table copy_trades add column if not exists token_id text;
alter table copy_trades add column if not exists outcome_index int;
alter table copy_trades add column if not exists neg_risk boolean default false;
alter table copy_trades add column if not exists entry_price double precision;
alter table copy_trades add column if not exists shares double precision;
alter table copy_trades add column if not exists result text;          -- win|loss|null
alter table copy_trades add column if not exists realized_pnl double precision;
alter table copy_trades add column if not exists resolved_at timestamptz;
alter table copy_trades add column if not exists redeemed_at timestamptz;
alter table copy_trades add column if not exists redeem_tx text;
create index if not exists idx_copy_trades_open
  on copy_trades (status) where redeemed_at is null;
```

#### Canonical `redeemPositions` reference (Problem 2 — read carefully, correct the misconceptions)

The on-chain claim **is already implemented and verified on mainnet** (`core/relayer.redeem_winnings`,
confirmed tx hashes, pUSD recovered). It is **NOT** a missing feature. Do **not** rewrite it from
scratch or with ethers.js. The canonical flow below documents exactly how it works so future edits
stay correct.

**Three misconceptions to reject:**
1. ❌ *"Send the tx from the user's wallet with ethers.js."* — Wrong stack and wrong signer. We use
   **Python `web3.py`** and the user **EOA usually holds no POL for gas**. The claim is executed
   **gaslessly** as a **relayer `DepositWalletCall` batch from the user's deposit wallet** (the
   ERC-1967 proxy that actually holds the outcome tokens). See `relayer.execute_deposit_wallet_batch`.
2. ❌ *"Listen to the `ConditionResolution` event."* — Event-log subscriptions miss events on restart
   and need reorg handling. Our beat-driven architecture **polls on-chain state** instead:
   `payoutDenominator(conditionId) > 0` ⟺ resolved. Idempotent, restart-safe, no missed events. (The
   event may be added later only as an optional latency accelerator, never as the source of truth.)
3. ❌ *"Plain CTF `redeemPositions` works for everything."* — **Neg-risk markets do not redeem through
   the CTF directly.** They redeem through the **NegRiskAdapter**. `redeem_winnings` auto-detects which
   by matching the held token's on-chain `positionId` (see below). Never trust the Data API
   `negativeRisk` flag.

**Contracts (import from `core/clob.py`, never hardcode):**
| Constant | Address | Role |
|---|---|---|
| `CONDITIONAL_TOKENS` | `0x4D97DCd97eC945f40cF65F87097ACe5EA0476045` | CTF (binary redeem, payout reads, ERC-1155 balances) |
| `NEG_RISK_ADAPTER` | `0xd91E80cF2E7be2e162c6513ceD06f1dD0dA35296` | neg-risk redeem + WrappedCollateral |
| `PUSD_ADDRESS` | `0xC011a7E12a19f7B1f670d46F03B03f3342E82DFB` | V2 collateral |

**Market-type detection (web3.py `eth_call`, no tx):** with `idx = 1 << outcome_index`,
`collectionId = CTF.getCollectionId(0x00…00, conditionId, idx)`:
- if `CTF.getPositionId(NegRiskAdapter.wcol(), collectionId) == held_token_id` → **neg-risk**;
- elif `CTF.getPositionId(collateral, collectionId) == held_token_id` for `collateral ∈
  {pUSD, USDC.e, USDC}` → **binary** with that collateral.

**Claim calldata (encode with `eth_abi`, wrap in a `DepositWalletCall`, send via the relayer batch):**
- **Binary:** `ConditionalTokens.redeemPositions(address collateralToken, bytes32 parentCollectionId,
  bytes32 conditionId, uint256[] indexSets)` with `parentCollectionId = 0x00…00` and
  `indexSets = [1, 2]`. The CTF burns the deposit wallet's outcome tokens and pays the collateral to
  the deposit wallet (msg.sender).
- **Neg-risk:** `NegRiskAdapter.redeemPositions(bytes32 conditionId, uint256[] amounts)` where
  `amounts[outcome_index] = on-chain ERC-1155 balance of the held token` (read via
  `CTF.balanceOf(dw, token_id)`), others `0`.
- **Payout currency = USDC.e** (empirically confirmed for both paths). The flow then calls
  `convert_dw_usdce_to_pusd` (CollateralOnramp `wrap`, also a gasless relayer batch) so the winnings
  become tradeable pUSD. **This second step is mandatory — without it the balance "doesn't update".**

**Approvals:** the deposit wallet must have `setApprovalForAll(NEG_RISK_ADAPTER, true)` on the CTF
(done at registration in `relayer.set_trading_approvals`) and USDC.e `approve(CollateralOnramp)` (done
inside `convert_dw_usdce_to_pusd`).

**Serialization:** the relayer permits **one in-flight action per deposit wallet**. On
`"wallet busy"`, retry with backoff (see `scripts/verify_v2.py redeem`). Manual recovery commands:
`python scripts/verify_v2.py inspectpos | redeem | wrapdw`.

**REMAINING GAP — ✅ IMPLEMENTED:**
1. **Migration 008 must be applied** in the target DB (see §7.4).
2. **Legacy positions (NULL ledger fields) — now recovered by `backfill_legacy_redemptions`**
   (beat every 600s, `worker/tasks/manage_positions.py`): enumerates resolved-won holdings via
   Data API (`get_positions(dw)`) and on-chain (`is_condition_resolved` + `get_payout_numerator`),
   dispatches `redeem_position` for each winner not yet redeemed. Deduped by Redis.
   Also self-heals stranded USDC.e on the deposit wallet (`convert_dw_usdce_to_pusd`).
3. **Self-healing USDC.e sweep** also added to `monitor_deposits` (runs every 120s): wraps any
   USDC.e ≥ $0.10 on the deposit wallet into tradeable pUSD opportunistically.
4. **Deploy/rebuild**: the worker image must be rebuilt (`docker compose up -d --build worker`).

**Acceptance:** a won position credits pUSD within ~2 min of on-chain resolution **even if it never
appears as `redeemable` in the Data API**; legacy positions with NULL ledger fields are recovered by
the backfill reconciler; no double-redeem; loss recorded with correct P&L; restart mid-flight resumes
safely.

---

### Blueprint 2 — Slice aggregation (accumulation tracker) + alert debounce ✅ IMPLEMENTED

**Current state:** `poll_tracked_wallets` already groups sliced fills per `(condition, token)` inside
the fetch window and dedups with an in-memory `_seen` map + a DB lookup. **The aggregation is real.**

**Reject the naive "just debounce" framing — diagnose precisely:**
- *Aggregation defect:* the current code fires the moment the running sum crosses
  `tracked_min_copy_usdc` — i.e. **mid-slice**, on a partial sum, often at a worse VWAP, while the
  whale keeps adding. We want to fire **once the slicing settles**.
- *Spam defect (the actual user-visible symptom):* the spam is **low-balance alerts**, not duplicate
  trades. Each fanned-out `execute_copy_trade` for an underfunded user calls `_notify_low_balance`
  with no throttle, so every signal re-alerts. Aggregation does not fix this; **alert throttling does.**

**Design A — Redis accumulation tracker with quiet-period + max-window debounce.**
Replace the in-memory `_seen` aggregation with a cross-process Redis bucket per `(wallet, cond, token)`:

State per bucket (Redis hash, TTL = `max_window + reentry`):
`first_ts, last_fill_ts, acc_usdc, acc_notional (Σ price·size), fills, fired(bool)`.

Each poll cycle, for fresh BUY fills not already counted (dedupe individual fills by `tx_hash` in a
Redis set), add to the bucket. **Fire exactly one signal when BOTH hold:**
```
acc_usdc >= threshold                                  # conviction floor (below)
AND ( now - last_fill_ts >= quiet_period_sec           # slicing has settled, OR
      OR now - first_ts   >= max_window_sec )          # hard cap so we never wait forever
AND not fired
```
On fire: set `fired=True`, emit signal with `price = acc_notional / acc_usdc` (true VWAP), keep the
bucket until `reentry` elapses to block re-fire. This guarantees **one entry + one alert per burst**,
entered after the whale finishes building.

**Threshold algorithm (be honest about what it does):** our copy size is a **fixed cap clamped by
depth** (§3), so the whale's absolute size is **not** a sizing input — the threshold's only job is
**noise filtering** (real directional entry vs dust/rebalance). Compute it relative to the whale, not
a flat constant:
```
threshold = max(
    abs_floor,                       # hard floor, default $50  (tracked_min_copy_usdc)
    conviction_frac * whale_avg_size # e.g. 0.5 × wallet avg trade size from discovery profile
)
```
Whale avg size is already computed in `core/wallet_discovery._activity_profile` (`avg_size`); cache it
on the `tracked_wallets` row (add column `avg_trade_usdc`) so the poller reads it cheaply. Rationale:
a $200 entry from a wallet that averages $5k is noise; the same $200 from a $300-avg wallet is a real
position. Defaults: `abs_floor=$50`, `conviction_frac=0.5`, `quiet_period=45s`, `max_window=180s`.

**Design B — alert throttling (fixes the actual spam).**
- Throttle `_notify_low_balance` with `notify_once(f"lowbal:{user_id}", ttl=6h)` so an underfunded
  user gets at most one low-balance nudge per 6h, not one per signal.
- Better: **check free pUSD once before fan-out** in `poll_tracked_wallets`; skip dispatch for users
  below `min_balance` and send the throttled nudge from there, so we don't even enqueue doomed trades.

**Files:** `worker/tasks/poll_tracked_wallets.py` (Redis accumulator + pre-fan-out balance gate),
`core/cache.py` (small hash-bucket helpers: `accum_add`, `accum_get`, `accum_mark_fired`),
`worker/tasks/execute_copy.py` (throttle `_notify_low_balance`), `core/config.py` (new knobs),
`migrations/009_tracked_avg_size.sql` (`alter table tracked_wallets add column if not exists
avg_trade_usdc double precision;`).

**Config:**
```python
slice_quiet_period_sec: int = 45
slice_max_window_sec: int = 180
slice_conviction_frac: float = 0.5
lowbal_alert_throttle_sec: int = 21600   # 6h
```

**Acceptance:** a whale that slices one $4k entry into 40 fills over 2 min → **one** copy + **one**
alert, entered at the blended VWAP after slicing settles; an underfunded user gets ≤1 low-balance
alert per 6h regardless of signal volume.

---

### Blueprint 3 — Risk-based position sizing (fractional Kelly, done correctly) ✅ IMPLEMENTED

**Reject the naive Kelly the prompt hints at.** Two things must be stated plainly:
1. Kelly needs an **edge** `q − p`. In copy-trading we **do not observe `q`**. Using a wallet's raw
   `winrate` as `q` is **wrong**: winrate is unconditional on price, while `q` must be the win
   probability **of this specific market at price `p`**. A 90%-winrate wallet betting a 0.95 favorite
   has ~zero edge, not 90%.
2. Full Kelly is variance-optimal only with a **known** edge; with an **estimated** edge it badly
   overbets. Always use **fractional Kelly** and let hard caps dominate.

**Correct binary-market Kelly.** Buying one YES share at price `p` pays `1` on win, `0` on loss →
net odds `b = (1−p)/p`. Kelly fraction of equity:
```
f* = (q − p) / (1 − p)          # bet only if q > p; else f* = 0
```
(Derivation: f* = q − (1−q)·p/(1−p) = (q−p)/(1−p).)

**Edge estimation — conservative, bounded, shrunk (this is the defensible part):**
We never trust raw winrate as `q`. Instead build a small bounded edge and add it to the market price:
```
# 1) shrink the wallet's winrate toward the market to kill small-sample noise (Bayesian)
n      = score.resolved_count
w_hat  = (wins + α) / (n + α + β)        # Beta prior, e.g. α=β=10  → pulls toward 0.5 when n small
# 2) convert track record into a *small* edge, NOT a probability
quality = clamp((w_hat - 0.5) * 2, 0, 1) # 0..1 trust factor from track record
consensus_mult = min(1 + 0.25 * (consensus - 1), 1.5)
edge_hat = min(base_edge * quality * consensus_mult, edge_cap)   # base_edge≈0.03, edge_cap≈0.06
q_hat = min(p + edge_hat, 0.99)
```
`wins` and `resolved_count` come from `core.wallet_score.score_wallet`; `consensus` is already on the
signal. If the wallet is unscored (lag), use `edge_hat = base_edge * 0.5` (minimum trust).

**Final stake (caps dominate, with a minimum-order FLOOR — see Problem 1 below):**
```
f_kelly = max((q_hat - p) / (1 - p), 0)
f       = kelly_lambda * f_kelly                 # kelly_lambda = 0.25 (quarter-Kelly)
f       = min(f, max_risk_per_trade)             # hard ceiling, e.g. 0.05 of equity
stake   = f * equity(user)
stake   = min(stake, user.max_position_usdc, depth_cap)   # existing depth/cap clamps stay
# Floor up to the exchange minimum so small accounts still trade (NOT a hard block):
stake   = max(stake, exchange_min_order(market))          # see Problem 1
stake   = min(stake, free_pusd)                           # never spend more than we have
stake   = 0 only if free_pusd < exchange_min_order(market) OR depth < exchange_min_order(market)
```
This **replaces** the flat `size_usdc = min(user_max, depth_cap)` in `execute_copy_trade`. Keep all
existing depth/book-safety/price-band clamps; Kelly sets the **upper** bound, the exchange minimum sets
the **lower** bound.

**Files:** `core/sizing.py` (pure module: `kelly_stake(p, score, consensus, equity, free_pusd, cfg)
-> float`, unit-testable, no I/O), `worker/tasks/execute_copy.py` (call it), `core/config.py` (knobs).

**Config:**
```python
sizing_mode: str = "kelly"          # "fixed" (legacy) | "kelly"
kelly_lambda: float = 0.25          # fraction of full Kelly
kelly_base_edge: float = 0.03       # edge for a fully-trusted single wallet
kelly_edge_cap: float = 0.06        # absolute edge ceiling
kelly_prior_strength: float = 10.0  # α=β for winrate shrinkage
max_risk_per_trade: float = 0.05    # hard cap: ≤5% of equity per position
recommended_min_balance_usdc: float = 100.0  # SOFT target (warn only, never blocks)
exchange_min_order_usdc: float = 1.0         # Polymarket platform floor (fallback size)
n_target_positions: int = 5
```

**Acceptance:** stake scales up with wallet quality/consensus and **down** as `p → 1` (favorites get
small bets), never exceeds `max_risk_per_trade · equity`. `sizing_mode="fixed"` reproduces legacy
behavior for rollback. **(See Problem 1 below for small-balance behavior.)**

---

### Blueprint 3.1 — Soft minimum balance + minimum-order fallback ✅ IMPLEMENTED

**Current bug:** `execute_copy_trade` does `if equity < settings.min_balance_usdc ($100): skip` and
`if size_usdc < settings.min_order_usdc ($5): skip`. A real $3.06 wallet is **hard-blocked** and never
trades. For a SaaS this silently breaks the product for small accounts.

**Reject the hard block.** `$100` is a **risk-management recommendation**, not a gate. Below it we
**still trade**, at the smallest valid Polymarket order, and **warn** the user to top up.

**Polymarket minimum order size.** The CLOB enforces a per-market minimum. Use **`$1` USDC notional**
as the platform floor, and prefer the market-specific value when available:
```
# /markets/{conditionId} → minimum_order_size (shares) and minimum_tick_size; the order book
# (get_order_book) also exposes these. Notional floor for a BUY:
exchange_min_order(market) = max(
    exchange_min_order_usdc,                       # platform floor, default $1
    minimum_order_size_shares * entry_price        # per-market share minimum × price, if known
)
```
Round up to satisfy tick/size rules; if the market min can't be read, fall back to `$1`.

**Fallback algorithm (replace the two hard `return skip` blocks):**
```
stake = kelly_or_fixed_stake(...)                 # may be tiny for a small account
floor = exchange_min_order(market)

# 1) SOFT recommendation: warn (throttled) when equity is below the recommended target,
#    but DO NOT block.
if equity < recommended_min_balance_usdc:
    warn_once(user, "trading_min", ttl=6h,
              text="⚠️ Баланс ниже рекомендованного. Торгуем на минималках — пополни баланс для нормального риск-менеджмента.")

# 2) Size: respect Kelly/caps, but never below the exchange minimum.
stake = max(stake, floor)
stake = min(stake, free_pusd)                     # can't spend more than we have

# 3) ONLY skip if we genuinely cannot place a valid order:
if free_pusd < floor:
    notify_low_balance_once(user, free_pusd, floor)   # throttled (BP2)
    return skip("insufficient_for_min_order")
if fillable_depth < floor:
    return skip("depth_below_min_order")              # book too thin even for the minimum

place_order(stake)                                    # otherwise: TRADE at the minimum
```
So a $3.06 wallet places a ~$1 order (capped by free balance), gets **one** "trading at minimum" warning,
and keeps copying. It is only skipped when it can't afford even the $1 platform minimum.

**Notes / guardrails:**
- Keep `max_position_usdc` and depth caps as the **upper** bounds; this change only fixes the **lower**
  bound. Risk gates (Blueprint 4: exposure %, drawdown) still apply and are percentage-based, so they
  scale correctly for small accounts.
- The "trading at minimum" warning and the "insufficient for minimum order" alert are **separate** and
  both throttled via `notify_once` (BP2) so small accounts are not spammed.
- Optional: at the very low end the bot can also auto-sweep the EOA (existing `fund_deposit_wallet`)
  before deciding it's underfunded (already attempted in current code).

**Files:** `worker/tasks/execute_copy.py` (remove the `below_min_balance` hard return and the flat
`min_order_usdc` skip; implement the fallback above), `core/sizing.py` (add `exchange_min_order` helper
or compute in the task from the book), `core/polymarket.py` (expose `minimum_order_size` from the
market/book if not already), `core/config.py` (replace `min_balance_usdc`/`min_order_usdc` with
`recommended_min_balance_usdc` + `exchange_min_order_usdc`).

**Acceptance:** a $3.06 wallet trades at the ~$1 minimum and receives exactly one throttled
"trading at minimum" warning; copying is skipped **only** when free pUSD or book depth is below the
platform minimum order; large accounts are unaffected; no hard `$100` block remains anywhere.

---

### Blueprint 4 — Tail-risk controls (exposure, correlation, drawdown, daily loss) ✅ IMPLEMENTED

**The math behind the "verняк" trap.** A 0.75 favorite pays only `(1−p)/p = 0.33` per $1 risked but
loses the **entire** stake on the rare miss → strongly **negative skew**. Flat or oversized, a single
loss erases many wins (5 wins × +0.33 = +1.67, wiped by ~5 losses... but at large `f` one loss can be
ruinous). Kelly (Blueprint 3) sizes each bet correctly; Blueprint 4 is the **portfolio backstop** for
estimation error and **correlation** (favorites cluster — same event, same team, same day).

Implement four gates as a single **pre-trade risk check** in `execute_copy_trade`, evaluated **after**
sizing and **before** `place_order`. Any breach → skip with a throttled alert (reuse Blueprint 2's
throttle). Order them cheapest-first.

1. **Aggregate exposure cap.** Total cost of open positions must stay within a fraction of equity:
   ```
   open_exposure = Σ open_position.cost
   skip if (open_exposure + stake) > max_portfolio_exposure_pct * equity   # e.g. 0.60
   ```
   Keeps dry powder; prevents being 100% deployed into correlated favorites.

2. **Per-event / correlation cap.** Two outcomes in the **same event** can lose together → treat them
   as one correlated bet. Bucket by `event_slug` (present on signals/positions; fall back to
   `eventId`). The existing "already in this market" guard is **per-condition** — upgrade it to
   **per-event**:
   ```
   event_exposure = Σ cost of open positions sharing this signal's event_slug
   skip if (event_exposure + stake) > max_event_exposure_pct * equity      # e.g. 0.15
   ```
   This subsumes the scattershot risk and limits team/league clustering at the event level. (Stretch:
   group by Gamma category/tag for cross-event correlation; event-level is the pragmatic v1.)

3. **Drawdown circuit breaker (high-water mark).** Track per-user realized equity HWM; if current
   equity falls too far from peak, **pause copying**:
   ```
   hwm = max(hwm, equity)                          # update each settlement/sync
   drawdown = (hwm - equity) / hwm
   if drawdown >= max_drawdown_pct:                # e.g. 0.25
       set users.copy_paused_until = now + cooldown   # e.g. 24h
       notify user once; reconcile loop auto-resumes after cooldown
   ```
   Store `equity_hwm` and `copy_paused_until` on `users`. `get_active_subscribers` and the pre-trade
   gate must honor `copy_paused_until`.

4. **Daily loss limit.** Sum `realized_pnl` of `copy_trades` settled in the trailing 24h; if losses
   exceed a fraction of start-of-day equity, pause until the next UTC day:
   ```
   if Σ realized_pnl (last 24h) <= -daily_loss_limit_pct * equity_at_day_start:  # e.g. 0.10
       pause copying until 00:00 UTC; notify once
   ```

**Note on the existing hard-stop** (`hard_stop_abs_price = 0.07`): keep it, but it is a
**capital-recycling** tool (exit a near-dead outcome), **not** a risk control. The real protection is
correct sizing (BP3) + these portfolio gates. Do not present the hard-stop as the stop-loss system.

**Files:** `core/risk.py` (new pure module: `check_risk_gates(user, signal, stake, open_positions,
cfg) -> RiskDecision`), `worker/tasks/execute_copy.py` (call before `place_order`),
`worker/tasks/manage_positions.py` (update `equity_hwm`, evaluate breaker/daily-loss in the reconcile
loop, set/clear `copy_paused_until`), `core/db/queries.py` (HWM + pause helpers; honor pause in
`get_active_subscribers`), `migrations/010_risk_controls.sql`.

**Migration 010 (idempotent):**
```sql
alter table users add column if not exists equity_hwm double precision default 0;
alter table users add column if not exists copy_paused_until timestamptz;
```

**Config:**
```python
max_portfolio_exposure_pct: float = 0.60
max_event_exposure_pct: float = 0.15
max_drawdown_pct: float = 0.25
drawdown_cooldown_sec: int = 86400
daily_loss_limit_pct: float = 0.10
```

**Acceptance:** a user cannot deploy >60% of equity, cannot stack >15% into one event, is auto-paused
on a 25% drawdown (auto-resumes after cooldown) and on a 10% daily loss; all pauses notify once and
are honored by both the fan-out and the pre-trade gate.

---

### Blueprint 5 — Correct time-to-resolution parsing & display ✅ IMPLEMENTED

**Symptom (live test):** the bot tells the user "до закрытия рынка ~1 ч" while the event
actually runs until end of the US day (~12 h). The countdown is both **wrong** and **frozen**.

**Root cause — three compounding defects, do NOT "just add hours":**

1. **Wrong source field (dominant cause).** `core/polymarket._build_market_meta` reads
   `end_iso = m.get("endDateIso") or m.get("endDate")` (`core/polymarket.py:101`). For any market
   that belongs to an **event** (sports / daily / multi-outcome — i.e. most fast markets), the
   *per-market* `endDate` is frequently an **understated placeholder** (a nominal cutoff or the
   game's scheduled time), while the real resolution boundary is the **event** `endDate`
   ("end of US day"). The event object is already fetched — `events = m.get("events")` — but only
   `events[0].slug` is kept; **`events[0].endDate` is discarded.** That discarded field is the
   correct one.
2. **Frozen value, never recomputed.** `hours_to_resolve` is computed **once** at fast-markets
   cache-build time (`refresh_fast_markets`, every `fast_markets_refresh_sec=120s`) and copied
   verbatim into the signal (`worker/tasks/poll_tracked_wallets.py:259` → `meta.get("hours_to_resolve")`).
   The user notification (`worker/tasks/execute_copy.py:660`) and the AI prompt
   (`worker/tasks/ai_filter.py:50`) read `signal["hours_to_resolve"]` directly — a stale scalar,
   never recomputed at send time. `core/detector._hours_fresh` already recomputes correctly **but
   the live Model-B path never calls it**, and the signal does not even carry the ISO end date, so
   downstream *cannot* recompute.
3. **Timezone / date-only edge.** Polymarket ISO strings are UTC (`…Z`); the arithmetic in
   `_hours_until` is correctly tz-aware, so there is **no EST math bug** — the EST aspect is purely
   a *display* concern ("end of US day"). The real parsing trap is **date-only** strings
   (`"2026-06-24"`), which `dateutil` parses to `00:00:00Z` — understating the deadline by up to a
   full day.

**Design — one authoritative time source, computed fresh, formatted for humans.**

**(A) Single resolution-time resolver (pure, in `core/polymarket.py`).**
```
def resolution_dt(obj: dict) -> datetime | None:
    # obj = a Gamma market dict OR a normalized position dict.
    # Candidate ISO strings, in AUTHORITY order (most reliable first):
    #   market endDateIso, event endDate (events[0].endDate), market endDate, position endDate
    # Parse each → tz-aware UTC:
    #   - naive (no tz)      → assume UTC
    #   - date-only "YYYY-MM-DD" → 23:59:59Z of that day (END of day, never 00:00)
    # Selection rule (this is the fix for the placeholder-endDate bug):
    #   among all parsed candidates, return the LATEST one that is still in the future;
    #   if none are in the future, return the latest candidate overall (resolving/closing).
    # Rationale: Polymarket keeps a market tradeable until the real event concludes, and the
    # per-market endDate is the field that UNDER-states; taking the latest plausible boundary
    # (which is the event endDate for grouped markets) matches reality.
    # gameStartTime is a START, not a resolution — never use it as the deadline.
```

**(B) Carry the ISO end on the signal, not a frozen scalar.**
- In `_build_market_meta`: also extract `event_end_iso = (events[0] or {}).get("endDate")` and store
  `resolution_iso = resolution_dt(m).isoformat()` in the meta (keep `hours_to_resolve` for the
  internal window filter only — see (D)).
- In `poll_tracked_wallets` signal dict: replace `"hours_to_resolve": meta.get("hours_to_resolve")`
  with `"resolution_iso": meta.get("resolution_iso")` (and keep `hours_to_resolve` only if some
  consumer still needs the coarse number).

**(C) Format fresh at the moment of sending (pure, in `core/polymarket.py`).**
```
def format_time_left(resolution_iso: str | None, now: datetime | None = None) -> str:
    dt = _parse_iso(resolution_iso); now = now or datetime.now(timezone.utc)
    if dt is None:                    return "время уточняется"
    delta = (dt - now).total_seconds()
    if delta <= 0:                    return "резолв скоро"
    if delta < 3600:                  return "<1 ч"
    if delta < 86400:                 return f"~{delta/3600:.0f} ч"
    d, h = divmod(int(delta // 3600), 24)   # d days, h hours
    return f"{d}д {h}ч"
```
- Replace **every** display site that does `f"~{hours:.0f} ч"`:
  `execute_copy._notify` (`hours_line`) and `ai_filter._call_gpt` (`hours=`) must call
  `format_time_left(signal.get("resolution_iso"))` evaluated **at send time**, not the frozen field.
- Optional nicety (recommended for "end of US day" markets): also render the ET wall-clock deadline
  via `zoneinfo.ZoneInfo("America/New_York")`, e.g. `"до 23:59 ET (через ~12 ч)"`. This is display
  only; all math stays in UTC.

**(D) Keep `hours_to_resolve` for the coarse window filter only.** The
`market_min/max_hours_to_resolve` gate in `_build_market_meta` can keep using the freshly computed
hours from `resolution_dt` — small staleness there is harmless. It must **not** be surfaced to users.

**Files:** `core/polymarket.py` (`resolution_dt`, `format_time_left`, use event endDate in
`_build_market_meta`, add `resolution_iso` to meta), `worker/tasks/poll_tracked_wallets.py` (carry
`resolution_iso` on the signal), `worker/tasks/execute_copy.py` (`_notify` formats fresh),
`worker/tasks/ai_filter.py` (`_call_gpt` formats fresh), `core/detector.py` (route `_hours_fresh`
through `resolution_dt` so all paths agree). No migration required (signal is an in-memory dict).

**Config (optional):**
```python
show_resolution_in_et: bool = True   # also render the America/New_York deadline in notifications
```

**Acceptance:** for an event that resolves at end of US day, the notification and the AI prompt show
~12 h (and optionally the ET deadline), not 1 h; the value is correct even minutes after the cache
was built (recomputed at send time); date-only `endDate` markets are treated as end-of-day, never
midnight; markets grouped under an event use the event boundary, not the understated per-market one.

---

### Blueprint 6 — Position state machine & P&L on manual / stop close ✅ IMPLEMENTED

**Symptom (live test):** user manually sells a position **in profit**. Hours later the contract
resolves on-chain and the bot (a) sends an **empty** win notification (no title) crediting **$0.01**
of dust, then (b) immediately trips the **daily-loss limit** and blocks trading — though there was no
loss.

**Root cause — the ledger is never closed on a token-sale exit (code-cited):**

1. `manage_positions.close_position` sells the outcome tokens, sets a **TTL-bound** Redis key
   (`_claim_settled` → `settle:{uid}:{cond}`), and notifies the user — but **never updates the
   `copy_trades` row**. The row stays `status='confirmed', redeemed_at IS NULL`.
2. `get_outstanding_copy_trades` (`core/db/queries.py:378`) therefore keeps returning that row.
   When the condition later resolves on-chain, `reconcile_settlements` acts on it. By then the
   Redis `settle:`/`redeem:` keys set at close time have **expired** (TTL ≪ hours-to-resolution),
   so the dedup guard is gone.
3. If the exited outcome happens to **win**, reconcile dispatches `redeem_position`, which claims the
   **dust** left behind by `close_position`'s floor-to-2-dp truncation (`manage_positions.py:281`,
   `math.floor(shares*100)/100`), emits `_emit_win`/"Выигрыш зачислен" with `title=None, outcome=None`
   (the empty message — symptom **a**), and writes
   `realized_pnl = credited(≈$0.01) − entry_cost(full size)` ⇒ a large **phantom loss** on a
   `result='win'` row.
4. `get_daily_realized_pnl` sums that phantom negative ⇒ BP4 daily-loss breaker trips ⇒ trading
   paused (symptom **b**). (On the loss branch reconcile would also write `-entry_cost` for an
   already-exited position — double-counting.)

**Design — the `copy_trades` ledger is the single state machine; a token-sale exit is TERMINAL.**

**(1) Close = write the ledger, atomically, in `close_position`.** On a successful `sell_position`:
- Compute realized P&L from the **actual sale**, not from any later resolution:
  ```
  entry_cost  = copy_trades.size_usdc          # filled cost basis (denormalized at fill)
  proceeds    = shares_sold * fill_price        # executed sale value (from the sell result)
  realized_pnl = proceeds - entry_cost          # correct sign immediately (+ on a profitable exit)
  ```
- Call a new `mark_trade_closed(trade_id, result='closed', realized_pnl, exit_tx)` that sets
  `status='closed', result='closed', realized_pnl, resolved_at=now, redeemed_at=now`. Setting
  `status='closed'` **and** `redeemed_at` removes the row from `get_outstanding_copy_trades` forever
  (it filters `status='confirmed' AND redeemed_at IS NULL`) — independent of any Redis TTL.
- This books Realized P&L into the daily stats **once, with the right sign, at close time**, and
  permanently removes the position from the resolve / auto-claim queue.

**(2) Find the row to close.** `close_position(user_id, token_id, reason)` lacks the trade id. Add
`get_open_trade_by_token(user_id, token_id) -> dict|None` (status `confirmed`, `redeemed_at IS NULL`,
matching `token_id`, newest first) to obtain `trade_id` + `size_usdc`. Where `sync_positions`
dispatches `close_position` it may pass the `trade_id` directly when known.

**(3) Make reconcile / backfill respect ledger state (defense in depth).**
- `get_outstanding_copy_trades` already excludes `status!='confirmed'`, so step (1) auto-fixes the
  main path. **Additionally**, in `backfill_legacy_redemptions` (which enumerates Data-API holdings
  irrespective of the ledger) add a guard: before dispatching a redeem for `(uid, condition_id)`,
  skip if any `copy_trades` row for that `(user_id, condition_id)` is in a **terminal** state
  (`status IN ('closed') OR redeemed_at IS NOT NULL`). Helper: `has_terminal_trade(user_id, condition_id) -> bool`.

**(4) Dust + active-trade guard in the claim path (covers legacy rows with NULL ledger fields).**
Before any redeem **and** before any win/loss notification, in `redeem_position`,
`reconcile_settlements`, and `backfill_legacy_redemptions`:
- Read the on-chain ERC-1155 balance `CTF.balanceOf(deposit_wallet, token_id)` (the relayer already
  reads this for neg-risk amounts — expose a small `get_ctf_balance(dw, token_id) -> int` helper).
  Convert to shares; if `shares < claim_dust_min_shares` (or notional `shares * resolve_price <
  claim_dust_min_usdc`), **skip the claim and the notification** and log `skip_dust_claim`. This
  alone kills the empty "$0.01 win" message, even for pre-existing rows.
- Require the trade to still be active: if a matching `copy_trades` row exists and is **terminal**,
  skip (the user already exited — do not claim, do not notify).

**(5) Never notify with a missing title.** `_emit_win`/`_emit_loss` must not fire with
`title=None`. On the on-chain-only path, hydrate the title from the trade's `signal_id`
(join `trade_signals.title`) or from the Data API position; if still unknown **and** the balance is
dust, suppress entirely (per step 4). A real, non-dust win must always carry a human title.

**(6) Leave genuine holds untouched.** For positions actually held to resolution,
`realized_pnl = credited − entry_cost` stays correct **because** `credited` is the full redemption,
not dust — the dust + terminal guards guarantee that formula never runs on an exited position.

**Files:** `worker/tasks/manage_positions.py` (`close_position` books P&L + `mark_trade_closed`;
`reconcile_settlements`/`backfill_legacy_redemptions`/`redeem_position` get dust + terminal-state +
title guards), `core/db/queries.py` (`get_open_trade_by_token`, `mark_trade_closed`,
`has_terminal_trade`), `core/relayer.py` (`get_ctf_balance` helper if not already exposed),
`core/config.py` (knobs), `migrations/011_position_state.sql`.

**Migration 011 (idempotent):**
```sql
-- 'result' is free-text; documented values now: win | loss | closed | null
alter table copy_trades add column if not exists exit_tx text;
create index if not exists idx_copy_trades_user_condition
  on copy_trades (user_id, condition_id);
```

**Config:**
```python
claim_dust_min_shares: float = 1.0   # ignore outcome-token balances below this at claim time
claim_dust_min_usdc:   float = 1.0   # …or notional floor (≈ exchange minimum) at resolve price
```

**Acceptance:** a manual (or hard-stop) close in profit immediately books `result='closed'` with a
correct **positive** realized P&L and disappears from the outstanding queue; the later on-chain
resolution produces **no** claim and **no** notification (dust + terminal guards); the daily-loss
breaker is **not** tripped; genuine holds still redeem fully and send exactly one titled win/loss
message; no empty or `$0.01` notifications ever occur; behavior is restart-safe because state lives in
the DB ledger, not in Redis TTLs.

---

### Blueprint 7 — Small-balance silent-skip RCA: exposure-cap → warn-only + sizing-mode-aware messaging ✅ IMPLEMENTED

**Symptom (prod, silent failure).** A small-balance user receives the "торгуем на минимальном объёме"
soft-limit alert, and then the bot **opens no positions at all** — no new trades, no error in the
worker logs, no user-facing failure. The bot looks alive but never trades.

**Root cause (from prod worker logs, user_id=2).** This is **not** an Ethers/decimals, relayer, CLOB,
or event-loop problem (all ruled out by logs: no `place_order_failed`, no web3/signature tracebacks,
worker heartbeat + periodic tasks healthy). The trade dies on **Blueprint 4's Gate 1 (exposure_cap)**,
which **hard-skips** instead of clamping:
```
[info] equity_below_recommended       equity=14.21 recommended=100.0 user_id=2     # the soft-limit alert
[info] skip_risk_gate  gate=exposure_cap
       reason='Открытые позиции (5.00$) + ставка (8.00$) превышают 60% капитала.'  # every signal dies here
```
Math: `equity≈$14.21`, open `$5.00`, fixed stake `$8.00`, cap `0.60 × 14.21 = $8.53`. Since
`5.00 + 8.00 = 13.00 > 8.53` every BUY is blocked. **At low equity the $5 platform minimum order and
the 60% exposure cap are mathematically incompatible**: after the first position there is almost no
headroom left for a new one. The skip is logged at `info` and the `skip_risk_gate` user alert is
throttled to once/hour (`notify_once(..., ttl=3600)`), so after the first soft-limit message the user
sees only silence. (Secondary, **not** a bug: many signals also legitimately hit
`skip_price_out_of_range` because tracked whales buy favorites priced > `max_entry_price=0.95`.)

**Product decision (agreed).** Below the recommended balance, **never block** on the exposure cap —
trade what fits, and if even the minimum order can't fit under the cap, **place it anyway and warn**
that the bot entered with >60% of balance. `$100` stays a recommendation, shown **conditionally on the
sizing mode**.

**Fix (sub-blueprints):**

1. **Capacity gates clamp, never silent-block (core RCA fix).** In `core/risk.py`, Gates 1
   (exposure_cap) and 2 (event_cap) stop returning a hard `allowed=False`. Extend `RiskDecision` with
   `max_stake: float | None` and `warn: str | None`. Compute `headroom = cap − already_deployed`:
   - `headroom ≥ stake` → allow, no message.
   - `exchange_min ≤ headroom < stake` → **clamp** `max_stake = headroom` (enter smaller, under cap, no
     warning).
   - `headroom < exchange_min ($5)`:
     - equity **< `recommended_min_balance_usdc` ($100)** → **enter at the $5 minimum, cap ignored**,
       set `warn="concentration_over_60"`.
     - equity **≥ $100** → throttled honest message + skip (rare: funded but ~fully deployed account;
       never silent).
   - **Gates 3 & 4 (drawdown, daily_loss) are unchanged** — loss-breakers must still pause.
   In `execute_copy_trade`, apply `decision.max_stake` (re-floor to `exchange_min`, re-clamp to
   `tradeable`) and forward `decision.warn` to the trade notification.

2. **Sizing-mode-aware messaging.** In `worker/tasks/execute_copy.py`:
   - Soft-limit "$100" warning (`_notify_trading_at_minimum` + `equity_below_recommended`) fires
     **only in `kelly` mode** (Kelly without capital yields tiny stakes — rationale holds). In `fixed`
     mode the user chose their own size → **stay silent about balance** during trading.
   - The **concentration warning** (`warn="concentration_over_60"`) is appended as a line to the
     existing success notification `_notify` (not a separate spam message) and shows in **both** modes
     (it's a risk note, not a balance nag): e.g. "⚠️ Позиция заняла >60% капитала — риск концентрации".
   - Drop `equity_below_recommended` to `log.debug`.

3. **Onboarding one-time recommendation.** At wallet registration/setup, send **once** (idempotent via
   a `users` flag or `notify_once`): recommend choosing **Kelly** and topping up to **≥ $100**, with a
   one-line rationale. Never blocks.

4. **Centralize the "$100 recommended + why" copy** in one place, reused by onboarding, the Kelly
   low-balance warning, and the `/wallet` + sizing-settings screens, so wording stays consistent.

5. **(Hygiene, optional, unrelated to the RCA)** Celery result backend bloat observed in prod
   (`celery-task-meta-*`, 7800+ keys in Redis). Add `result_expires` (e.g. 3600s) in
   `worker/celery_app.py`.

**Files:** `core/risk.py` (Gate 1/2 clamp + `RiskDecision.max_stake/warn`), `worker/tasks/execute_copy.py`
(apply clamp; mode-gate soft-limit alert; append concentration warning to `_notify`), onboarding handler
(`core/clob.register_deposit_wallet` / Telegram setup flow — locate at implementation), shared messaging
copy module, optional `worker/celery_app.py` (`result_expires`).

**Config:** no new keys required; behavior keyed off existing `recommended_min_balance_usdc` (100),
`exchange_min_order_usdc` (5.0), `max_portfolio_exposure_pct` (0.60), `sizing_mode` ("fixed").

**Acceptance:** a ~$14 wallet with an open $5 position **still copies** (enters at the $5 minimum) and
receives a single "entered >60% of capital" concentration note instead of silence; in `fixed` mode no
per-trade balance warnings are sent; in `kelly` mode the "recommend ≥ $100" warning is shown (throttled);
funded accounts (≥ $100) keep the real exposure cap via clamping and are never silently skipped; no
`skip_risk_gate gate=exposure_cap` ever results in a silent no-trade for sub-$100 balances.

---

### Blueprint 8 — Equity accounting RCA: phantom drawdown, unified per-trade risk cap, manual override ✅ IMPLEMENTED

**Symptoms (live test, real funds):**
1. **Phantom drawdown + auto-block.** The bot enters a trade for almost the whole
   balance. The funds lock into an open (un-resolved) Polymarket position. The bot
   *immediately* records equity falling from **$18.07 → $12.95** and pauses copying
   on **"Просадка 28.3%"**, even though nothing actually lost — the position is just
   open and un-resolved.
2. **Block-alert spam.** After the pause, the user keeps receiving repeated
   "копирование приостановлено" notifications over time.
3. **(Problem 2)** A fully-lost trade in `fixed` mode wipes the entire accumulated
   profit; the stop-loss behaves inconsistently between `fixed` and `kelly`.
4. **(Problem 3)** There is no way for the user to lift a drawdown pause early.

**Root cause — three independent defects (code-cited). Do NOT "just lower the
drawdown threshold" — that hides the bug and weakens real protection.**

**✅ Confirmed by production worker logs (`drawdown_breaker_tripped`, 2026-06-26 → 29):**
```
2026-06-28 20:23:38  drawdown_breaker_tripped  drawdown=0.2834  equity=12.95  user_id=1
2026-06-29 20:27:40  drawdown_breaker_tripped  drawdown=0.2834  equity=12.95  user_id=1   ← identical, ~24h later
2026-06-27 20:19:42  drawdown_breaker_tripped  drawdown=0.6292  equity=6.70   user_id=1
2026-06-29 00:03:37  drawdown_breaker_tripped  drawdown=0.6046  equity=8.45   user_id=2
```
Two independent confirmations, both predicted above:
1. **Phantom & frozen (RCA-1).** `equity=12.95, drawdown=0.2834` is the exact reported
   symptom, and it recurs **with byte-identical values 24 h apart** (06-28 20:23 →
   06-29 20:27). Equity is *stuck* because the position is held and un-resolved — the
   breaker is reacting to a frozen mark-to-market markdown, not to any realized loss.
   The deeper trips (62.9% / 60.5%) are the same effect compounded across several open
   lots (incl. a cheap longshot: `filled=4.85 shares=28.5` ⇒ entry ≈ 0.17, marked even
   lower). All `copy_trade_ok` lines show clean `fill=full` — **nothing actually lost.**
2. **Re-pause spam loop (RCA-2).** The 24 h gap = `drawdown_cooldown_sec` (86 400 s): the
   pause expires → `sync_positions` auto-resumes → the very next cycle re-evaluates the
   **same frozen markdown** → re-trips → re-notifies. This is the user-visible
   "повторно шлёт уведомления" spam, and it will repeat every 24 h forever until the
   underlying market resolves. Cost-basis equity (RCA-1 fix) breaks the loop at the
   source; the transition-only state machine (RCA-2 fix) stops the re-notify.

#### RCA-1 — Equity is marked-to-market on the open position's depressed price

`equity = free_pusd + Σ current_value`, computed identically in three places:
- `worker/tasks/execute_copy.py:142-149` and `:176-183` (pre-trade gate),
- `worker/tasks/manage_positions.py:181-186` (`sync_positions` HWM update),
- `core/risk.py:72-74` (`open_exposure` inside the gate).

`current_value = shares × curPrice` (`core/polymarket.py:440`), where `curPrice` is
Polymarket's **live mark** (bid/mid side). The instant a BUY fills, the position is
re-priced at this mark, which for a freshly-bought fast-resolving favorite sits
**below entry** (spread + thin-book mark). So the act of opening a trade converts
cash into a position whose *marked* value is lower than what we just paid:

```
before:  free=$18.07, open=$0          → equity=$18.07   → HWM=$18.07
buy ~$15 into one position
after:   free≈$3.05,  current_value≈$9.90 (marked at curPrice, not entry)
         → equity=$12.95               → drawdown=(18.07-12.95)/18.07 = 28.3%
```

28.3% > `max_drawdown_pct` (0.25) ⇒ the breaker trips on a position that has **not
resolved and has not lost anything**. The HWM was captured on all-cash equity, then
compared against marked-down equity one cycle later. **Mark-to-market noise on open,
un-resolved positions is being treated as realized drawdown.** This is the phantom.

**Fix — drawdown/HWM must run on a REALIZED (cost-basis) equity definition.**
Opening a position is **capital-neutral**: cash becomes cost basis of equal value.
Define a single authoritative function (pure, in `core/risk.py`):

```
def total_equity(free_pusd, open_positions, ledger_cost_by_token, cfg) -> float:
    # cost_basis per open position, in AUTHORITY order:
    #   1) copy_trades.size_usdc for the matching open trade (true filled cost)   ← preferred
    #   2) shares * avg_price    (Data-API cost basis fallback)
    #   3) current_value         (last-resort mark, only if no cost basis known)
    open_cost = Σ cost_basis(p)  for p in open_positions if p.shares > 0
    return free_pusd + open_cost
```

- The **drawdown circuit breaker, HWM, exposure cap, and event cap** all switch to
  this cost-basis equity (`drawdown_equity_mode="cost_basis"`, default). With it,
  the buy above gives `equity = 3.05 + 15.00 = 18.05 ≈ HWM` → **drawdown ≈ 0%**, no
  false trip. A breaker only fires when a position **actually resolves/closes at a
  loss** — and that realized loss is already booked on the `copy_trades` ledger
  (`realized_pnl`, BP1/BP6) and flows through `get_daily_realized_pnl`.
- Mark-to-market (`current_value`/`cur_price`) stays for **display only** (P&L
  screens, position lists) — never for the breaker.
- `drawdown_equity_mode="mark"` preserves the legacy behaviour for instant rollback.

> **Why cost-basis, not mark:** binary Polymarket positions are held to resolution
> (§2.5). Their interim mark is economically meaningless (illiquid, wide spread) and
> mean-reverts to $1 or $0 at resolve. Drawdown protection must react to **realized**
> capital destruction, not to transient bid marks on positions we intend to hold.

#### RCA-2 — Broken pause state machine → duplicate / repeated block alerts

- **Two notifiers, two throttle keys.** The drawdown pause is announced from
  *both* `manage_positions._update_hwm_and_check_breakers` (`:914`,
  `notify_once("drawdown_alert:{uid}", ttl=86400)`) *and*
  `execute_copy_trade` (`:331`, `notify_once("risk_gate:{uid}:drawdown", ttl=3600)`).
  Different keys ⇒ the user gets **two** alerts per event, and the 1 h key lets the
  execute path **re-alert every hour** while paused.
- **Re-pause every cycle.** `sync_positions` runs every 120 s; while equity stays
  below the HWM threshold it calls `pause_user_copying` again each pass, pushing
  `copy_paused_until` forward — so a *persistent* (phantom) markdown can keep the
  account paused indefinitely and re-evaluate forever. There is no explicit state,
  only an inferred timestamp.

**Fix — one explicit state machine, notify once on transition.** Add a
`users.risk_state` column and make the *transition* (not the evaluation) the event:

```
states: active → paused_drawdown → active
        active → paused_daily_loss → active
        paused_* → override_active → active   (manual unblock, RCA-3)

transition rules (evaluated only in sync_positions / the single breaker owner):
  active        & drawdown ≥ max_drawdown_pct  → set paused_drawdown,
                                                 set copy_paused_until,
                                                 send ONE notification (with unblock button)
  paused_*      & cooldown elapsed             → set active (auto-resume), notify once
  paused_*      & still tripped                → DO NOTHING (no re-pause, no re-notify)
```

- **Single owner of the notification.** Only `sync_positions` sends the pause alert
  (on the `active → paused_*` edge). `execute_copy_trade` becomes a pure *enforcer*:
  it still honors `copy_paused_until` and skips the trade, but **never sends the
  pause notification** (drop the `_notify_risk_pause` call for the `drawdown`/
  `daily_loss` gates; keep it only for genuinely new info if any). This removes the
  second path entirely.
- **Idempotent transition guard.** The notification fires only when
  `risk_state` actually changes value (compare-and-set), so repeated evaluations
  while already `paused_drawdown` send nothing — independent of any Redis TTL.
- Keep a Redis `notify_once` as a belt-and-suspenders cross-process guard, but the
  DB `risk_state` edge is the source of truth.

#### Problem 2 — Unified Risk-per-Trade Cap (mode-agnostic stop-loss)

**Root cause:** `max_risk_per_trade` (0.05 of equity) is enforced **only inside
`kelly_stake`** (`core/sizing.py:94`). The `fixed` branch
(`execute_copy.py:169-172`) sizes `min(user_max, depth_cap)` with **no** per-trade
equity ceiling. A user with `max_position_usdc=$25` on a `$30` balance bets ~83% of
equity; one fully-lost binary trade (worst case = the entire stake) erases the whole
account / all accumulated profit.

**Fix — hoist the cap out of Kelly into one place that runs in BOTH modes.** After
sizing (Kelly *or* fixed) and before the BP4/BP7 gates, in `execute_copy_trade`:

```
# Unified per-trade risk cap — applies regardless of sizing_mode.
if cfg.enforce_risk_per_trade_cap:
    hard_cap = cfg.max_risk_per_trade * equity        # e.g. 0.05 × equity
    size_usdc = min(size_usdc, hard_cap)

# Profit-protection (trailing): never let one trade's worst-case loss (= full stake
# for a binary outcome) give back more than a fraction of accumulated realized profit.
profit_above_baseline = max(0.0, equity_hwm - realized_baseline)   # see note
if cfg.max_trade_loss_vs_profit_pct > 0 and profit_above_baseline > 0:
    size_usdc = min(size_usdc, cfg.max_trade_loss_vs_profit_pct * profit_above_baseline
                               + cfg.max_risk_per_trade * realized_baseline)

# Then the existing BP7 small-balance semantics still apply:
size_usdc = max(size_usdc, exchange_min)   # floor (small accounts still trade)
size_usdc = min(size_usdc, tradeable)      # never spend more than free pUSD
```

- This makes the stop-loss **structural**: the maximum loss of any single trade is
  bounded by `max_risk_per_trade × equity` (5%), so ~20 consecutive worst-case losses
  would be needed to halve the account — and the drawdown breaker (now correct, per
  RCA-1) stops it long before. One fixed trade can no longer "сжечь весь профит".
- `kelly_stake` keeps its internal `max_risk_per_trade` clamp (harmless — the hoisted
  cap is identical), but the cap is **no longer mode-dependent**.
- The exchange-minimum floor (BP3.1/BP7) still wins for tiny accounts: a sub-$100
  wallet may exceed 5% on a single $5 order — that is the intended, warned override
  (`concentration_over_60`), not a regression.

> **`realized_baseline`** = the equity recorded when the user last reset their risk
> baseline (registration, top-up, or manual override). Stored alongside the HWM.
> If unset, treat `realized_baseline = current equity` (no profit to protect yet).

#### Problem 3 — Manual override: "Снять блокировку" inline button

**Design — a one-tap consented reset of the drawdown baseline.**

1. **Button on the pause message.** The single pause notification (RCA-2) attaches:
   ```
   InlineKeyboardMarkup([[InlineKeyboardButton(
       "🔓 Снять блокировку", callback_data="unlock_drawdown")]])
   ```
   (Sent via `manage_positions._notify`; add an optional `reply_markup` arg, or send
   the keyboard through the bot directly. The user bot's `callback_handler`
   (`api/routers/telegram.py:1155`) is the dispatcher — add an `unlock_drawdown` branch.)

2. **Handler logic (`callback_data == "unlock_drawdown"`):**
   ```
   db_user = get_user_by_telegram_id(tg.id);  require ownership
   if db_user.risk_state not in ("paused_drawdown", "paused_daily_loss"):
       answer("Блокировка уже снята"); return
   equity = total_equity(...)                 # current cost-basis equity
   reset_risk_baseline(uid, equity)           # equity_hwm = equity  → drawdown resets to 0
   record_risk_override(uid)                  # risk_override_at=now, risk_override_count += 1
   resume_user_copying(uid)                   # copy_paused_until = NULL
   set_risk_state(uid, "active")              # NOT 'override_active' permanently — back to normal guard
   clear Redis keys: drawdown_alert:{uid}, risk_gate:{uid}:drawdown  # so future REAL DD can alert again
   edit message → "✅ Блокировка снята. Ты берёшь риск на себя. Точка отсчёта просадки сброшена."
   ```

3. **Consent / liability record.** `risk_override_at` (timestamptz) +
   `risk_override_count` (int) on `users` are the audit trail that the user accepted
   responsibility. Log `risk_override_manual` at `info` (user_id, old_hwm, new_hwm).
   Resetting the HWM to current equity makes the **current** equity the new peak, so
   the breaker measures drawdown *from here forward* — exactly "сбросить точку отсчёта".

4. **State after override:** `risk_state='active'`, `copy_paused_until=NULL`, HWM reset.
   The normal breaker is fully armed again from the new baseline (a *further* real
   drop still protects them). We do **not** disable the breaker — we only reset its
   reference point, per the user's consent.

**State machine (combined):**
```
            drawdown ≥ 25% (cost-basis)              cooldown elapsed
  active ──────────────────────────────▶ paused_drawdown ───────────────▶ active
    ▲                                         │
    │            tap "🔓 Снять блокировку"     │
    └─────────────────────────────────────────┘   (reset HWM = equity, record consent)
```

**Files:**
- `core/risk.py` — `total_equity()` (pure, cost-basis); breaker reads cost-basis equity;
  Gates 1–4 use cost-basis `open_exposure`.
- `worker/tasks/manage_positions.py` — `_update_hwm_and_check_breakers` rewritten as a
  compare-and-set state machine (notify once on edge, no re-pause, auto-resume on edge);
  `_notify` gains an optional `reply_markup` for the unblock button; `sync_positions`
  computes cost-basis equity (pass ledger cost via `get_open_trades_cost(uid)`).
- `worker/tasks/execute_copy.py` — apply the **unified per-trade risk cap** in both
  modes after sizing; compute equity cost-basis; **stop** sending the drawdown/daily-loss
  pause notification (enforce-only).
- `core/sizing.py` — unchanged math; the cap is now also enforced by the caller.
- `api/routers/telegram.py` — `unlock_drawdown` branch in `callback_handler`.
- `core/db/queries.py` — `set_risk_state`, `get_risk_state`, `reset_risk_baseline`,
  `record_risk_override`, `get_open_trades_cost(user_id) -> {token_id: size_usdc}`,
  `get_realized_baseline(user_id)`; `get_active_subscribers` already honors
  `copy_paused_until` (keep).
- `core/config.py` — new knobs (below).
- `migrations/013_risk_state_override.sql`.

**Migration 013 (idempotent):**
```sql
-- Blueprint 8: risk state machine + manual drawdown override + realized baseline.
alter table users add column if not exists risk_state text default 'active';
  -- active | paused_drawdown | paused_daily_loss
alter table users add column if not exists risk_override_at timestamptz;
alter table users add column if not exists risk_override_count int default 0;
alter table users add column if not exists realized_baseline double precision;
  -- equity snapshot used for profit-protection; reset on top-up / manual override
```

**Config (`core/config.py`):**
```python
# ── Blueprint 8: equity accounting + unified per-trade risk cap ───────────────
# Equity definition used by the drawdown breaker / HWM / exposure gates.
# "cost_basis" = open positions valued at filled entry cost (no phantom drawdown).
# "mark"       = legacy mark-to-market on curPrice (rollback only).
drawdown_equity_mode: str = "cost_basis"
# Apply max_risk_per_trade × equity as a hard ceiling in BOTH fixed and kelly modes.
enforce_risk_per_trade_cap: bool = True
# Profit-protection: a single trade's worst-case loss may not give back more than
# this fraction of accumulated realized profit above the baseline (0 disables).
max_trade_loss_vs_profit_pct: float = 0.50
```
(`max_risk_per_trade=0.05`, `max_drawdown_pct=0.25`, `drawdown_cooldown_sec=86400`
are reused unchanged.)

**Acceptance:**
- Opening a position no longer moves cost-basis equity ⇒ **no phantom drawdown**; the
  $18.07→$12.95 mark-to-market dip does **not** trip the breaker. The breaker fires
  only on **realized** losses (resolution/close), and the $18.07→$12.95 figure now
  shows only as an informational unrealized mark on the P&L screen.
- A drawdown pause produces **exactly one** notification (on the `active→paused_drawdown`
  edge), carries an unblock button, and is **not** repeated on subsequent sync cycles
  or by the execute path; it auto-resumes once after cooldown.
- In **both** `fixed` and `kelly` modes a single trade risks ≤ `max_risk_per_trade`
  (5%) of equity (modulo the warned sub-$100 exchange-minimum override); one lost trade
  can no longer wipe accumulated profit.
- Tapping "🔓 Снять блокировку" resets the HWM to current equity, records consent
  (`risk_override_at`, `risk_override_count`), clears the pause, returns `risk_state`
  to `active`, and re-arms the breaker from the new baseline; the action is logged and
  the message updates in place. Behaviour is restart-safe (state in the DB, not Redis).

---

### Blueprint 9 — Release-integrity RCA: silent callback crash + dead redemption safety-net ✅ IMPLEMENTED

**Symptoms (live test, real funds):**
1. **Telegram navigation dead.** From any deeper screen (settings / positions / wallet),
   tapping "🏠 Главное меню" does nothing — the bot ignores the press, no return to root.
2. **Late resolve + no claim.** A resolved Polymarket event sent "Событие выиграно! +1.25$"
   only ~24 h later, and **no USDC was credited** (deposit-wallet balance unchanged).

**✅ Confirmed by production logs (2026-06-29), do NOT re-diagnose from symptoms:**
```
# api container — once PER button press, swallowed (no error handler):
No error handlers are registered, logging exception.
  File "/app/api/routers/telegram.py", line 1169, in callback_handler
    if not settings.auto_copy_enabled:
UnboundLocalError: cannot access local variable 'settings' where it is not associated with a value

# worker container — every 600 s:
Task worker.tasks.backfill_legacy_redemptions ... raised unexpected:
  ImportError("cannot import name 'has_terminal_trade' from 'core.db' (/app/core/db/__init__.py)")
reconcile_settlements_done   checked=6 processed=0          # runs, but redeems nothing
# beat schedules every task correctly; all 4 containers Up; redis healthy.
```

**Infra reminder:** this stack is **Docker Compose, not PM2** (§7.1). Diagnose with
`docker compose logs --no-color {api|worker|beat}`, not `pm2 logs`.

#### Root cause — two code defects, one shared meta-cause (RELEASE DRIFT)

The running images execute **older code than the working tree**. Both fixes already exist
locally but were never committed / pushed / rebuilt, so `git pull` + `docker compose build`
on the VPS baked the stale versions. Evidence: `core/db/__init__.py` **already exports**
`has_terminal_trade` locally (lines 19/63) yet the container throws `ImportError`; and
`callback_handler` already carries the comment *"settings is already imported at module
level — no local re-import"* (`telegram.py:1579`) yet the container still shadows it. The
relevant files show as **untracked** in `git status` (`core/db/queries.py`, `core/risk.py`,
`core/config.py`, `api/routers/telegram.py`, `worker/tasks/manage_positions.py`,
`worker/tasks/execute_copy.py`, `migrations/013_*`).

**Defect A (Problem 1) — `settings` shadowed as a function-local.**
Python binds a name as **function-local for the entire scope** if it is assigned/imported
*anywhere* in that function. The deployed `callback_handler` re-imports `settings`
(`from core.config import settings`) inside one of its branches, so the **first** read at
`telegram.py:1169` (`if not settings.auto_copy_enabled:`, the `data == "menu"` branch)
raises `UnboundLocalError`. Because `query.answer()` already fired (`:1159`) **and there is
no `app.add_error_handler`** (`:359-377`), the exception is logged by PTB and the user just
sees a dead button. This breaks **every** callback path that touches `settings`
(menu / help / wallet / …), not only "Главное меню". The FSM hypothesis is wrong — there is
no `ConversationHandler`; navigation is a single global `CallbackQueryHandler`.

**Defect B (Problem 2) — the on-chain redemption safety-net is dead, and the win
notification is decoupled from the actual claim.**
1. `backfill_legacy_redemptions` (the catch-all that redeems neg-risk/legacy winners the
   Data API hides) imports `has_terminal_trade` from `core.db`
   (`manage_positions.py:740`), which the **deployed** `core/db/__init__.py` does not export
   → `ImportError` on **every** run → the task never does anything.
2. `reconcile_settlements` runs but `processed=0` (the 6 outstanding rows are not detected as
   resolved on-chain via `is_condition_resolved`, `manage_positions.py:614`).
3. The Data-API `redeemable` branch in `sync_positions` never fires for neg-risk (Blueprint 1).
4. The only path that *did* fire was `sync_positions`' **closed-positions branch**
   (`manage_positions.py:159-175`): it sends `_emit_win` (the "+$1.25") **but never dispatches
   a redeem**. That is where the late, content-rich message came from (~1 day later, when the
   position finally surfaced as closed in the Data API).
5. **Net:** no `redeemPositions` tx was ever sent → balance unchanged, exactly the symptom.

**Secondary defect (money-safety, independent of the deploy gap).** In `sync_positions`
(`:97-115`) the win **notification** and the **redeem** dispatch sit behind *separate* Redis
guards (`settle:` vs `redeem:`), and the closed-positions branch notifies with **no** redeem
at all. So a "выиграно" message is **never proof of an on-chain credit** — the core invariant
this blueprint must restore.

#### Design — three layers (do all three; Layer 1 is the hotfix, 2–3 are the architecture)

**Layer 1 — Immediate correctness (commit + redeploy the working tree).**
- Ensure `callback_handler` has **no** function-local rebinding of `settings`; rely on the
  module-level import (`telegram.py:16`). (Working tree already correct.)
- Ensure `has_terminal_trade` (+ `get_open_trade_by_token`, `mark_trade_closed`,
  `get_open_trades_cost`, …) exist in `core/db/queries.py` **and** are listed in
  `core/db/__init__.__all__`. (Working tree already correct.)
- Commit the untracked files, push, apply any unapplied migrations (008–012 per §7.4), then
  `docker compose build --no-cache api worker beat && docker compose up -d`.

**Layer 2 — Fail-loud, never-silent (the architectural fix that would have caught both).**
- **(2a) Global PTB error handler.** Register `app.add_error_handler(on_error)` on **both**
  bots. Log structured (`telegram_callback_error`, `data`, `user_id`) and reply with a safe
  fallback ("⚠️ Что-то пошло не так — открой /start"), so a handler exception can never again
  produce a silent dead button. Converts Problem 1 from invisible to logged + recoverable.
- **(2b) Import-time integrity self-check.** At api/worker boot **and** in CI, import every
  task module and assert that all names in `core.db.__all__` resolve
  (`python -c "import worker.tasks, api.routers.telegram"`). A missing export then fails the
  container HEALTHCHECK / CI **loudly at deploy time**, instead of crashing one periodic task
  forever. Prefer module-top imports over per-function `from core.db import …` so an
  ImportError surfaces at import, not silently per-run.
- **(2c) Crashed-periodic-task alerting.** A Celery `task_failure` signal handler (or a beat
  watchdog) escalates when a periodic task — especially `backfill_legacy_redemptions` /
  `reconcile_settlements` — raises repeatedly, so a dead safety-net pages us within minutes
  instead of rotting silently for a day.

**Layer 3 — Couple the win message to a CONFIRMED on-chain credit (money-safety invariant).**
- **Never** send "Выигрыш зачислён +$X" until `redeem_winnings` **and**
  `convert_dw_usdce_to_pusd` have **confirmed** (a tx hash + observed pUSD balance delta).
- On resolution detection, send an interim "🏁 Событие выиграно — оформляю зачисление…"
  (pending); send the final "✅ Выигрыш зачислён: +$X (pUSD)" **only** after the redeem+wrap
  relayer batch confirms. On failure, send "⏳ Выигрыш определён, зачисление задерживается —
  повторяю" and keep the row in the outstanding queue for idempotent retry — never a false
  success.
- Concretely: move the terminal win emit **into `redeem_position` after `redeem_done`**
  (gate it on `mark_trade_settled` success), and make `sync_positions`' closed-positions
  branch (`:159-175`) **not** emit a terminal win without also ensuring redemption
  (dispatch `redeem_position` / leave to reconcile). Keep `notify_once`/`claim` dedup so
  retries never double-notify. Result: **notification ⟺ credited**, always.

**Files:** `api/routers/telegram.py` (error handler; verify no `settings` shadow),
`api/main.py` + `worker/entrypoint.py` (boot self-check / healthcheck), `core/db/__init__.py`
(verify exports), `worker/tasks/manage_positions.py` (win emit moved post-redeem;
closed-branch must not falsely claim a win), `worker/celery_app.py` (`task_failure` alert
hook). **No new migration required.**

**Acceptance:**
- Every inline button works; any future handler exception shows a fallback **and** a
  structured log — never a dead button.
- A missing `core.db` export (or any task-module ImportError) **fails CI / the container
  healthcheck at deploy**, and pages on repeated runtime failure; the redemption safety-net
  can never again be silently disabled.
- A won position credits pUSD on-chain (**confirmed tx**) **before** any "зачислён" message;
  on redeem failure the user sees a pending/retry state, never a false success; **no win
  notification is ever sent without a corresponding confirmed credit.**

---

### Other known gaps (lower priority)

- **No automated tests / CI.** The new `core/sizing.py` and `core/risk.py` are pure functions — add
  `pytest` unit tests for them first (deterministic, no chain/API).
- **SELL copying not supported** — only BUY signals are mirrored.
- **Geoblock dependency** — `auto_copy_enabled` must only be ON where Polymarket trading is allowed.
- **Beat single-replica** requirement is operational, not enforced (2 beats double-fire).
- **Model A dormant** — `ws_listener.py`/`signals.py` not wired in; `scan_markets.py`/`poll_donors.py`
  off-schedule.
- **`wallet_filter_mode` defaults to `observe`** — buyer track-record logged but not enforced.
- **Single subscription tier** — no pricing/feature differentiation.
- **`get_closed_positions` capped at `limit=100`** — long histories truncated (affects winrate stats).

---

### Blueprint 10 — Delta-Drop Stop-Loss (simple, data-informed) 🟡 FINAL DESIGN / READY TO IMPLEMENT

**Product decision (Product Owner, 2026-06-30):** reject heavy quant (trailing stops, R/R entry
filters). Ship a **dumb, robust "Delta-Drop" stop**: if the outcome price falls by **X** from our
entry, sell the shares into the CLOB and exit. If price rises or holds, hold to resolution (that
branch is profitable). One knob, predictable behaviour.

#### Diagnosis recap (confirmed by prod logs + DB, do NOT re-diagnose)

**Finding 1 — there is no working stop; the bot is pure hold-to-resolution.** The only exit in
`sync_positions` is `cur_price < hard_stop_abs_price (0.07)` (`manage_positions.py:161-169`), and
it is disabled in the final `tp_sl_min_hours=4 h` (`:144-145`) and blind to neg-risk tokens that
delist from the Data API before reaching 0.07. A 12 h grep over `{hard_stop_triggered, sell_placed,
sell_order_failed, position_closed, no_bid}` returned **zero** matches and the ledger has
**`exit_tx = 0`** across all 368 rows → `close_position` was **never** invoked. The monitoring loop
itself was healthy (`sync_positions_done` every 120 s, no failures).

**Finding 2 (CRITICAL, blocks data-driven calibration) — the P&L ledger is corrupt.** Census of
`copy_trades` (368 rows): 343 `failed`, 19 `confirmed`/`result=NULL`, 5 `loss`, 1 `win`;
`result IS NULL` for 362/368; only 1 `redeem_tx`. The single `win` (id 695, entry 0.69) has a real
on-chain `redeem_tx` but `realized_pnl = -4.88` (booked as −99.9 %) because `realized_pnl =
credited − entry_cost` and `credited = bal_after − bal_before` measured ≈ $0 (the USDC.e→pUSD wrap
had not settled when the balance was read). **Losses book correctly** (via on-chain
`get_payout_numerator == 0`); **wins are systematically mis-booked or left NULL.** Net effect: the
ledger shows a false −$26 when the live portfolio is positive.

**Consequence for calibration:** `realized_pnl` is unusable, and the intra-trade **price path /
drawdown is not stored anywhere** (logs only have `order_placed` on entry + `sync_positions_done`
counts). Only `entry_price` is reliable (verified by arithmetic, e.g. id 714: 4.85/0.17 = 28.5
shares ✓). Therefore **X cannot be fitted to historical drawdown** — it is chosen from first
principles below and tuned later from the new `position_mark` logs.

#### Why a RELATIVE X (% of entry), not absolute cents

For a binary, the dollar loss when stopped is:
`loss_$ = shares · (entry − exit) = (size/entry) · (entry − exit) = size · (1 − exit/entry) = size · X`.
So a **relative** Delta-Drop caps the dollar risk at exactly **`X · size` regardless of entry
price** — the predictable, "dumb" property we want. Absolute cents give a floating risk that is
worse at low entries. → **use relative X.**

#### Approved parameters (PO sign-off 2026-06-30)

| Knob | Value | Rationale |
|---|---|---|
| `delta_drop_stop_pct` (**X**) | **0.30** | exit when `best_bid ≤ entry × 0.70`; caps loss at ≈30 % of stake. Wide enough to ride normal prediction-market noise on eventual winners, tight enough to convert −100 % wipeouts into −30 %. |
| `min_entry_price` | **0.40** (was 0.05) | **Do not enter outcomes priced < 0.40.** Solves the dead-zone case (e.g. the 0.17 loss) at the source: a 30 % drop from ≥0.40 exits at ≥0.28, where the book still has bids and the stop can actually fill. |
| `hard_stop_abs_price` | **0.07** (kept) | residual lower floor, runs alongside Delta-Drop. Harmless no-op in normal operation. |
| mark logging | **ON** | one `position_mark` log line per cycle → calibrate the optimal X from real drawdown after 1–2 weeks. |

**What X=0.30 would have done to the real (correctly-booked) losers, if the stop had filled:**
id 710 (0.77) −$5.03→≈−$1.51 · id 712 (0.59) −$4.96→≈−$1.49 · id 711 (0.526) −$4.75→≈−$1.43 ·
id 697 (0.42) −$2.02→≈−$0.61. The win (695 @ 0.69, resolved up) is never touched. (Assumes Step 2
live-book exit is in place.)

#### Step-by-step implementation

**Step 1 — Config (`core/config.py`).**
```python
# Blueprint 10 — Delta-Drop stop-loss (relative drop from entry)
delta_drop_stop_pct: float = 0.30          # exit when best_bid <= entry_price * (1 - X)
delta_drop_min_hold_sec: int = 600         # ignore the first 10 min (avoid entry-tick whipsaw)
log_position_marks: bool = True            # emit one position_mark line per open position per cycle
```
Also change the existing `min_entry_price: float = 0.05` → `0.40`. Keep `hard_stop_abs_price = 0.07`
and `tp_sl_min_hours` as-is (the Delta-Drop path below ignores the `tp_sl_min_hours` skip).

**Step 2 — Delta-Drop checker in `sync_positions`** (`worker/tasks/manage_positions.py`, replace the
hold/hard-stop block `:135-169`). For each open position with `shares > 0` and not `redeemable`:
1. `entry = float(p.get("avg_price") or 0)` (fallback to the ledger `entry_price` via
   `get_open_trade_by_token` if `avg_price` is missing — neg-risk safety).
2. `book = get_order_book(token_id)`; `best_bid = float(book.get("best_bid") or 0)`.
   **Use the live CLOB book, not the Data-API `cur_price`** (the book does not delist neg-risk early
   and is the price we can actually exit at).
3. **Mark logging** (when `log_position_marks`): emit
   `log.info("position_mark", token=token_id[:14], entry=entry, best_bid=best_bid,
   drop=round(1-best_bid/entry,3), hours=...)` — this is the dataset for future X tuning.
4. Enforce `delta_drop_min_hold_sec` (reuse the existing `_first_seen` map) to skip very fresh
   positions.
5. **Trigger:** if `entry > 0 and best_bid > 0 and (1 - best_bid/entry) >= delta_drop_stop_pct` →
   `_closing.add(ckey); close_position.delay(uid, token_id, "delta_drop_stop"); continue`.
   **Do NOT apply the `hours < tp_sl_min_hours: continue` skip on this path** (that guard is what
   let the loss ride to zero — Finding 1).
6. Leave the existing `hard_stop_abs_price (0.07)` check below as the residual floor (unchanged).

**Step 3 — Emergency sell = reuse existing `close_position`** (`manage_positions.py:262`). It already
places a marketable FAK SELL into the book at `best_bid` with `exit_slippage_pct` and books P&L
(Blueprint 6). Because `min_entry_price=0.40` keeps us out of dead books, the existing
`best_bid < 0.01 → no_bid` abort (`:303-327`) will not fire on a Delta-Drop exit. **No change to the
sell logic needed** — only add the `"delta_drop_stop"` label to `_notify_closed` (`:592-613`):
`"delta_drop_stop": "🛑 Стоп-лосс (−30% от входа)"`.

**Step 4 — Entry filter** is already enforced at `execute_copy.py:312-321` (and `detector.py:142`);
it reads `settings.min_entry_price`, so raising the config value to 0.40 is sufficient — no new code.

**Cadence note:** v1 runs inside the existing 120 s `sync_positions` loop (simplest, "dumb"). If a
faster reaction is needed later, lift the Delta-Drop block into a dedicated 30 s task — the logic is
identical.

#### Acceptance criteria / test plan
- Unit: pure helper `delta_drop_hit(entry, best_bid, X) -> bool` (deterministic, no I/O) with cases
  0.77→0.50 (hit), 0.77→0.60 (no), 0.69→1.0 (no, win), entry/bid ≤ 0 (no).
- Integration (staging): open a tiny position, push a synthetic book where `best_bid ≤ entry·0.70`,
  assert `delta_drop_triggered` + `position_closed reason=delta_drop_stop` + a non-empty `exit_tx`
  written to the ledger.
- Prod smoke: confirm `position_mark` lines appear every cycle, and `min_entry_price=0.40` rejects a
  sub-0.40 copy with `skip_price_out_of_range`.

> **Out of scope → Blueprint 11 (separate):** the P&L booking bug (Finding 2). `realized_pnl` must be
> sourced from the actual redeemed proceeds / `sell_position` fill, not a fragile wallet
> balance-delta. Until fixed, the daily-loss / drawdown circuit breakers (Blueprint 4/8) are fed
> phantom −100 % wins and cannot be trusted.

---

### Blueprint 12 — Close-handler import regression + withdrawal balance fix & FSM redesign ✅ IMPLEMENTED

> **Numbering note:** the prompt asked for "Blueprint 11", but Blueprint 11 already exists (the
> P&L-booking fix, IMPLEMENTED). This work is filed as **Blueprint 12** to avoid overwriting it.

Two unrelated prod incidents reported on 2026-06-30, bundled here because both are operational
breakages on the money path. Root causes were confirmed by code inspection — **no `pm2 logs`
were required** (see the optional verification commands at the end if you want runtime confirmation).

---

#### Part A — Bug A: "Закрыть #N" crashes with `ImportError`

**Symptom:** tapping **❌ Закрыть #1** alerts:
`cannot import name 'get_open_trade_by_token' from 'core.db' (/app/core/db/__init__.py)`.

**Exact crash path:**
1. `api/routers/telegram.py` (`close_` callback, ~L1435) dispatches `close_position.delay(uid, token_id, "manual")`.
2. The worker task `worker/tasks/manage_positions.py::close_position` runs and, inside its `try:` block, executes:

```381:381:worker/tasks/manage_positions.py
        from core.db import get_open_trade_by_token, mark_trade_closed
```

3. `get_open_trade_by_token` **is defined** in `core/db/queries.py` (L454) but is **not re-exported**
   from `core/db/__init__.py` — it is missing from both the `from core.db.queries import (...)` block
   and from `__all__`. (`mark_trade_closed` *is* exported, so only the first name fails.)
4. The `ImportError` is caught by `close_position`'s `except Exception as exc:` (L439), retried twice,
   and after `max_retries` the task notifies the user with `…<code>{str(exc)[:200]}</code>` — which is
   the exact ImportError text the user sees in the alert.

**This is a repeat of the Blueprint 9 Layer-1 class of bug** (`has_terminal_trade` was missing from
`core.db` exports). The package boundary `core/db/__init__.py` is hand-maintained and drifts from
`queries.py`.

**Fix (one file, two edits):** in `core/db/__init__.py`
1. Add `get_open_trade_by_token` to the `from core.db.queries import (...)` import block (alphabetical,
   next to `get_open_trades_cost`).
2. Add `"get_open_trade_by_token",` to `__all__`.

**Hardening (prevent the whole class, pick at least the first):**
- Extend the BP9 Layer-2 boot self-check `_check_core_imports()` to assert every name `close_position`,
  `redeem_position`, `reconcile_settlements`, and `backfill_legacy_redemptions` import from `core.db`
  (`get_open_trade_by_token`, `mark_trade_closed`, `mark_trade_settled`, `has_terminal_trade`,
  `get_outstanding_copy_trades`, `get_open_trades_cost`, `get_supabase`, …). Fail loud at boot, not
  on the money path.
- Add a trivial test `tests/test_db_exports.py` that asserts `import core.db` then `getattr(core.db, n)`
  for every `n in core.db.__all__`, **and** that every public `def` in `queries.py` used by workers is
  present in `__all__`. This makes the drift a red CI, not a prod alert.

**Acceptance (Bug A):** with the export added, `python -c "from core.db import get_open_trade_by_token"`
succeeds; closing a live position writes a non-empty `exit_tx` + `realized_pnl` to the `copy_trades`
row and the user gets "✅ Позиция закрыта" instead of the ImportError alert.

---

#### Part B — Bug B: withdrawal reads/sends the wrong balance + UX redesign

**Symptom:** user has **$7.00 USDC**, taps Вывод, and gets
*"Недостаточно средств: доступно $0.00, запрошено $7.00"*.

**Root cause (two compounding defects):**

1. **Wrong wallet for the "available" figure.** The amount step in
   `api/routers/telegram.py` (~L1134–1139) computes the balance from the **EOA**:
   `addr = db_user.get("wallet_address")` → `get_balances(addr)["total_usdc"]`. But in V2 the user's
   liquid funds live as **pUSD in the deposit wallet** (`deposit_wallet_address`), which `get_balances`
   only reads when called on that wallet. So the EOA shows ≈$0 even though the trading wallet holds $7.

2. **Wrong asset checked at transfer time + silent conversion failures.**
   `worker/tasks/wallet_ops.py::withdraw_funds` tries to assemble **native USDC on the EOA** by:
   pull pUSD from deposit wallet → EOA (relayer), unwrap pUSD→USDC.e, swap USDC.e→native USDC — but
   **every leg is wrapped in a swallowing `try/except` that only logs a warning**. If the relayer pull
   or a swap fails (e.g. no POL for gas, relayer busy), execution proceeds anyway to
   `transfer_usdc(..., use_bridged=False)`, whose own balance guard (`core/polygon.py` L267–270) finds
   **0 native USDC** and raises the exact *"доступно $0.00, запрошено $7.00"* message. The user's hunch
   ("checks locked pUSD vs free USDC") is the right shape: the *displayed* balance and the *actually
   transferable* balance are computed from different wallets/assets and never reconciled.

3. **No pre-flight validation.** The amount is accepted with only a `>= $1` check; the real
   insufficiency surfaces deep inside an on-chain revert instead of an upfront, friendly message.

**Design principle — ONE source of truth for "withdrawable":**

Add a single helper (put it in `core/polygon.py` or a thin wrapper in the telegram router) and use it
for **both** the displayed "Доступно" **and** the pre-flight validation **and** the task's own guard:

```python
def withdrawable_usdc(db_user: dict) -> float:
    """Total liquid USD the bot can actually convert + send out, across both wallets.
    = deposit-wallet pUSD (trading collateral)  +  EOA (pusd + usdc_e + usdc native)."""
    eoa = db_user.get("wallet_address")
    dw  = db_user.get("deposit_wallet_address")
    dw_pusd = get_balances(dw).get("pusd", 0.0) if dw else 0.0
    e = get_balances(eoa) if eoa else {}
    return dw_pusd + e.get("pusd", 0.0) + e.get("usdc_e", 0.0) + e.get("usdc", 0.0)
```

This is exactly the pool `withdraw_funds` already tries to mobilize, so display, validation, and
execution can never disagree again.

**New withdrawal FSM (replaces the current address → amount → confirm flow).**
State key: `context.user_data["withdraw_step"]`. The existing handlers in `telegram.py` (cmd_withdraw
~L617, the `withdraw_start`/`withdraw_cancel`/`withdraw_confirm` callbacks ~L1363, and the text router
~L1117) are refactored — do **not** add a parallel flow.

| # | State | Bot action | On valid input → |
|---|-------|-----------|------------------|
| 1 | `start` (button `withdraw_start` or `/withdraw`) | reset any stale `withdraw_*` keys; set step=`address`; prompt: **"Введите адрес кошелька (Polygon) для вывода:"** + ❌ Отмена | `address` |
| 2 | `address` (text in) | `from core.polygon import is_valid_address`; reject non-`0x…`/bad-length with a re-prompt | store `withdraw_to`; step=`amount` |
| 3 | `amount` prompt | compute `avail = withdrawable_usdc(db_user)`; prompt: **"Введите сумму для вывода (Доступно: {avail:.2f} USDC)"** + ❌ Отмена | — |
| 4 | `amount` (text in) | parse (`$`,`,`→`.`); validate `>= MIN_WITHDRAW_USDC` (1.0) **and `<= avail`** (recompute `avail` fresh here — this is the pre-flight gate). On `> avail`: friendly "Недостаточно средств. Доступно: {avail:.2f} USDC" + re-prompt | store `withdraw_amount`; go to execute |
| 5 | execute | edit message to **"⏳ Выполняю вывод…"**; clear `withdraw_*` step keys; `withdraw_funds.delay(uid, to, amount)` | task runs |
| 6 | task success | `transfer_usdc` waits for the receipt; task notifies **"✅ Вывод успешно завершён.\nТранзакция: https://polygonscan.com/tx/{tx}"** | done |

> **Confirm step:** the prompt's 6-step spec omits the old "✅ Подтвердить" screen, so this design
> goes straight from amount → execution. If you'd rather keep an explicit money-movement confirmation
> (recommended for safety), insert a one-tap confirm between steps 4 and 5 showing amount + address;
> it does not change any of the balance logic below. **Decision left to the implementer; default to
> following the 6-step spec (no confirm).**

**Fixes inside `withdraw_funds` (`worker/tasks/wallet_ops.py`) — fail loud, never on bad data (§5.2):**
1. **Pre-flight guard:** recompute `avail = withdrawable_usdc(user)` at task start; if `amount > avail`,
   notify a clear "Недостаточно средств: доступно ${avail:.2f}" and return **before** any on-chain
   action. (Belt-and-suspenders with the UI gate, in case balances moved.)
2. **POL/gas pre-check** on the EOA before conversions; if `< ~0.02 POL`, notify "⛽️ Недостаточно POL
   на газ" and abort (mirror `wrap_collateral`).
3. **Stop swallowing conversion errors.** The relayer pull / unwrap / swap legs must surface failures:
   on any leg failure, abort with a specific message ("не удалось вывести средства из торгового
   кошелька / конвертация не удалась — попробуйте позже") instead of falling through to a misleading
   "$0.00" transfer revert.
4. **Confirm the tx before declaring success.** `core/polygon.py::transfer_usdc` currently sends the
   raw tx and returns **without waiting for the receipt**. Route it through the existing `_exec_tx`
   helper (or add `wait_for_transaction_receipt` + `status == 1` check) so the "✅ Вывод успешно
   завершён" message + Polygonscan link is sent **only after on-chain confirmation** (matches the
   prompt's "после успешного подтверждения").

**Consistency cleanup (optional but recommended):** the wallet/positions/menu screens
(`telegram.py` L150–182, L573–599, L1295–1300) compute "available" several different ways
(`total_usdc`, `dw_pusd + on_eoa`, etc.). Point them at `withdrawable_usdc()` too so every screen shows
the same number the user can actually withdraw.

**Config:** add `MIN_WITHDRAW_USDC = 1.0` to `core/config.py::Settings` (no magic numbers, §5.6).
No DB migration required.

**Acceptance / test plan (Bug B):**
- Unit: `withdrawable_usdc` returns `dw_pusd + eoa(pusd+usdc_e+usdc)` for mocked balances (deposit-only,
  EOA-only, split, empty).
- FSM (staging): a user whose $7 sits as deposit-wallet pUSD sees **"Доступно: 7.00 USDC"** at step 3;
  entering `7` passes the pre-flight gate; entering `8` is rejected upfront (no on-chain call).
- Integration (staging, tiny amount): full path pulls pUSD→EOA, converts, transfers native USDC, waits
  for receipt, and the success message contains a valid `polygonscan.com/tx/…` link; the position/wallet
  screens then show the reduced "Доступно".
- Negative: simulate a failed swap leg → user gets a specific failure message, **never** a misleading
  "$0.00 available", and no partial silent drain.

---

#### Optional runtime verification (only if you want logs, not required)

```bash
# Bug A — confirm the import actually fails in the deployed image
pm2 logs nexa-worker --lines 200 --nostream | grep -iE "get_open_trade_by_token|close_position_failed|ImportError"
docker exec -it <worker_container> python -c "from core.db import get_open_trade_by_token; print('OK')"

# Bug B — confirm where the $7 actually is and which wallet the flow read
pm2 logs nexa-worker --lines 300 --nostream | grep -iE "withdraw_failed|withdraw_dw_pull_failed|Недостаточно"
# (substitute the user's deposit + EOA addresses to compare pUSD vs native USDC balances)
```

---

### Blueprint 13 — Sizing-mode hierarchy fix, zero-edge skip, max-daily-trades limit & stop-loss invariant ✅ IMPLEMENTED

> **Audit context (2026-06-30, Lead Quant):** three risk-management defects/gaps found during the
> Kelly audit. 13.1 fixes a settings-priority bug that silently disables per-user Kelly and a
> dangerous "no-edge → trade anyway" fallback. 13.2 adds a user-controllable daily trade cap.
> 13.3 records the (already-correct) stop-loss invariant so it is never regressed by sizing work.
> **No code in this pass — design only.** Code snippets below are the implementation contract.

#### Diagnosis recap (confirmed by code inspection — do NOT re-diagnose)

**Bug 13.1a — global ENV silently overrides per-user Kelly.** `execute_copy_trade` resolves the
effective mode correctly (`user_sizing_mode = user.get("sizing_mode") or settings.sizing_mode`,
`execute_copy.py:128`) and branches on it (`:152 if user_sizing_mode == "kelly":`). **But**
`kelly_stake` itself re-checks the *global* config and bails:

```52:53:core/sizing.py
    if cfg.sizing_mode != "kelly":
        return 0.0  # caller falls back to legacy flat cap
```

Global default is `sizing_mode: str = "fixed"` (`config.py:249`). So a user who enables Kelly in
Telegram enters the `kelly` branch, calls `kelly_stake`, gets `0.0` (because *global* mode is
`fixed`), and is dropped into the no-edge fallback → **fixed sizing**. The per-user choice is
silently ignored unless `SIZING_MODE=kelly` is also set in the environment. This is a coupling bug:
mode selection is the **caller's** job; `kelly_stake` must be **pure math**.

**Bug 13.1b — "no edge" falls through to a fixed-size trade.** When Kelly legitimately returns `0`
(`q_hat <= p`, i.e. no measurable edge over the market price), the bot does **not** skip — it trades
the flat cap anyway:

```173:177:worker/tasks/execute_copy.py
        else:
            # Kelly returned 0 (no edge detected) — fall back to fixed cap
            size_usdc = min(user_max, depth_cap) if depth_cap > 0 else user_max
            log.info("sizing_kelly_no_edge_fallback", fixed_cap=round(size_usdc, 2),
                     user_id=user.get("id"))
```

This defeats the entire point of Kelly: a user who chose Kelly is telling us "only bet when there is
an edge". Trading the flat $25 on a zero-edge signal is the opposite of that contract. The same is
true when Kelly returns a positive but **sub-$5** stake: the downstream `size_usdc = max(size_usdc,
exchange_min)` floor (`execute_copy.py:235`) silently inflates a $0.80 Kelly stake back up to the
$5 platform minimum — again overriding the math.

**Gap 13.2 — no per-user daily trade cap.** On a high-activity whale day a user can be copied into
dozens of positions; there is no way to say "max N entries/day". `max_open_positions`
(`config.py`) caps *concurrent* positions globally, not *daily entries* per user.

**Invariant 13.3 — stop-loss is already sizing-agnostic; lock it in.** The Delta-Drop stop
(Blueprint 10) lives in `sync_positions` (`manage_positions.py`) and triggers purely on
`entry_price` vs live `best_bid`. It never reads `sizing_mode`. `entry_price` is persisted on every
`copy_trades` row for both modes (BP1, `execute_copy.py:431`). So Kelly vs Fixed cannot change stop
behaviour today — but nothing *documents* or *tests* that, so a future sizing change could regress
it. This blueprint records the invariant + a guard test.

---

#### Blueprint 13.1 — Correct sizing-mode hierarchy + zero-edge skip

**Priority rule (authoritative):** `users.sizing_mode` (DB) **>** `settings.sizing_mode` (global ENV).
The global value is only a **default for users who never chose**. An explicit per-user choice always
wins. Encoded as: `effective_mode = user.sizing_mode if user.sizing_mode in {"fixed","kelly"} else settings.sizing_mode`.

**Behaviour matrix (the contract):**

| `effective_mode` | Kelly math result | Action |
|---|---|---|
| `kelly` | stake ≥ `exchange_min` (after user/depth caps) | **trade** the Kelly stake |
| `kelly` | `0` (no edge, `q_hat ≤ p`) | **SKIP** → `risk_gate:zero_edge` |
| `kelly` | `> 0` but `< exchange_min` | **SKIP** → `risk_gate:zero_edge` (do **not** floor up to $5) |
| `fixed` | n/a (Kelly never called) | trade the flat `min(user_max, depth_cap)` cap |

Fixed sizing is used **only** when the user explicitly chose `fixed`. There is no "Kelly fell back to
fixed" path anymore.

**Step 1 — make `kelly_stake` pure math (`core/sizing.py`).** Delete the global-mode early return
(lines 52–53). Mode selection no longer belongs here. Keep the genuine "no input" guards
(`equity <= 0`, `free_pusd <= 0`, `p` out of `(0,1)`) and the no-edge guard (`q_hat <= p → 0.0`).
Update the docstring: `kelly_stake` now returns the recommended stake assuming the caller has
already decided to size with Kelly; `0.0` means **"no edge — do not bet"**, not "use fixed".

**Step 2 — rewrite the sizing block (`execute_copy.py:124–182`).**

```python
# ── BP13.1: resolve effective sizing mode (User DB > global ENV) ──────────
user_mode = user.get("sizing_mode")
effective_mode = user_mode if user_mode in ("fixed", "kelly") else settings.sizing_mode

user_max  = float(user.get("max_position_usdc") or 25)
depth_cap = float(signal.get("max_copy_usdc") or signal.get("size_usdc") or 0)

if effective_mode == "kelly":
    from core.sizing import kelly_stake
    from core.wallet_score import score_wallet
    try:
        score = score_wallet(signal.get("source_wallet") or signal.get("whale_wallet") or "")
    except Exception:
        score = None
    k_stake = kelly_stake(
        p=float(signal.get("price") or 0), score=score,
        consensus=int(signal.get("consensus") or 1),
        equity=equity, free_pusd=tradeable, cfg=settings,
    )
    size_usdc = min(k_stake, user_max)
    if depth_cap > 0:
        size_usdc = min(size_usdc, depth_cap)
    # BP13.1b: no edge OR sub-minimum Kelly stake → SKIP, never floor up, never fall back to fixed.
    if k_stake <= 0 or size_usdc < settings.exchange_min_order_usdc:
        log.info("skip_zero_edge", user_id=user_id, k_stake=round(k_stake, 4),
                 capped=round(size_usdc, 4), exchange_min=settings.exchange_min_order_usdc)
        return {"skipped": True, "reason": "risk_gate:zero_edge"}
    log.info("sizing_kelly", stake=round(k_stake, 2), capped=round(size_usdc, 2),
             equity=round(equity, 2), user_id=user_id)
else:
    size_usdc = min(user_max, depth_cap) if depth_cap > 0 else user_max
    score = None
    log.debug("sizing_fixed", cap=round(size_usdc, 2), user_id=user_id)
```

**Step 3 — protect the exchange-min floor from resurrecting a skipped Kelly stake.** The existing
`size_usdc = max(size_usdc, exchange_min)` (`:235`, `:261`, `:334`) is correct for **fixed** mode (a
small fixed cap should still execute at $5). It is only dangerous on the Kelly path, and Step 2
already `return`s before reaching it when the Kelly stake is sub-minimum. **No change to the floor
lines** — the early `return` is the guard. (Document this dependency in a comment so the floor is not
later moved above the Kelly skip.)

**Step 4 — `zero_edge` is a silent skip, not a notification.** Mirror the existing
`risk_gate:{gate}` skips (`:362-367`): log + return, **no Telegram message** (a "no edge" non-event
must not spam the user). It surfaces only in logs / metrics.

**Acceptance criteria (13.1):**
- `kelly_stake` unit tests no longer depend on `cfg.sizing_mode`; add a case asserting a positive
  stake is returned with `cfg.sizing_mode="fixed"` (proves decoupling).
- Integration: user `sizing_mode='kelly'`, `SIZING_MODE=fixed` in env, edge present → trade is
  **Kelly-sized** (regression test for 13.1a).
- Integration: user `sizing_mode='kelly'`, signal with `q_hat ≤ p` → `{"skipped": True,
  "reason": "risk_gate:zero_edge"}`, **no order placed, no fixed fallback** (13.1b).
- Integration: user `sizing_mode='kelly'`, Kelly stake `$0.80` (< $5) → skipped `zero_edge`, **not**
  floored to $5.
- Integration: user `sizing_mode='fixed'` → unchanged flat-cap behaviour, no Kelly call.

---

#### Blueprint 13.2 — Per-user "Max daily trades" limit

**13.2.1 — Database (migration `014_max_daily_trades.sql`).** New nullable column; `NULL` = unlimited
(preserves current behaviour for every existing user).

```sql
-- Blueprint 13.2: per-user daily trade cap. NULL = unlimited (default, legacy behaviour).
-- Counted against copy_trades rows CREATED in the current UTC day that actually entered the
-- market (status <> 'failed'). Apply in Supabase SQL editor. Idempotent.
alter table users add column if not exists max_daily_trades int;
```

Add to §6.9 pending-migrations list as **014** and to the §6.10 migration order. Update
`core/db/models.py` `User` reference (add `max_daily_trades: Mapped[int | None]`). No global config
knob is required; optionally add `default_max_daily_trades: int | None = None` to `Settings` if a
fleet-wide default is ever wanted (default `None` = off).

**13.2.2 — DB helper (`core/db/queries.py`).** Mirror `get_daily_realized_pnl` but key on
`created_at` and the **UTC calendar day** (not a trailing 24 h window — the user's mental model is
"per day", resets at 00:00 UTC).

```python
def get_daily_trade_count(user_id: int) -> int:
    """Number of copy_trades this user ENTERED since 00:00 UTC today.

    Counts rows that reached order placement (status != 'failed'). copy_trades rows are only
    inserted once the bot commits to placing an order (execute_copy.py), so skipped signals
    never consume a slot. 'failed' rows (order never landed) are excluded.
    """
    sb = get_supabase()
    since = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0).isoformat()
    res = (
        sb.table("copy_trades")
        .select("id", count="exact")
        .eq("user_id", user_id)
        .neq("status", "failed")
        .gte("created_at", since)
        .execute()
    )
    return int(res.count or 0)
```

**13.2.3 — Risk gate (fail-fast, before sizing & RPCs).** This cap must reject **before** the
expensive balance/positions/order-book reads, so it is **not** folded into `check_risk_gates`
(which runs late, post-book). Instead add an early guard in `execute_copy_trade`, immediately after
the `copy_paused_until` check (`:114`) and before the balance check (`:117`):

```python
# ── BP13.2: per-user daily trade cap (fail-fast, UTC day) ─────────────────
max_daily = user.get("max_daily_trades")
if max_daily is not None:
    try:
        from core.db import get_daily_trade_count
        used = get_daily_trade_count(user_id)
        if used >= int(max_daily):
            log.info("skip_max_daily_trades", user_id=user_id, used=used, limit=int(max_daily))
            _notify_daily_limit(user["telegram_id"], used, int(max_daily))  # throttled, see below
            return {"skipped": True, "reason": "risk_gate:max_daily_trades"}
    except Exception:
        log.warning("daily_trade_count_failed", user_id=user_id)  # fail-open: never block on a count error
```

- **Counting semantics:** the slot is consumed when a `copy_trades` row is inserted
  (`execute_copy.py:420`), i.e. the moment we commit to placing. The check reads the count *before*
  this trade is inserted, so `used >= max_daily` is the correct "already at limit" test.
- **Known race (accepted, documented):** two signals fanned out concurrently can both observe
  `used = max-1` and both proceed, overshooting by one. This is a soft risk cap, not a financial
  invariant; an atomic counter is out of scope. Note it in the code comment.
- **Reset:** purely time-based — the next 00:00 UTC the `since` boundary moves and the count resets.
  No cron, no stored counter to clear.
- **Notification:** `_notify_daily_limit` is **throttled** via `core.cache.notify_once`
  (key `daily_limit:{telegram_id}`, ttl ≈ `lowbal_alert_throttle_sec`) so a busy day produces at
  most one "daily limit reached" nudge, mirroring `_notify_low_balance` (BP2).

**13.2.4 — Telegram UI state machine (`api/routers/telegram.py`).** Mirror the existing
`max_position_usdc` template+custom pattern (`_settings_kb` + `setmax_*` + `awaiting_max_pos`).

*Keyboard (`_settings_kb`)* — add a `max_daily_trades` parameter and a new template row with a ✓ on
the active value:

```python
def _settings_kb(copy_active, current_max, sizing_mode="fixed", max_daily=None):
    def _daily_label(n):
        mark = " ✓" if max_daily == n else ""
        return f"{n}/день{mark}"
    off_label = "♾ Без лимита" + (" ✓" if max_daily is None else "")
    ...
    # new rows (placed after the position-size rows, before the sizing toggle):
    [InlineKeyboardButton(_daily_label(1),  callback_data="setdaily_1"),
     InlineKeyboardButton(_daily_label(5),  callback_data="setdaily_5"),
     InlineKeyboardButton(_daily_label(10), callback_data="setdaily_10")],
    [InlineKeyboardButton("✏️ Свой лимит", callback_data="setdaily_custom"),
     InlineKeyboardButton(off_label,        callback_data="setdaily_off")],
```

Every existing `_settings_kb(...)` call site (`:854`, `:1237`, `:1519`, `:1566`, `:1586`) must pass
`max_daily=db_user.get("max_daily_trades")`.

*Callback handler* — add a `data.startswith("setdaily_")` branch alongside `setmax_` (`:1523`):

```python
if data.startswith("setdaily_"):
    suffix = data[len("setdaily_"):]
    if suffix == "off":
        update_user(tg_user.id, {"max_daily_trades": None})
        ... re-render settings with confirmation "♾ Лимит снят" ...
        return
    if suffix == "custom":
        context.user_data["awaiting_daily_limit"] = True
        context.user_data["awaiting_max_pos"] = False   # mutually exclusive FSM flags
        ... prompt: "Введи число сделок в день (1–100), 0 = без лимита" ...
        return
    val = int(suffix)                                    # 1 | 5 | 10
    update_user(tg_user.id, {"max_daily_trades": val})
    ... re-render settings, answer "✅ Лимит: N/день" ...
    return
```

*Custom text input* — add a block in the message handler mirroring `awaiting_max_pos`
(`:1206-1238`). **Guard mutual exclusion:** the handler checks `awaiting_daily_limit` and
`awaiting_max_pos` as separate branches; setting one flag clears the other (shown above) so a typed
number is never ambiguous.

```python
if context.user_data.get("awaiting_daily_limit"):
    context.user_data["awaiting_daily_limit"] = False
    clean = text.strip().replace(",", "")
    try:
        n = int(float(clean))
    except ValueError:
        ... reply "⚠️ Введи целое число, напр. 5" ...; return
    if n <= 0:
        update_user(tg_user.id, {"max_daily_trades": None})   # 0 / negative = unlimited
        ... reply "♾ Лимит снят — без ограничения по сделкам в день" ...
    elif n > 100:
        ... reply "⚠️ Максимум 100 сделок в день"; return
    else:
        update_user(tg_user.id, {"max_daily_trades": n})
        ... reply f"✅ Лимит: {n} сделок в день (UTC)" ...
    ... re-render settings keyboard with new max_daily ...
    return
```

*FSM summary:* `idle → [tap ✏️ Свой лимит] → awaiting_daily_limit → [valid int] → idle (saved)`;
template buttons (`setdaily_1/5/10/off`) write immediately with no intermediate state. `awaiting_*`
flags are mutually exclusive — entering either clears the other.

*Display* — surface the limit in `_settings_text` and the dashboard (`_dashboard_text:204`):
`f"🔁 Лимит/день: {max_daily}" if max_daily else "🔁 Лимит/день: ♾"`.

**Acceptance criteria (13.2):**
- Migration applies idempotently; existing users read `NULL` → unlimited (no behaviour change).
- `get_daily_trade_count` counts only today-UTC, non-`failed` rows; excludes yesterday and `failed`.
- With `max_daily_trades=1` and one entered trade today, the next signal returns
  `{"skipped": True, "reason": "risk_gate:max_daily_trades"}` and places **no** order; the check
  runs **before** any balance/book RPC (assert via call order / logs).
- After 00:00 UTC rollover the count resets and trading resumes with no manual action.
- Telegram: tapping `5/день` persists `max_daily_trades=5` and shows ✓; `✏️ Свой лимит` → typing
  `7` persists 7; `0` or `♾ Без лимита` clears to `NULL`; daily-limit nudge is throttled to ≤1.

---

#### Blueprint 13.3 — Stop-loss consistency invariant

**Invariant (must hold for all future sizing work):** the unified **Delta-Drop stop-loss**
(Blueprint 10) applies to **every** open position with `shares > 0`, evaluated solely on
`entry_price` vs the live CLOB `best_bid` at the **price-tracking layer** (`sync_positions` in
`worker/tasks/manage_positions.py`). The stop is **completely independent of how the entry size was
computed** — Kelly or Fixed. Position size affects only the *dollar* magnitude of a stopped loss
(`loss_$ = size · X`, see BP10), never *whether* or *when* the stop fires.

**Why it already holds (do not "fix"):**
- `sync_positions` reads `entry` from the position `avg_price` (fallback: ledger `entry_price` via
  `get_open_trade_by_token`) and `best_bid` from the live book. It **never reads `sizing_mode`**.
- `entry_price` is persisted on **every** `copy_trades` row at insert time (BP1,
  `execute_copy.py:431`) regardless of sizing mode, so the stop has its reference price in both modes.
- The trigger `(1 - best_bid/entry) >= delta_drop_stop_pct` contains no size/mode term.

**Guardrails to add so it stays true:**
- **Test (pure):** extend BP10's `delta_drop_hit(entry, best_bid, X)` unit suite with an explicit
  comment/case asserting the function signature takes **no size and no mode** argument — the type
  system enforces sizing-independence.
- **Test (integration):** open two positions at the **same `entry_price`**, one created in Kelly
  mode and one in Fixed mode; push a synthetic book with `best_bid ≤ entry·(1-X)`; assert **both**
  fire `position_closed reason=delta_drop_stop`. Sizing mode must not appear in the assertion path.
- **Doc lock:** a one-line comment at the Delta-Drop trigger in `manage_positions.py`:
  `# BP13.3 invariant: stop is sizing-mode-agnostic — do NOT branch on users.sizing_mode here.`
- **Coupling caution:** BP13.1 makes Kelly able to **skip** entry (`zero_edge`) and BP13.2 can cap
  daily entries — both reduce *how many* positions exist, but once a position is open it is governed
  by the **same** stop. No stop-loss code reads the daily-cap or sizing fields.

---

#### Cross-cutting notes
- **Config defaults unchanged:** global `sizing_mode` stays `"fixed"` (conservative). The 13.1 fix
  means a per-user `kelly` choice now actually takes effect without touching the env.
- **Rollback:** 13.1 is behaviour-preserving for `fixed` users; to revert, restore the
  `kelly_stake` global-mode early return. 13.2 is fully gated by `max_daily_trades IS NULL` (off by
  default), so shipping the migration alone changes nothing until a user sets a limit.
- **Skip-reason taxonomy:** two new `reason` values join the existing `risk_gate:*` family —
  `risk_gate:zero_edge` (13.1) and `risk_gate:max_daily_trades` (13.2) — so dashboards/log greps
  already filtering `risk_gate:` pick them up for free.

---

### Blueprint 14 — Kelly edge-degeneracy fix + AI-analysis pipeline redesign ✅ IMPLEMENTED

> **Audit context (2026-06-30, Lead Quant):** two production problems on PolyMind AI. 14.A — Kelly
> sizing looks fixed (~$6.2 every executed trade) and only ever fires on expensive favorites.
> 14.B — the LLM risk analysis is internally inconsistent (emoji/verdict/score disagree) and
> content-free.
>
> **Implemented 2026-06-30:** 14.A shipped as `core/sizing._damp_edge()` +
> `kelly_edge_damping_gamma` config knob, **default 0.0 (OFF — legacy undamped formula,
> behaviour unchanged on deploy)**. Stress-testing the fix before shipping the default ON
> revealed a severe side effect: at `gamma=1.0` (full damping), the *maximum possible* stake
> (best wallet quality, max consensus, edge at the 0.06 cap) is `kelly_lambda · kelly_edge_cap ·
> equity` — independent of price. At current prod equity (~$124) that ceiling is **$1.86**,
> below `exchange_min_order_usdc` ($5) — meaning full damping makes Kelly skip **every** signal
> until equity exceeds ≈$333 (`5 / (kelly_lambda · kelly_edge_cap)`), or `kelly_base_edge` /
> `kelly_edge_cap` are raised to compensate. Per §5.6 (strategy/money-moving changes need a
> conservative default), this is shipped **off by default** — operators must explicitly set
> `KELLY_EDGE_DAMPING_GAMMA` after either growing equity past the threshold or raising the edge
> caps, and validate on the `kelly_stake` logs that real trades still clear the minimum before
> enabling fleet-wide. 14.B shipped as `core/risk_label.py` (single source of truth for
> emoji/verdict, shared by `ai_filter._broadcast` and `execute_copy._notify`) + strict
> `json_schema` structured output in `worker/tasks/ai_filter.py`
> (`risk_score`/`signal_type`/`thesis`/`caution`) + migration 015 (`trade_signals.ai_signal_type`).
> 14.B is live unconditionally (no flag) — it only changes how the existing AI message is
> composed, not how money moves.

---

#### Part A — Kelly edge degeneracy (the real cause of "fixed-looking" sizing)

**Diagnosis (confirmed from 30+ prod `kelly_stake` log lines, 2026-06-30 15:36–20:13):**

The user hypothesis ("risk gates inflate a $1 Kelly stake up to the $5 minimum") is **DISPROVEN** —
BP13 works: sub-$5 Kelly stakes log `skip_zero_edge` and are skipped, `sizing_kelly_no_edge_fallback`
count is 0. The true defect is deeper.

**Empirical fact:** `q_hat − p ≡ 0.0214` for *every* signal, across all prices observed
(0.126, 0.37, 0.39, 0.513, 0.67, 0.79, 0.82, 0.83, 0.905, 0.91, 0.938, 0.94, 0.95). The estimated
edge is a **flat constant**, independent of market or price.

**Mechanism.** With a constant edge `E = 0.0214`, the Kelly fraction collapses to a pure function of
price: `f_kelly = E / (1 − p)`, then `f_final = min(λ·f_kelly, max_risk_per_trade)`. With
`λ=0.25`, `max_risk_per_trade=0.05`, equity ≈ $124:

| Price band | `f_final` | stake | Outcome |
|---|---|---|---|
| `p < 0.867` | < 0.0403 | < $5 | **skip** (`skip_zero_edge`) — every cheaper signal |
| `0.867 ≤ p < 0.893` | 0.0403–0.05 | $5–$6.2 | rare (logs: `capped=5.1`, `5.2`) |
| `p ≥ 0.893` | **clamped to 0.05** | ≈ 5%·equity ≈ **$6.2** | every executed trade |

So the bot **only trades expensive favorites (p ≳ 0.89), and every one clamps to the 5% hard cap** —
hence the near-identical $6.18–$6.33 sizes. Quarter-Kelly (`λ`) is dead weight: on every *executed*
trade the 5% cap binds, not Kelly.

**Root cause.** `edge_hat = kelly_base_edge · quality · consensus_mult` (`core/sizing.py:74-75`)
encodes only *wallet trust*, never *market mispricing*, and is a **flat additive bump** on top of the
price the whale paid. Two compounding failures:
1. **Additive edge explodes at high p.** A flat +0.0214 added to 0.95 yields a tiny *relative* edge
   but `f_kelly = E/(1−p)` blows up as `p→1`, so Kelly always maxes out on favorites — the exact
   "penny-collecting, high tail-risk" trades. This is adverse selection baked into the math.
2. **`quality` is currently pinned constant** (single dominant whitelisted wallet and/or unscored
   default `quality=0.5`), so edge does not differentiate signals at all.

**Step 0 — confirm the `quality`/`consensus` decomposition (one command, before coding).** `kelly_edge`
is logged at DEBUG; raise the worker to `--loglevel=debug` briefly and capture:
```bash
docker compose logs --since 10m worker | grep "kelly_edge"   # edge_hat, quality, consensus
```
Confirm whether `quality` is constant (single-wallet/unscored) or genuinely flat from scoring.

**Step 1 — make edge price-aware (kill the high-p explosion).** The additive model is the core flaw.
Scale the edge so the Kelly fraction does **not** diverge as `p→1` — a 2pp edge on a 0.95 favorite
must be worth far less risk-adjusted stake than 2pp on a 0.55 coin-flip. Concretely, damp `edge_hat`
by a concave factor of `(1−p)` (design target; tune the exponent on the `position_mark`/`kelly_edge`
dataset):
```
edge_hat_eff = edge_hat · (1 − p)^γ      # γ ∈ [0.5, 1.0]; γ=1 fully cancels the 1/(1−p) blow-up
f_kelly      = edge_hat_eff / (1 − p)
```
With `γ=1` this makes `f_kelly = edge_hat` (flat in p) → favorites no longer auto-max the cap, and
mid-price signals with real edge can clear the minimum. This directly counters the penny-collecting
adverse selection surfaced above.

**Step 2 — make `quality` actually vary.** Ensure `signal["source_wallet"]` is reliably populated
(via `wallet_score.resolve_buyer`) so `score_wallet` returns a real per-wallet `resolved_count > 0`;
otherwise every signal falls to the `quality=0.5` default and edge can never differentiate. Add a
`kelly_edge` log assertion / metric on the share of signals scored vs. defaulted.

**Step 3 — stop the 5% cap from being the de-facto sizer.** Once Steps 1–2 let `f_final` land below
`max_risk_per_trade` on most trades, λ (quarter-Kelly) governs sizing again and stakes genuinely
vary. The 5% cap returns to being a *safety ceiling*, not the primary knob. Keep `max_risk_per_trade`
as-is; verify post-fix that executed trades are **not** all pinned at `f_final = 0.05`.

**Acceptance criteria (14.A):**
- Post-fix `kelly_stake` logs show `q_hat − p` **varying** across signals (no longer a constant).
- Executed trades show a **spread** of `f_final` values (not all `0.05`); stakes are not all ≈5%·equity.
- The bot enters at least some non-favorite (p < 0.89) signals when a real edge exists.
- Pure unit test for the new `edge_hat_eff`/`f_kelly` helper: assert `f_kelly` is non-increasing-then-
  bounded in p (no divergence at p→1), and 0 when `q_hat ≤ p`.

> **Note:** 14.A is a *strategy* change (moves money differently) → gate behind a config flag with a
> conservative default and validate on the `kelly_edge` dataset before enabling fleet-wide, per §5.6.

---

#### Part B — AI-analysis pipeline redesign

**Diagnosis (confirmed from code, `worker/tasks/ai_filter.py`).** The LLM returns **both** a free-text
`verdict` *and* a `score`, independently:
```43:44:worker/tasks/ai_filter.py
{{"score": <целое 1-10, 1=низкий риск>, "verdict": "<Сильный сигнал|Умеренный|Рискованно>",
```
while the bot derives the emoji from `score`:
```128:128:worker/tasks/ai_filter.py
    risk_icon = "🟢" if score <= 4 else ("🟡" if score <= 6 else "🔴")
```
→ `score=3` (bot → 🟢) + hallucinated `verdict="Рискованно"` ⇒ **"🟢 Рискованно · риск 3/10"**. Three
sources of truth (emoji, verdict, number) are unsynchronised. The `reason` text also just restates the
probability/time — no analytical value.

**Principle: `risk_score` is the single source of truth.** The LLM returns *only* a number + analysis.
The emoji **and** the verdict label are **derived deterministically by the bot** from `risk_score`.
The LLM never emits emoji or verdict.

**B.1 — Structured Outputs (strict JSON schema).** Replace `response_format={"type":"json_object"}`
with a strict `json_schema` so the model cannot return extra/contradictory fields:
```json
{
  "name": "trade_analysis",
  "strict": true,
  "schema": {
    "type": "object",
    "additionalProperties": false,
    "required": ["risk_score", "signal_type", "thesis", "caution"],
    "properties": {
      "risk_score":  { "type": "integer", "minimum": 1, "maximum": 10 },
      "signal_type": { "type": "string",
        "enum": ["penny_collecting","value_bet","momentum","longshot_size","consensus_stack","coin_flip"] },
      "thesis":  { "type": "string", "maxLength": 180 },
      "caution": { "type": "string", "maxLength": 120 }
    }
  }
}
```
- `risk_score` — the only driver of colour/verdict.
- `signal_type` — machine tag of the trade's structure (analytics + future filters).
- `thesis` — the core insight; `caution` — the main risk. No emoji, no number-restating.

**B.2 — Deterministic mapping (bot, single helper `risk_label(score)`).** Used by *both*
`ai_filter._broadcast` and `execute_copy._notify` so the two paths render identically:
```
1–2  → 🟢  "Сильный сетап"
3–4  → 🟢  "Уверенный сигнал"
5–6  → 🟡  "Умеренный риск"
7–8  → 🟠  "Высокий риск"
9–10 → 🔴  "Опасная зона"
```
Emoji, label and number now come from one integer → they cannot disagree. (Replaces the inline
`risk_icon` ternary at `ai_filter.py:128` and the equivalent in `execute_copy._notify`.)

**B.3 — New system prompt (draft).** Forbid number-restating; force hedge-fund-analyst reasoning:
```
Ты — старший аналитик хедж-фонда, специализация — рынки предсказаний (Polymarket).
Тебе дают сделку проверенного прибыльного кита из белого списка. Оцени КАЧЕСТВО СДЕЛКИ
как инвестиционный кейс, а не описывай вводные.

ЗАПРЕЩЕНО:
- Пересказывать цифры («цена 0.94, до закрытия 3 часа») — пользователь видит их сам.
- Общие фразы («высокая вероятность, но есть риск») — это мусор.
- Эмодзи, вердикты, слово «риск N/10» — это проставит система.

ТРЕБУЕТСЯ распознать СТРУКТУРУ сделки и дать инсайт уровня деска:
- Дорогой фаворит (0.90+) на крупный размер → «сбор копеек»: малый апсайд, жирный tail-risk.
- Низкая вероятность (<0.30) + агрессивный размер кита → возможный инсайд / асимметрия:
  кит видит то, чего не видит рынок. Подсвети это.
- Консенсус нескольких китов в одном исходе → усиление, но проверь скученность.
- Тонкий запас времени до резолва → нет места для разворота, риск выше.
- Цена ~0.50 → монетка; нужна причина, почему это не шум.

Верни строго JSON по схеме: risk_score (1=низкий риск сделки, 10=высокий), signal_type,
thesis (главный тезис), caution (главный риск). Русский, без воды, тон — аналитик, не маркетолог.
```
Set `temperature=0.2` (was 0.3) for verdict stability. On invalid JSON / schema refusal → fallback
`risk_score=5`, `thesis="ИИ временно недоступен"`, label/colour from the mapping. Never crash.

**B.4 — Persistence & migration.** Store `ai_score`, `ai_signal_type`, `ai_reason` on
`trade_signals`. New column needs migration **015**: `alter table trade_signals add column if not
exists ai_signal_type text;` (add to §6.9 / §6.10 with the implementation PR).

**Acceptance criteria (14.B):**
- Emoji, verdict label and number are always consistent (derived from one `risk_score`) — no more
  "🟢 Рискованно · риск 3/10".
- `thesis` never merely restates price/time; it names the structural pattern (e.g. penny-collecting,
  longshot-size) — spot-check 10 live analyses.
- Strict-schema call: malformed model output cannot leak emoji/verdict; fallback path verified.
- Both the signals-mode broadcast and the copied-trade notification use the shared `risk_label`.

---

#### Cross-cutting
- **The two problems are linked:** 14.A's degenerate Kelly funnels the bot into high-p penny-
  collecting favorites — precisely the trades 14.B's analyst prompt is built to flag as high tail-
  risk. Fixing 14.A widens the signal set; 14.B makes the per-trade risk legible.
- **Migrations:** 14.B adds **015** (`trade_signals.ai_signal_type`). 14.A adds a Kelly config flag
  (no schema change). Apply 015 with the BP14 code.
- Both parts are strategy/UX changes → gate behind config flags with conservative defaults (§5.6) and
  validate on real data before fleet-wide enable.

---

### Blueprint 15 — Onboarding & Trust UX Redesign (Progressive Disclosure) 🟡 FINAL DESIGN / READY TO IMPLEMENT

**Symptom (conversion drop at onboarding).** In the custodial copy-trading deployment
(`AUTO_COPY_ENABLED=true`), the very first message after `/start` creates a wallet and immediately
fires `_new_user_text()` (`api/routers/telegram.py` L267–282) — a wall of *"пополни USDC / пополни POL
/ зарегистрируй кошелёк"*. For a cold Web3 user this reads as a scam: an unknown bot demanding money
before delivering any value. They don't deposit, and they leave.

**Goal.** Replace "money-first" with **value-first, money-when-ready** (Progressive Disclosure):
welcome → explain the value → default into a **risk-free signals (demo) mode** → and only reveal
deposit/network/USDC instructions when the user *taps a button to opt in* to auto-trading.

> **Scope.** This blueprint redesigns the **`AUTO_COPY_ENABLED=true` (custodial)** onboarding only.
> The `AUTO_COPY_ENABLED=false` deployment is already a pure non-custodial signals bot with a soft
> intro (`_signals_welcome_text`, L308) and is the *tone reference* for this redesign.

---

#### ⚠️ Honesty constraint — DO NOT call the wallet "non-custodial"

The prompt asks to mention "кошелёк некастодиальный (если это так)". **It is NOT.** Per §1 and §5.1 the
bot **generates and holds the user's private key (encrypted)** — this is a **custodial** model. Claiming
"non-custodial" would be a false safety claim and is **forbidden** (§5.1, §5.7). Use only **truthful**
trust levers instead:

1. **"Выводи в любой момент"** — true: `/withdraw` (BP12) sends funds to any Polygon address the user
   names, no approval from us. This is the strongest *honest* fear-reducer.
2. **"Старт без депозита"** — the demo/signals mode genuinely requires $0 on-chain.
3. **"Только сеть Polygon"** — concrete, protects the user from losing funds on the wrong chain.
4. **"Только USDC, газлесс-регистрация"** — bot auto-converts USDC→pUSD; registration costs the user
   no gas (relayer-deployed deposit wallet, see §2 / `_register_deposit_wallet`).
5. **Optional, only if implemented:** "ключ хранится в зашифрованном виде" — true (Fernet at rest),
   but do **not** oversell it as "только у тебя".

---

#### Part A — Progressive-disclosure model (3 layers)

| Layer | When shown | Contains | Money mentioned? |
|---|---|---|---|
| **L0 Welcome / Demo** | immediately on first `/start` (wallet silently created in background) | value pitch + the trust quote + the offer to start in signals mode | **No** |
| **L1 Upsell gate** | only after user taps **🚀 Перейти к автоторговле** | the 3 honest trust facts (withdraw-anytime / Polygon-only / USDC-only) + a single "show me the address" CTA | network/asset rules, **no address yet** |
| **L2 Funding steps** | only after user taps **✅ Показать адрес для пополнения** | deposit address + numbered steps + 🔐 register button (the *content* of the old `_new_user_text`, but earned, not pushed) | **Yes — fully** |

The deposit address / network / "buy USDC" instructions live **only in L2**. They are never the first
message and never appear unless the user explicitly walks L0 → L1 → L2.

---

#### Part B — Onboarding FSM

**State source of truth.** Derive the stage from existing fields (mirrors how `_checklist()` already
derives status) — **no migration required**:

```python
# Proposed helper in telegram.py — pure function over the db_user row.
def _onboarding_stage(db_user: dict) -> str:
    if not db_user.get("wallet_address"):
        return "fresh"                      # /start not finished creating wallet
    if db_user.get("is_signal_only", True): # NEW DEFAULT: True for new users
        return "demo"                       # L0 — risk-free signals, no money ask
    if not db_user.get("wallet_registered"):
        return "intent"                     # opted into autotrade, not yet registered
    # funded? reuse _checklist math (dw_pusd + on_eoa) >= MIN_USDC_READY
    return "active"                         # auto-trading
```

> **One small behavioural change required:** new users must default to **`is_signal_only = True`**.
> Today new rows default to copy-mode. Set `is_signal_only=True` at wallet-creation time in `cmd_start`
> (and as the column default in a future migration if convenient — not blocking).

| # | State | Entry trigger | Bot shows | Exit → |
|---|-------|--------------|-----------|--------|
| 1 | `fresh` | `/start`, no wallet | "⏳ Готовлю твой аккаунт…" then silently `generate_wallet()`; set `is_signal_only=True` | → `demo` |
| 2 | `demo` | wallet ready / `onb_signals` / `/start` returning demo user | **L0 welcome** (`_onboarding_welcome_text`) + `_onboarding_kb()` | tap 🚀 → `intent` · tap 🎬 → stays `demo`, confirms signals on |
| 3 | `intent` | `onb_autotrade` | **L1 upsell** (`_autotrade_gate_text`) + `_autotrade_gate_kb()` | tap ✅ → `funding` view · tap ↩️ → `demo` |
| 4 | `funding` (view, not a stored state) | `onb_fund_steps` | **L2 funding** (`_funding_steps_text` = deposit addr + steps) + 🔐 register | tap 🔐 → existing `register` flow |
| 5 | `register` | `register` callback (unchanged, BP9/BP12) | gasless deploy → "✅ Кошелёк готов" | on success set `is_signal_only=False`; → `active` |
| 6 | `active` | registered + (auto-detected funds) | normal `_dashboard_text` + `_main_kb` (existing) | — |

**Seamless demo → autotrade hand-off.** The user never re-enters anything: tapping **🚀 Перейти к
автоторговле** in `demo` flips intent, L1 reassures, L2 reveals the address, 🔐 register reuses the
existing gasless flow and **flips `is_signal_only=False` on success** — at which point the dashboard
becomes the full auto-trading view. Going back is always one tap (**↩️ Вернуться в режим сигналов**),
which never deletes the wallet — it just sets `is_signal_only=True`.

> **Subscription gate (product decision, flag it).** In copy-mode deployments, signal broadcasts are
> gated by an active subscription. To make the demo *genuinely* risk-free and not a dead end, **default
> recommendation:** grant new demo users a small free sample — e.g. the next **3 signals** or a **48h
> window** (Redis counter keyed by `telegram_id`, no schema change). If the business refuses a free
> tier, L0's copy must instead say signals require a subscription (still framed as "watch us trade
> before funding"). **Default to the 3-signal sample; leave the final call to the operator.**

---

#### Part C — Concrete message drafts & inline-button structure (start screen)

All texts are HTML parse-mode, Russian (matches the existing bot voice). These are **drafts ready to
paste** into new builders in `telegram.py`.

**L0 — Welcome / Demo (`_onboarding_welcome_text`)** — replaces `_new_user_text` as the first message:

```
🧠 <b>Добро пожаловать в PolyMind AI!</b>

Мы копируем сделки проверенных <b>китов Polymarket</b> — трейдеров, которые
годами стабильно зарабатывают на прогнозах. Наш ИИ следит за их крупными
покупками 24/7 и присылает разбор каждой.

━━━━━━━━━━━━━━━━━━━━━
🎬 <b>Начни без риска</b>
━━━━━━━━━━━━━━━━━━━━━
Мы понимаем, что доверие нужно заслужить. Начни с <b>режима сигналов</b> —
посмотри, как мы торгуем, без риска для твоих средств.

Ты будешь получать те же сигналы по китам с ИИ-анализом, что и платные
подписчики, а решение о деньгах примешь позже — когда сам увидишь результат.

👇 С чего начнём?
```

`_onboarding_kb()` — inline keyboard (primary CTA first, money CTA secondary):

```python
InlineKeyboardMarkup([
    [InlineKeyboardButton("🎬 Смотреть сигналы (без риска)", callback_data="onb_signals")],
    [InlineKeyboardButton("🚀 Перейти к автоторговле",       callback_data="onb_autotrade")],
    [
        InlineKeyboardButton("❓ Как это работает", callback_data="help"),
        InlineKeyboardButton("🛡 Это безопасно?",  callback_data="onb_trust"),
    ],
])
```

**`onb_trust` — trust FAQ (fear-killer), shown on demand:**

```
🛡 <b>Часто волнует — отвечаем честно</b>

💸 <b>Деньги выводятся в любой момент.</b>
Кнопка «💸 Вывод» отправит USDC на любой твой адрес Polygon. Мы не держим
твои средства в заложниках и не требуем разрешений.

🌐 <b>Только сеть Polygon.</b>
Пополняй строго в сети Polygon (не Ethereum / BSC / Arbitrum) — иначе монеты
уйдут в чужую сеть и потеряются. Это главное правило безопасности.

🪙 <b>Только USDC, и старт без газа.</b>
Достаточно обычного USDC — бот сам сконвертирует его в торговый баланс.
Регистрация кошелька газлесс: POL на старте не нужен.

🎬 <b>Старт — бесплатный и без депозита.</b>
Режим сигналов не требует ни цента на счёте. Сначала смотришь, потом решаешь.
```
Buttons: `[🎬 Остаться на сигналах → onb_signals]` · `[🚀 Перейти к автоторговле → onb_autotrade]`

> Note: this text deliberately says **"деньги выводятся в любой момент"** and **"мы не держим в
> заложниках"** (true), and **never** the word "некастодиальный" (false). Keep it that way.

**`onb_signals` — confirm demo mode (sets `is_signal_only=True`, no deposit):**

```
🎬 <b>Режим сигналов включён</b>

Теперь ты получаешь сигналы по китам с ИИ-анализом — <b>без единого цента на
счёте</b>. По каждому сигналу: событие, исход, цена входа кита, объём и оценка
риска от ИИ + ссылка на рынок.

Когда захочешь, чтобы бот торговал это <b>за тебя автоматически</b> —
нажми «🚀 Перейти к автоторговле». Это займёт пару минут.
```
Buttons: `[🚀 Перейти к автоторговле → onb_autotrade]` · `[⭐️ Подписка → subscription]` · `[🏠 Меню → menu]`

**L1 — Autotrade upsell gate (`_autotrade_gate_text`)** — shown on `onb_autotrade`. **Still no address:**

```
🚀 <b>Автоторговля — сделки копируются сами</b>

В этом режиме бот сам открывает позиции на <b>твоём личном кошельке</b>, как
только кит заходит крупно. Перед первым пополнением — 3 факта, чтобы было
спокойно:

🔑 <b>Кошелёк под твоим контролем.</b> Вывести средства можно в любой момент
кнопкой «💸 Вывод» — без подтверждений с нашей стороны.
🌐 <b>Только сеть Polygon.</b> Не Ethereum, не BSC — иначе деньги уйдут в чужую
сеть.
🪙 <b>Только USDC.</b> Бот сам сконвертирует в торговый баланс (pUSD). Газ (POL)
для старта не нужен — регистрация газлесс.

Готов? Покажу адрес и пошаговую инструкцию по пополнению.
```

`_autotrade_gate_kb()`:

```python
InlineKeyboardMarkup([
    [InlineKeyboardButton("✅ Показать адрес для пополнения", callback_data="onb_fund_steps")],
    [InlineKeyboardButton("💸 А как выводить деньги?",        callback_data="onb_withdraw_info")],
    [InlineKeyboardButton("↩️ Вернуться в режим сигналов",    callback_data="onb_signals")],
])
```

**L2 — Funding steps (`_funding_steps_text(addr)`)** — shown on `onb_fund_steps`. This is the *only*
place the address + deposit steps appear (refined `_new_user_text`):

```
🚀 <b>Пополнение — 3 шага</b>

📬 <b>Твой адрес для пополнения (USDC, сеть Polygon):</b>
<code>{addr}</code>

━━━━━━━━━━━━━━━━━━━━━
1️⃣ Отправь <b>USDC</b> на адрес выше — <b>строго в сети Polygon</b>
2️⃣ Нажми <b>🔐 Зарегистрировать кошелёк</b> (газлесс, 30–60 сек)
3️⃣ Готово — бот начнёт копировать крупные сделки китов
━━━━━━━━━━━━━━━━━━━━━

⚠️ <b>Только сеть Polygon</b> — не Ethereum, не BSC, не Arbitrum!
ℹ️ Бот сам сконвертирует USDC в торговый баланс (pUSD). Вывести средства можно
в любой момент кнопкой «💸 Вывод».
```

Buttons:

```python
InlineKeyboardMarkup([
    [InlineKeyboardButton("🔐 Зарегистрировать кошелёк", callback_data="register")],
    [
        InlineKeyboardButton("🔄 Проверить баланс", callback_data="wallet_balance"),
        InlineKeyboardButton("💸 Как вывести",      callback_data="onb_withdraw_info"),
    ],
    [InlineKeyboardButton("↩️ Назад", callback_data="onb_autotrade")],
])
```

**`onb_withdraw_info` — withdraw reassurance (links to the BP12 flow):**

```
💸 <b>Вывод средств — в любой момент</b>

Нажимаешь «💸 Вывод» → вводишь свой адрес Polygon → сумму → подтверждаешь.
Бот сконвертирует pUSD обратно в USDC и отправит на указанный адрес; в ответ
придёт ссылка на транзакцию в Polygonscan.

Никаких блокировок и периодов ожидания — деньги твои.
```
Buttons: `[🚀 Продолжить к пополнению → onb_fund_steps]` · `[🏠 Меню → menu]`

---

#### Part D — Wiring (files & touch-points; implement later)

1. **`cmd_start` (L485–562).** For `AUTO_COPY_ENABLED=true`:
   - On wallet creation, set `is_signal_only=True` (default into demo).
   - Returning users: branch on `_onboarding_stage(db_user)` → `demo` shows `_onboarding_welcome_text`
     + `_onboarding_kb`; `active` shows the existing `_dashboard_text` + `_main_kb`.
   - **Delete the immediate `_new_user_text` push.** Its content survives, relocated to L2.
2. **New callbacks in `callback_handler` (L1333+):** `onb_signals`, `onb_autotrade`, `onb_trust`,
   `onb_fund_steps`, `onb_withdraw_info`. `onb_signals` sets `is_signal_only=True`; `onb_autotrade`
   only renders L1 (does **not** flip the flag yet — the flag flips to copy-mode on **register
   success**, so an abandoned funnel never silently arms auto-trading).
3. **`register` success (L1428–1438 and `cmd_register` L963–968):** on success
   `update_user(tg_user.id, {"is_signal_only": False})` so the hand-off to `active` is automatic.
4. **Dashboard (`_dashboard_text` L222 / `_checklist` L177):** when stage==`demo`, suppress the
   funding checklist entirely and show a one-line demo banner + the single 🚀 CTA. The checklist only
   makes sense once the user has opted into autotrade.
5. **`_main_kb` (L50):** for demo users, surface **🚀 Перейти к автоторговле** as the top row instead
   of wallet/positions clutter (those are meaningless with $0 and no positions).
6. **Reuse, don't fork:** registration, wrap, withdraw, subscription flows are unchanged (BP9/BP12).
   This blueprint adds *only* the pre-funding disclosure layer and the demo default.

**Config (§5.6, no magic literals):** add `ONBOARDING_FREE_SIGNALS = 3` (or `ONBOARDING_DEMO_HOURS`)
to `core/config.py::Settings` if the free-sample option is taken. No DB migration is required for the
FSM (stage is derived); the only data change is the `is_signal_only=True` default for new users.

---

#### Acceptance criteria (Blueprint 15)

- A brand-new `/start` (copy-mode deployment) shows the **value-first L0 welcome** containing the exact
  trust quote — and **no deposit address, network instructions, or "пополни" wording**.
- The deposit address and funding steps appear **only** after `onb_autotrade` → `onb_fund_steps`
  (two explicit taps). They never appear in L0/L1.
- New users land in `is_signal_only=True` (demo); the dashboard hides the funding checklist until they
  opt in.
- **🚀 Перейти к автоторговле** → L1 reassurance → L2 address → 🔐 register → on success
  `is_signal_only` flips to False and the full auto-trading dashboard renders — with no re-entry of any
  data. **↩️ Вернуться в режим сигналов** returns to demo without destroying the wallet.
- No user-facing copy claims the wallet is "non-custodial"; only truthful levers (withdraw-anytime,
  Polygon-only, USDC-only, gasless, no-deposit demo) are used.
- (If free-sample taken) a demo user with no subscription receives the configured sample of real
  signals, then is prompted to subscribe — proving "watch before you fund" end to end.

---

## 5. Coding Guidelines (STRICT — safety first)

These rules are non-negotiable. Money and private keys are at stake.

### 5.1 Private-key protection (highest priority)
- Private keys exist in two forms only: **encrypted at rest** (`wallet_private_key_enc`, Fernet via
  `ENCRYPTION_KEY`) and **decrypted in-memory at the moment of signing**. Never widen this.
- **NEVER** log, print, return in an API/Telegram response, store unencrypted, or put a decrypted key
  (or `ENCRYPTION_KEY`) into Redis, Supabase, error messages, or AI prompts.
- Decrypt only via `core.wallet.decrypt_key` and only inside the function that signs. Do not pass
  decrypted keys across task boundaries or persist them.
- Never include key material, full addresses with secrets, or seed phrases in logs. Truncate
  addresses in logs (existing code uses `addr[:10]`/`[:12]`).
- Treat `.env`, `ENCRYPTION_KEY`, `SUPABASE_SERVICE_KEY`, `BUILDER_*`, `RELAYER_*` as secrets. Never
  commit them; never echo them.

### 5.2 Fail safe — never drain a deposit on API desync
- Polymarket Data/Gamma/CLOB APIs lag and occasionally return stale or partial data. **Assume any
  external call can fail, time out, or lie.** Wrap every external call in try/except and **fail
  CLOSED** (skip the action) rather than trading on bad data.
- Before any BUY: re-check the order book (price band + fillable depth) and the deposit-wallet pUSD
  balance. If balance/depth checks fail, **skip** — do not place the order.
- Always cap order size by BOTH `max_position_usdc` AND order-book depth (`book_safe_frac`). Never
  remove these caps.
- Use **FAK marketable orders with slippage protection** (`order_slippage_pct` / `exit_slippage_pct`)
  via `_worst_buy_price`/`_worst_sell_price`. Never place naked market orders without a worst-price
  bound.
- **Idempotency is mandatory.** Celery tasks retry. Guard against double-execution with: the
  `copy_trades` (user_id, signal_id) existence check, the in-memory `_seen` map, the `trade_signals`
  DB dedup, and Redis `notify_once`/`claim`. Any new money-moving task MUST be idempotent.
- For redemption, **never trust the API `negativeRisk` flag** — detect market type on-chain
  (`redeem_winnings` already does this). A wrong path silently redeems $0.

### 5.3 Concurrency & async in the worker (gevent)
- Workers run in a **gevent pool with no asyncio event loop in the task thread**. To send Telegram
  messages from a task, use **`asyncio.run(_send())`** — **NEVER `asyncio.get_event_loop()`** (it
  raises in non-main threads and silently drops notifications). This bug has bitten us repeatedly.
- The relayer allows **one in-flight action per deposit wallet**. Serialize on-chain actions per
  wallet; on `"wallet busy"` errors, retry with a delay (see `scripts/verify_v2.py redeem`).

### 5.4 Data isolation
- Always scope DB reads/writes by `user_id` / `telegram_id`. Never let one user's data, balance,
  positions, or wallet leak into another user's view or trade.
- A signal fans out to subscribers individually; each `execute_copy_trade` operates on exactly one
  user. Keep it that way.
- Use the supabase client in `core/db/queries.py`. Do not open raw DB connections or scatter table
  names across the codebase — add a query helper instead.

### 5.5 Trade logging & observability
- Use **`structlog`** (`log = structlog.get_logger(__name__)`) with **structured key/value** fields,
  not f-strings. Example: `log.info("copy_trade_ok", user_id=uid, order_id=oid, fill=status)`.
- Worker runs at `--loglevel=info`; `log.debug` is invisible in prod — put diagnostics needed in prod
  at `info`.
- Every money-moving action must leave an audit trail: a `trade_signals` row, a `copy_trades` row with
  status transitions (`executing → placed → confirmed/unfilled/failed`), and an `info` log line.
- Never log secrets (see §5.1). Truncate addresses, tx hashes, and token ids in logs.

### 5.6 Config & constants
- All tunable thresholds live in `core/config.py` (`Settings`). **Do not hardcode magic numbers** in
  task logic — add a setting with a clear comment and a safe default.
- Contract addresses come from `core/clob.py` / `core/polygon.py`. Import them; never re-declare.
- New behavior that moves money or changes strategy should be **gated behind a config flag** with a
  conservative default (off / smallest size).

### 5.7 General
- Match existing style: small focused functions, early returns, `try/except` around all I/O, no
  narrating comments (comment only non-obvious intent/constraints).
- Schema changes go in a new `migrations/00X_*.sql` (idempotent SQL), and the corresponding helper in
  `core/db/queries.py`. Keep `core/db/models.py` updated as reference.
- Prefer editing existing modules over adding new ones. Do not introduce new external dependencies
  without a strong reason.
- After editing, mentally run the failure cases: API down, partial fill, retry, restart, Redis empty,
  insufficient balance. The bot must degrade safely in all of them.

---

## 6. Database Schema (Supabase / Postgres)

**Runtime access is via the Supabase client** (`core/db/queries.py`) — there is **no ORM at runtime**.
`core/db/models.py` (SQLAlchemy) is a **reference that has drifted** from the live schema; the live
schema is the **base tables + the applied `migrations/00X_*.sql` files**. Where they disagree, the
**migrations + actual `queries.py` usage win** (noted inline below).

Migrations are applied **manually** in the Supabase SQL editor, in order, and are idempotent
(`create table if not exists` / `add column if not exists`).

### 6.1 `users` — subscribers (custodial wallets + subscription state)

| Column | Type | Notes |
|---|---|---|
| `id` | int PK | internal id (FK target for `copy_trades.user_id`) |
| `telegram_id` | bigint unique | Telegram user id |
| `username` | text | Telegram @username (migration 003); indexed `lower(username)` |
| `wallet_address` | text(42) | user EOA (signer) |
| `wallet_private_key_enc` | text | **Fernet-encrypted** EOA private key — NEVER expose/log (§5.1) |
| `deposit_wallet_address` | text | V2 deposit wallet (ERC-1967 proxy, order `funder`) — migration 005 |
| `deposit_wallet_deployed` | bool | proxy deployed on-chain — migration 005 |
| `wallet_registered` | bool | on-chain approvals done — migration 001 |
| `clob_api_key` / `clob_secret` / `clob_passphrase` | text | per-user CLOB creds — migration 001 (treat as secrets) |
| `sub_tier` | text | `'free'` = inactive; any non-`free` (runtime uses `'active'`) = active |
| `sub_expires_at` | timestamptz | subscription expiry; gate = non-`free` AND `> now()` |
| `copy_active` | bool | custodial copy enabled (checked only when `auto_copy_enabled`) |
| `max_position_usdc` | float | per-position cap (default 25.0) — current fixed-sizing input |
| `balance_usdc` | double precision | cached balance for the deposit monitor — migration 001 |
| `equity_hwm` | double precision | per-user equity high-water mark (Blueprint 4) — migration 010 |
| `copy_paused_until` | timestamptz | risk-pause expiry; fan-out + pre-trade gate honor it — migration 010 |
| `sizing_mode` | text | per-user `fixed`/`kelly` override (Blueprint 3) — migration 011 |
| `risk_state` | text | `active`/`paused_drawdown`/`paused_daily_loss` state machine (Blueprint 8) — migration 013 |
| `risk_override_at` / `risk_override_count` | timestamptz / int | manual-unblock consent audit trail (Blueprint 8) — migration 013 |
| `realized_baseline` | double precision | equity baseline for profit-protection cap (Blueprint 8) — migration 013 |
| `is_signal_only` | boolean | Signal-Only Mode: deliver signals, never trade on-chain (BP14) — migration 014 |
| `subscription_notified_expired` | boolean | dedup flag for the "subscription expired" alert (BP14) — migration 014 |
| `created_at` | timestamptz | |

> `models.py` lists `privy_user_id` (legacy/unused) and a `SubTier` enum (`basic/pro/whale`) that the
> runtime does **not** use — production is a **single `'active'` tier**.

### 6.2 `tracked_wallets` — Model B whitelist (whales to copy) — migration 007

| Column | Type | Notes |
|---|---|---|
| `id` | bigint identity PK | |
| `address` | text unique | whale wallet (lowercased on write) |
| `label` | text | display name |
| `active` | bool | only `active=true` are polled; indexed |
| `added_at` | timestamptz | |

### 6.3 `trade_signals` — detected copy signals (one per whale entry burst)

Base (`models.py`) + migrations 001/006/007:

| Column | Type | Notes |
|---|---|---|
| `id` | int PK | |
| `donor_id` | int FK → `donor_wallets.id` | **nullable** (migration 001) — whale signals have no donor |
| `market_id` | text | Polymarket `conditionId` |
| `title` | text | market title (**runtime inserts `title`**; `models.py` calls it `market_title` — stale) |
| `side` | text | `BUY` (YES/NO outcome captured via `token_id`) |
| `price` | float | VWAP of the aggregated entry |
| `size_usdc` | float | aggregated whale notional |
| `token_id` | text | exact outcome token bought — migration 001 |
| `source_tx_hash` | text | dedup key across restarts — migration 001 (indexed) |
| `source_wallet` | text | tracked wallet that triggered it — migration 007 |
| `consensus` | int default 1 | distinct tracked wallets backing this market/outcome — migration 007 |
| `whale_wallet` | text | resolved buyer (observe-mode scoring) — migration 006 |
| `whale_realized_pnl` / `whale_resolved_count` / `whale_winrate` / `whale_passed` | float/int/float/bool | track-record snapshot — migration 006 |
| `ai_score` / `ai_reason` | int / text | OpenAI risk analysis (informational) |
| `created_at` | timestamptz | indexed desc |

### 6.4 `copy_trades` — per-subscriber mirrored trades (audit trail)

| Column | Type | Notes |
|---|---|---|
| `id` | int PK | |
| `user_id` | int FK → `users.id` | the subscriber |
| `signal_id` | int FK → `trade_signals.id` | source signal |
| `status` | text | `executing → placed → confirmed \| unfilled \| failed` |
| `size_usdc` | float | intended, then updated to filled amount |
| `order_id` | text | CLOB order id (**runtime writes `order_id`**; not in `models.py`) |
| `tx_hash` | text | on-chain tx (legacy field in `models.py`) |
| `fill_price` | float | |
| `pnl_usdc` | float | realized P&L (settlement) |
| `error_msg` | text | failure reason (truncated) |
| `created_at` / `updated_at` | timestamptz | |

> Idempotency uses `(user_id, signal_id)` + status (see §5.2). **Blueprint 1 (§4) adds settlement
> columns** (`condition_id, token_id, outcome_index, neg_risk, entry_price, shares, result,
> realized_pnl, resolved_at, redeemed_at, redeem_tx`) via migration 008. **Blueprint 6 (§4)** makes
> a token-sale exit terminal: `status='closed'`, `result='closed'`, P&L booked from the actual sale,
> plus `exit_tx` via migration 012 (apply before next deploy). `status='closed' OR redeemed_at IS NOT NULL`
> ⇒ the row is permanently excluded from settlement/auto-claim.

### 6.5 `donor_wallets` — legacy donor-copy (Model A, dormant) — `models.py`

`id`, `address` (unique), `label`, `win_rate_30d`, `roi_30d`, `total_volume_usdc`, `active`,
`last_seen_at`, `updated_at`. Not used by the active Model B path.

### 6.6 `access_codes` — one-time subscription activation — migration 002

| Column | Type | Notes |
|---|---|---|
| `code` | text PK | redeemable code (`secrets.token_urlsafe`) |
| `tier` | text default `'active'` | tier granted |
| `days` | int default 30 | subscription length |
| `note` | text | admin note |
| `used_by` | bigint | telegram_id that redeemed (null = unused; partial index on unused) |
| `used_at` | timestamptz | |
| `created_at` | timestamptz | |

> Redeem is **atomic**: `update ... where code=? and used_by is null` (guards double-redeem races).

### 6.7 `admins` — admin registry — migration 004

`telegram_id` (bigint PK), `username`, `active` (bool), `added_by` (bigint), `created_at`. The
super-admin (`ADMIN_TELEGRAM_ID` from env) is always authorized regardless of this table.

### 6.8 `admin_codes` — one-time admin invite codes — migration 004

`code` (text PK), `note`, `used_by` (bigint), `used_at`, `created_at`. Same atomic-claim pattern as
`access_codes`.

### 6.9 Pending migrations (SQL written, **must be applied manually** in Supabase SQL editor)

- **008** — `copy_trades` settlement ledger (Blueprint 1) → `migrations/008_settlement_ledger.sql`
- **009** — `tracked_wallets.avg_trade_usdc` (Blueprint 2) → `migrations/009_tracked_avg_size.sql`
- **010** — `users.equity_hwm`, `users.copy_paused_until` (Blueprint 4) → `migrations/010_risk_controls.sql`
- **011** — `users.sizing_mode` (per-user Kelly/fixed toggle) → `migrations/011_user_sizing_mode.sql`
- **012** 🔴 — `copy_trades.exit_tx` + `(user_id, condition_id)` index (Blueprint 6) →
  `migrations/012_position_state.sql` (also documents `copy_trades.result='closed'` for token-sale exits)
- **013** ✅ — `users.risk_state` + `risk_override_at` + `risk_override_count` +
  `realized_baseline` (Blueprint 8) → `migrations/013_risk_state_override.sql`
  (**applied** — deploy with Blueprint 8 code)
- **014** ✅ — `users.max_daily_trades` (Blueprint 13.2; `NULL` = unlimited) →
  `migrations/014_max_daily_trades.sql` (applied — deploy with Blueprint 13 code)
- **015** ✅ — `trade_signals.ai_signal_type` (Blueprint 14.B structured AI output) →
  `migrations/015_ai_signal_type.sql` (applied — deploy with Blueprint 14 code)

### 6.10 Migration order

`001` whale strategy → `002` access codes → `003` username → `004` admins → `005` deposit wallets →
`006` wallet score → `007` tracked wallets → `008` settlement ledger → `009` tracked avg size →
`010` risk controls → `011` user sizing mode → `012` position state (exit_tx + user/condition index) →
`013` risk state + manual override (Blueprint 8) → `014` max daily trades (Blueprint 13.2) →
`015` ai_signal_type (Blueprint 14.B).

---

## 7. Server & Deploy Guide

### 7.1 Infrastructure

| Component | Where |
|---|---|
| **VPS** | AWS EC2 — `ubuntu@ip-172-26-8-174` |
| **Project root** | `/home/ubuntu/app` |
| **Process manager** | Docker (plugin, `docker compose` without hyphen) |
| **Redis** | container `app-redis-1` (redis:7-alpine, port 6379, internal only) |

Running containers (check with `docker compose ps`):

| Container | Image | Role |
|---|---|---|
| `app-api-1` | `app-api` | FastAPI (uvicorn), port 8000 → host |
| `app-worker-1` | built image | Celery worker (gevent, queues: trades/ai/periodic) |
| `app-beat-1` | `app-beat` | Celery beat scheduler — **must be exactly 1 replica** |
| `app-redis-1` | redis:7-alpine | Broker + backend |

### 7.2 Standard deploy (after `git push` from local)

```bash
# 1. SSH into the server
ssh ubuntu@ip-172-26-8-174

# 2. Pull latest code
cd /home/ubuntu/app
git pull origin master

# 3. Apply any new migrations in Supabase SQL Editor (see §7.4)

# 4. Rebuild images and restart containers
docker compose build --no-cache api worker beat
docker compose up -d api worker beat

# 5. Verify
docker compose ps
docker compose logs --tail=50 worker
docker compose logs --tail=50 beat
```

### 7.3 Quick restart (no code changes, just config / env)

```bash
cd /home/ubuntu/app
docker compose restart api worker beat
```

### 7.4 Applying database migrations

Migrations are plain idempotent SQL files in `migrations/`. They **must be applied manually**
in the Supabase SQL Editor **before** restarting the worker, because new code may write to
columns that don't exist yet.

1. Open [supabase.com](https://supabase.com) → your project → **SQL Editor**.
2. Copy-paste the contents of each new `migrations/00X_*.sql` file and click **Run**.
3. Apply in order: `008` → `009` → `010` → …

**Migrations applied as of the last deploy (2026-07-02):** 001–014 (all applied in prod).
Migration **014** (`is_signal_only`, `subscription_notified_expired`) backs the production Signal-Only Mode +
Subscription Enforcer (BP14); verified live on 2026-07-02 (columns present, enforcer end-to-end healthy).
Any future migration (015+) must be applied in the Supabase SQL Editor **before** restarting the worker.

### 7.5 Useful diagnostic commands

```bash
cd /home/ubuntu/app

# Tail live worker logs
docker compose logs -f worker

# Tail beat logs
docker compose logs -f beat

# Check all container health
docker compose ps

# Drop into a running worker shell (for one-off scripts)
docker compose exec worker bash

# Run a one-off Python script inside the worker context
docker compose exec worker python scripts/seed_quality.py

# Restart only the beat scheduler (e.g. after beat_schedule change)
docker compose restart beat

# Hard rebuild a single service
docker compose build --no-cache worker
docker compose up -d worker
```

### 7.6 Environment / secrets

Secrets are in `.env` at the project root (not committed). After SSH-ing in:

```bash
cat /home/ubuntu/app/.env   # view current config
nano /home/ubuntu/app/.env  # edit (then restart the affected containers)
```

Key variables to verify are set: `SUPABASE_URL`, `SUPABASE_SERVICE_KEY`, `ENCRYPTION_KEY`,
`TELEGRAM_BOT_TOKEN`, `POLYGON_RPC_URL`, `ALCHEMY_API_KEY`, `BUILDER_API_KEY`,
`BUILDER_SECRET`, `BUILDER_PASSPHRASE`, `REDIS_URL`, `AUTO_COPY_ENABLED`.

---

## Blueprint 16: Fix Entry Price & PnL in Positions List 🟡 FINAL DESIGN / READY TO IMPLEMENT

> **Class of bug:** Data Persistence / State read-path defect (NOT a write-path loss). The correct
> entry price *is* in our DB — the `/positions` view simply never reads it and trusts an on-chain
> source that returns `0` for our custodial proxy wallets.

### 16.0 Symptom (prod, PolyMind AI)

1. On entry, the trade notification (`_notify` in `worker/tasks/execute_copy.py`) shows the **correct**
   price (e.g. `@ 0.875`) and invested amount (e.g. `$5.60`). ✅
2. In `/positions` (`_build_positions` in `api/routers/telegram.py`) **every** position renders entry
   price as `@ 0.000`, so the PnL % renders `(+0%)` and the "→ cur" arrow starts from zero. ❌

The two numbers come from **two different sources** that were never reconciled — the exact same class
of "displayed value ≠ stored value" split diagnosed for withdrawals in **Blueprint 12 Part B**.

### 16.1 Root-cause analysis

**Write path — CORRECT (not the bug).** `execute_copy_trade` already denormalizes the entry price onto
the `copy_trades` row (Blueprint 1, migration 008):

```485:486:worker/tasks/execute_copy.py
        "entry_price":    round(entry_price, 6),
    })
```

`entry_price` is the fresh order-book `best_ask` (L368–373), a non-zero float. So the DB **does** hold
the right cost basis. (Caveat hardened in §16.4: nothing currently *guarantees* it is `> 0`.)

**Read path — THE BUG.** `/positions` is sourced **100% on-chain / Data-API**, with **zero JOIN** to
our own `copy_trades` table:

```883:890:api/routers/telegram.py
    for i, p in enumerate(positions):
        title = (p.get("title") or "—")[:40]
        outcome = p.get("outcome") or "—"
        shares = p["shares"]
        avg = p["avg_price"]
        cur = p["cur_price"]
        pnl = p["cash_pnl"]
        pct = p["percent_pnl"]
```

`avg_price` / `percent_pnl` originate solely from the Polymarket Data API:

```437:445:core/polymarket.py
                "shares":       float(p.get("size") or 0),
                "avg_price":    float(p.get("avgPrice") or 0),
                "cur_price":    float(p.get("curPrice") or 0),
                "current_value": float(p.get("currentValue") or 0),
                "cash_pnl":     float(p.get("cashPnl") or 0),
                # ...
                "percent_pnl":  float(p.get("percentPnl") or 0) / 100.0,
```

For our **custodial deposit wallets** (POLY_1271 relayer-funded proxy funders — §5), the Data API
`avgPrice` is unreliable and frequently `0`:
- **Indexing lag** — freshly-opened positions surface with `avgPrice = 0` before the indexer back-fills
  the fill price (the code already *knows* this — see the comment at `_build_pnl`,
  `api/routers/telegram.py` L952–954: *"avg_price momentarily 0 → it reports the whole position value
  as profit"*).
- **Proxy attribution** — fills routed through the 1271 proxy are not always attributed with a blended
  `avgPrice` on the funder address the way a plain EOA trade is.

When `avgPrice = 0`: `avg` renders `0.000`, and the API's own `percentPnl` is `0` (it cannot compute a
return with no cost basis) → `(+0%)`. **The bug is not that the price was lost — it is that the read
path throws away the DB copy we already have and trusts a source that returns 0.**

**Math-safety latent bug.** `_build_positions` currently consumes the *pre-computed* `percent_pnl`, so
it does not divide by zero today. But the moment we compute the return locally from the entry price
(the fix), `pct = (cur - entry) / entry` divides by zero when `entry == 0`. `_build_pnl` already dodges
this defensively (`if avg > 0.001`) — the fix must apply the **same guard** in `_build_positions`.

### 16.2 Fix strategy — DB is the source of truth for entry price

Three coordinated changes; **no new migration** (the `entry_price` column already exists — migration 008).

**A. New read helper — `get_entry_prices_by_token(user_id)` (`core/db/queries.py`).**
Return `{token_id: entry_price}` for the user's open (`status in ('confirmed','executing')`,
`redeemed_at IS NULL`) `copy_trades`. Mirror `get_open_trades_cost` (L618) exactly, but select
`token_id, entry_price` and keep the **latest non-zero** entry per token (guards partial-fill dupes):

```python
def get_entry_prices_by_token(user_id: int) -> dict:
    """{token_id: entry_price} for open (confirmed/executing, unredeemed) copy_trades.
    Local cost-basis fallback for the /positions view when the Data-API avgPrice is 0."""
    sb = get_supabase()
    res = (
        sb.table("copy_trades")
        .select("token_id, entry_price, created_at")
        .eq("user_id", user_id)
        .in_("status", ["confirmed", "executing"])
        .is_("redeemed_at", "null")
        .order("created_at", desc=True)
        .execute()
    )
    out: dict = {}
    for row in (res.data or []):
        tid = row.get("token_id")
        ep = float(row.get("entry_price") or 0)
        if tid and ep > 0 and tid not in out:   # first (newest) non-zero wins
            out[tid] = ep
    return out
```

> **CRITICAL — export it.** Add `get_entry_prices_by_token` to **both** the
> `from core.db.queries import (...)` block **and** `__all__` in `core/db/__init__.py`. This is the
> exact drift that caused **Blueprint 12 Part A** (`get_open_trade_by_token` missing from exports) —
> do not repeat it. If the BP9 boot self-check `_check_core_imports()` exists, add the name there too.

**B. Overlay DB entry price in the read path (`api/routers/telegram.py`).**
In `_build_positions` (and reuse the same map in `_build_pnl`), fetch the map once and pick the
**effective entry** per position — prefer a valid on-chain blended `avgPrice`, fall back to our DB copy:

```python
# once, before the loop:
from core.db import get_entry_prices_by_token
db_entry = get_entry_prices_by_token(db_user["id"])

# per position:
api_avg = float(p.get("avg_price") or 0)
entry   = api_avg if api_avg > 0 else db_entry.get(p["token_id"], 0.0)
```

Rationale for the precedence (`API-if-nonzero, else DB`): once the indexer catches up, `avgPrice` is
the *blended* truth across partial fills / add-ons; our single-row `entry_price` is only the first
fill. So we trust the API when it is populated and use the DB purely as the **zero-gap fallback** that
kills the `0.000` display. (If a market is later found where the API blends *worse* than our ledger,
revisit — but do not silently override a valid non-zero API avg.)

**C. Compute PnL locally with a divide-by-zero guard (single source of math truth).**
Replace the direct `pct = p["percent_pnl"]` / `pnl = p["cash_pnl"]` reads with a guarded local compute,
so display, %, and $ all derive from the same `entry`:

```python
if entry > 0:
    pnl = shares * (cur - entry)
    pct = (cur - entry) / entry
else:
    # No cost basis anywhere — happens for legacy pre-BP1 rows (verified in §16.7,
    # ids 674–690: entry_price AND shares both NULL). Show a dash, never 0%/NaN.
    pnl = float(p.get("cash_pnl") or 0)
    pct = None
```

Render `pct` as `"—"` when `None` (never `+0%`, never `ZeroDivisionError`, never `inf/NaN`). Keep the
`avg:.3f` in the row using `entry` so the arrow reads `0.875 → 0.910` instead of `0.000 → 0.910`.

### 16.3 Files touched (no migration)

| File | Change |
|---|---|
| `core/db/queries.py` | **+** `get_entry_prices_by_token(user_id)` (new helper, §16.2 A) |
| `core/db/__init__.py` | **+** re-export the helper in the import block **and** `__all__` (BP12-A guard) |
| `api/routers/telegram.py` | `_build_positions` + `_build_pnl`: overlay DB entry, guarded local PnL (§16.2 B/C) |
| `worker/tasks/execute_copy.py` | **hardening only** — enforce `entry_price > 0` invariant on write (§16.4) |

### 16.4 Write-path hardening (defense-in-depth, secondary)

`entry_price` is written today, but nothing guarantees it is non-zero, and if it ever is, the fallback
in §16.2 silently degrades back to `0.000`. Add a cheap invariant in `execute_copy_trade` right before
the `insert_copy_trade` at L475:

- `entry_price` is derived from `book["best_ask"]` and falls back to `signal["price"]`. If **both** are
  `0`/missing, either **skip** (`reason="no_entry_price"`) or persist the best available signal price —
  never insert a `0` cost basis. Log `log.warning("entry_price_zero_guard", ...)` when it triggers so a
  regression in the order-book path is visible, not silent.

**Model drift note (cosmetic, flag don't chase):** `core/db/models.py::CopyTrade` still declares
`fill_price` and has **no** `entry_price` column (models are "schema reference only", §2.1, and are not
used at runtime — writes go through raw dicts to Supabase). Update the SQLAlchemy model to match the
live schema (`entry_price`, `shares`, `condition_id`, `token_id`, `outcome_index`, `neg_risk`,
`result`, `realized_pnl`, `resolved_at`, `redeemed_at`, `redeem_tx`, `exit_tx`) so the reference stops
lying — but this does not affect the runtime fix.

### 16.5 Acceptance criteria

1. For a position opened at `0.875`, `/positions` shows `… @ 0.875 → {cur} · {icon} {pnl:+.2f}$ ({pct:+.0%})`
   with the **real** entry and a non-zero, correctly-signed % — even immediately after entry while the
   Data-API `avgPrice` is still `0`.
2. A position with **no** DB entry and a `0` API avg renders `—` for the %, **never** `+0%` and never
   raises `ZeroDivisionError`.
3. `python -c "from core.db import get_entry_prices_by_token"` succeeds (export wired, BP12-A guard).
4. `_build_pnl` unrealized total uses the same effective entry (no phantom "whole value = profit" when
   `avgPrice=0`).
5. No new migration required; `copy_trades.entry_price` (migration 008) is unchanged.

### 16.6 DB verification commands (run BEFORE coding to confirm the hypothesis)

The store is **Supabase Postgres** (§2.1) — use `psql` with the project's pooler/direct connection
string (Supabase Dashboard → Project Settings → Database → Connection string), or the supabase-client
one-liner below (works with the `SUPABASE_URL` / `SUPABASE_SERVICE_KEY` already in `.env`).

```bash
# --- Option A: psql against Supabase Postgres -------------------------------
# Paste your connection string (Session pooler / Direct). NEVER commit it.
export PGURL='postgresql://postgres.<ref>:<PASSWORD>@aws-0-<region>.pooler.supabase.com:5432/postgres'

# 1) Distribution of entry_price on OPEN trades — is it really zeros/nulls?
psql "$PGURL" -c "
  select
    count(*)                                   as open_trades,
    count(*) filter (where entry_price is null) as null_entry,
    count(*) filter (where entry_price = 0)     as zero_entry,
    count(*) filter (where entry_price > 0)     as good_entry,
    min(entry_price), max(entry_price)
  from copy_trades
  where status in ('confirmed','executing') and redeemed_at is null;
"

# 2) Eyeball the most recent open rows — compare stored entry_price vs size_usdc/shares.
psql "$PGURL" -c "
  select id, user_id, left(token_id,14) as token, status,
         entry_price, shares, size_usdc, created_at
  from copy_trades
  where redeemed_at is null
  order by created_at desc
  limit 20;
"

# 3) Cross-check: are the notified trades the ones showing 0.000?  (entry_price=0 but shares>0)
psql "$PGURL" -c "
  select count(*) as zero_priced_open_positions
  from copy_trades
  where status in ('confirmed','executing')
    and redeemed_at is null
    and coalesce(entry_price,0) = 0;
"
```

```bash
# --- Option B: no psql? use the supabase client already configured in .env --
# Reads SUPABASE_URL + SUPABASE_SERVICE_KEY from the environment / .env.
python - <<'PY'
from core.db.session import get_supabase
sb = get_supabase()
rows = (sb.table("copy_trades")
        .select("id,user_id,token_id,status,entry_price,shares,size_usdc,created_at")
        .is_("redeemed_at","null")
        .order("created_at", desc=True)
        .limit(50).execute().data or [])
open_rows = [r for r in rows if r["status"] in ("confirmed","executing")]
zero = [r for r in open_rows if not r.get("entry_price")]
print(f"open (confirmed/executing, unredeemed): {len(open_rows)}")
print(f"  with entry_price 0/NULL: {len(zero)}")
print(f"  with entry_price > 0   : {len(open_rows)-len(zero)}")
for r in open_rows[:15]:
    print(f"  id={r['id']:>5} tok={str(r['token_id'])[:12]:<12} "
          f"entry={r.get('entry_price')!s:<8} shares={r.get('shares')!s:<8} "
          f"size=${r.get('size_usdc')}")
PY
```

**How to read the result:**
- **`entry_price > 0` in the DB (good_entry ≫ 0) while `/positions` shows `0.000`** → confirms the
  read-path/JOIN diagnosis (§16.1): the data is fine, the view ignores it. Fix = §16.2 B/C only.
- **`entry_price` is `0`/`NULL` in the DB (zero_entry/null_entry ≫ 0)** → the write path is *also*
  degrading; apply the §16.4 write guard **in addition to** the read-path fix.

### 16.7 Verification result — prod, 2026-07-01 ✅ HYPOTHESIS CONFIRMED

Ran Option B against prod (`docker compose exec -T worker python …`). Of **25** open
(`confirmed`/`executing`, unredeemed) `copy_trades`:

| bucket | count | meaning |
|---|---|---|
| `entry_price > 0` in DB | **18** | correct cost basis stored (`0.88`, `0.931`, `0.95`, …) yet `/positions` renders `0.000` |
| `entry_price` NULL in DB | **7** *(8 within a 200-row window)* | **all legacy** — see below |

**Conclusion 1 — read-path is THE bug, and the fix is sufficient.** 18/18 of the *recent* trades
(ids ≥ 709, created ≥ 2026-06-21) carry a valid `entry_price`, but the on-chain-only `/positions`
view shows `0.000` for them. The data was never lost — the view throws it away. **§16.2 (B/C) fully
resolves the active symptom.**

**Conclusion 2 — write-path is NOT currently degrading.** Every NULL-entry row is a **legacy tail**
created **2026-06-15 → 2026-06-20** (ids 674–690) with **both** `entry_price = NULL` **and**
`shares = NULL` — i.e. rows written *before* the Blueprint 1 / migration 008 denormalization went
live. No post-BP1 row is missing its price. Therefore **§16.4 is demoted to defense-in-depth**
(cheap future insurance), **not** a required part of this fix.

**Consequence for the legacy rows.** Those 8 rows have no cost basis *anywhere* (not in the API,
not in our DB), so the §16.2-B fallback cannot rescue them — they rely purely on the §16.2-C
divide-by-zero guard to render `—` (never `+0%`, never a crash) and will age out on resolution.
This makes the §16.2-C guard **load-bearing**, not merely defensive.

**Incidental finding (out of scope, log for later):** the query revealed **`copy_trades.order_id`
does not exist** in the live schema, yet `execute_copy_trade` writes it inside a swallowing
`try/except: pass`:

```505:508:worker/tasks/execute_copy.py
            sb.table("copy_trades").update({
                "status":   "placed",
                "order_id": order_id,
            }).eq("id", trade_row["id"]).execute()
```

Because both fields go in one `update`, the missing column makes the **entire** statement fail
silently → the interim `status='placed'` transition never persists (the row stays `executing` until
the later `confirmed`/`unfilled` update, which omits `order_id`, succeeds). Not part of Blueprint 16;
file as a follow-up (either add an `order_id text` column via migration, or drop the field from the
write). Flagging so it is not lost.

---

## Blueprint 17 — Spread-Trap stop-loss hardening + Broken-Override state reset ✅ IMPLEMENTED 2026-07-02

Two independent prod risk-manager defects, designed together because both live in the risk/exit
path and share the same monitor (`sync_positions` → `_update_hwm_and_check_breakers`) and the same
override button (`callback_data="unlock_drawdown"`).

- **17.A — Spread Trap:** the Delta-Drop stop fires within minutes of entry on illiquid markets,
  closing profitable/neutral positions at a loss because it compares the **ask-based fill price**
  against the **live best_bid** across a wide spread — measuring the spread, not a real move.
- **17.B — Broken Override State:** the manual "Снять блокировку" handler lifts the pause and resets
  the HWM baseline but **never neutralizes the daily-loss counter**, so the next monitor cycle
  re-trips `paused_daily_loss` and re-locks the user in a loop, with no new losing trades.

### 17.1 Root cause — 17.A (Spread Trap)

`worker/tasks/manage_positions.py` (BP10 Delta-Drop block, L166–195):

```183:195:worker/tasks/manage_positions.py
            # Delta-Drop trigger: exit if best_bid fell >= X from entry.
            if entry_px > 0 and best_bid > 0:
                drop_pct = 1.0 - best_bid / entry_px
                if drop_pct >= settings.delta_drop_stop_pct:
                    log.info("delta_drop_triggered", ...)
                    _closing.add(ckey)
                    close_position.delay(uid, token_id, "delta_drop_stop")
```

- `entry_px = float(p.get("avg_price"))` — the Data-API cost basis, i.e. we **bought at the ask**
  (`execute_copy` sets `entry_price = book["best_ask"]`, L368–373).
- `best_bid` — the **live top-of-book bid** from `get_order_book(token_id)`.

On an illiquid binary market the resting spread is enormous (buy fills at ask `0.80`, the best
standing bid is `0.50`). `drop_pct = 1 - 0.50/0.80 = 0.375 ≥ 0.30` → **instant stop**, even though
the market's fair value (mid ≈ `0.65`) hasn't moved and the probability hasn't fallen. We are
measuring the **bid-ask spread**, not a drop in win probability, then crystallising it as a real
loss by market-selling into that same thin bid.

The existing `delta_drop_min_hold_sec = 600` (10 min) guard does **not** save us: the spread is
present from t=0 and persists, so the drop is still there after the hold window expires. And
`_first_seen` is an in-process dict that **resets on worker restart** (L32–34), so a restart can
make an old position instantly "mature" and eligible.

### 17.2 Design — 17.A Spread-Trap defense (layered, defense-in-depth)

The stop must trigger on a **real fall in fair value**, not on an empty book. Four layers; ship all
of them (cheap, independent, each closes a different failure mode):

**Layer 1 — Measure drop from MID, not from best_bid.**
`get_order_book` already returns `best_bid` **and** `best_ask`. Compute
`mid = (best_bid + best_ask) / 2` and `drop_pct = 1 - mid/entry_px`. Mid is spread-insensitive:
a hollow bid with a sane ask no longer fabricates a drop. Fall back to best_bid only if `best_ask`
is missing/zero (and in that case Layer 2 will veto anyway).

**Layer 2 — Spread / liquidity gate (veto).**
Before trusting *any* stop signal, compute `spread_pct = (best_ask - best_bid) / mid`. If
`spread_pct > settings.max_spread_for_stop_pct` (proposed `0.08`), the book is too thin to be a
reliable price source → **skip the stop this cycle** and log `stop_skipped_wide_spread`
(user_id, token, best_bid, best_ask, spread_pct). Optionally also require a minimum bid size/notional
(`min_bid_notional_usdc`) if depth is available from the book. This is the single highest-leverage
fix: it directly rejects the Spread-Trap condition.

**Layer 3 — Entry-anchored bid baseline (reference the book we actually entered against).**
Persist the CLOB `best_bid` observed **at buy time** as `copy_trades.entry_bid` (written in
`execute_copy` next to `entry_price`). Then the "real move" test becomes
`drop_from_entry_bid = 1 - best_bid/entry_bid` — a like-for-like bid-vs-bid comparison that is
immune to the ask-vs-bid spread asymmetry entirely. Fire the stop only when **both** the mid-based
drop (Layer 1) *and* the entry-bid-based drop clear the threshold. (If `entry_bid` is NULL for
legacy rows, gracefully skip this leg and rely on Layers 1+2+4.)

**Layer 4 — Persistence / debounce + robust cooldown.**
- Require the drop to persist across **N consecutive polls** (`delta_drop_confirm_ticks`, proposed
  `2`) before closing — a single hollow-book snapshot never triggers. Track a small per-token
  breach counter (in-process is fine; a transient false reading simply resets it).
- Anchor min-hold to the **trade's real age**, not the in-process `_first_seen` dict: read
  `copy_trades.created_at` for the token and enforce `age >= delta_drop_min_hold_sec`. Bump the
  window to **900s (15 min)** per the incident. This survives worker restarts (the current dict does
  not).

**Recommended shipping combination:** Layer 2 (spread veto) + Layer 1 (mid) are mandatory and
sufficient to kill the reported symptom; Layers 3 + 4 make it robust and calibratable. `hard_stop`
(absolute floor at `0.07`) stays as-is — it is a true "market has abandoned this outcome" net and is
not spread-sensitive at that price.

### 17.3 Config knobs — 17.A (add to `core/config.py`)

| Setting | Proposed default | Meaning |
|---|---|---|
| `max_spread_for_stop_pct` | `0.08` | above this (`(ask-bid)/mid`) the book is untrustworthy → skip stop |
| `delta_drop_use_mid` | `True` | measure drop from mid instead of best_bid |
| `delta_drop_confirm_ticks` | `2` | consecutive breaching polls required before closing |
| `delta_drop_min_hold_sec` | `900` | raise from 600 → 15 min, anchored to `created_at` |
| `min_bid_notional_usdc` | `0` (opt-in) | optional depth floor before trusting the bid |

### 17.4 Files touched — 17.A

| File | Change |
|---|---|
| `worker/tasks/manage_positions.py` | Delta-Drop block: fetch `best_ask`; compute `mid` + `spread_pct`; add spread veto (Layer 2), mid drop (Layer 1), entry-bid drop (Layer 3), persistence counter + `created_at`-anchored hold (Layer 4); new log events `stop_skipped_wide_spread`, `delta_drop_confirming` |
| `worker/tasks/execute_copy.py` | Persist `entry_bid` (CLOB best_bid at fill) alongside `entry_price` |
| `core/config.py` | Add the five knobs in §17.3 |
| `core/db/queries.py` | `get_open_trade_by_token` / cost helper: also return `created_at`, `entry_bid` |
| `migrations/016_entry_bid.sql` | `alter table copy_trades add column if not exists entry_bid double precision;` |

### 17.5 Acceptance criteria — 17.A

1. A position bought at ask `0.80` with a resting bid `0.50` and ask `0.80` (mid `0.65`, spread
   `~0.46`) is **NOT** closed: the spread veto (Layer 2) skips it and logs `stop_skipped_wide_spread`.
2. A position whose **mid** genuinely falls ≥30% from entry across ≥2 polls on a tight book (spread
   < 8%) **is** closed with `reason="delta_drop_stop"` — real stops still work.
3. No stop can fire before `created_at + 900s`, and this holds **across a worker restart**.
4. `hard_stop` behaviour at `< 0.07` is unchanged.

---

### 17.6 Root cause — 17.B (Broken Override State / cyclic re-lock)

The monitor re-pauses on daily loss using a counter the override never touches:

```1138:1147:worker/tasks/manage_positions.py
        # ── Daily loss limit ──────────────────────────────────────────────────
        daily_pnl = get_daily_realized_pnl(uid)
        if daily_pnl <= -(settings.daily_loss_limit_pct * equity):
            ...
            pause_user_copying(uid, next_utc_day)
            set_risk_state(uid, "paused_daily_loss")
```

`get_daily_realized_pnl` sums `copy_trades.realized_pnl` over the trailing 24h (queries.py L515–529).
The `unlock_drawdown` handler (`api/routers/telegram.py` L2117+) does:
`resume_user_copying` (clears `copy_paused_until`) → `reset_risk_baseline` (resets `equity_hwm` +
`realized_baseline`, fixing **only** the *drawdown* breaker) → `record_risk_override` (audit) →
`set_risk_state("active")` → deletes Redis keys `drawdown_alert` / `risk_gate:*:drawdown` /
`resume_alert`.

**Nothing resets or masks the daily-loss sum.** So on the next `sync_positions` (seconds later):
`current_state` is now `active` (the guard `if current_state in (paused_*): return` no longer
short-circuits) → `daily_pnl` is still the same large negative number → the daily-loss branch
re-fires, re-pauses, and re-sends the alert. Infinite re-lock, zero new losing trades. (The
`daily_loss` alert has no `notify_once` guard — it relied on the state machine that the override just
cleared.)

### 17.7 Design — 17.B State Reset (hard, self-expiring override flag)

Adopt the user-proposed **`manual_override_until_midnight_utc`** as a first-class, hard-respected
flag. This is preferred over "zero the counter" because (a) it is self-documenting, (b) it expires
exactly when the daily-loss window rolls over (00:00 UTC), matching daily-loss semantics, and (c) it
also protects the drawdown breaker from an immediate re-trip while equity is still depressed.

**Schema (migration 016):**
`alter table users add column if not exists risk_override_until timestamptz;`
(distinct from the existing `risk_override_at` audit stamp).

**Handler (`unlock_drawdown`, api/routers/telegram.py):** in addition to the current steps, set
`risk_override_until = next 00:00 UTC` via a new `set_risk_override_until(uid, ts)` query. Keep the
existing HWM/baseline reset and audit increment.

**Monitor (`_update_hwm_and_check_breakers`):** at the very top, after loading state, add a hard
guard:

```text
override = user.get("risk_override_until")
if override and now_utc < parse(override):
    return   # user explicitly accepted risk for the rest of the UTC day — do NOT re-pause
# (optional) if override elapsed, clear it and continue normally
```

This suppresses **both** breakers for the remainder of the UTC day, so no re-lock is possible. At
midnight UTC the flag lapses and normal protection resumes automatically.

**Pre-trade path (`execute_copy.check_risk_gates` caller, L400–411):** honor the same flag so the
user can actually open trades after overriding. Either skip gate 4 (daily loss) when the override is
active, or pass an `override_active: bool` into `check_risk_gates` and short-circuit gate 4 there.
The pure `check_risk_gates` stays pure — the caller reads `risk_override_until` and decides.

**Precise alternative (documented, not required):** instead of a blanket flag, snapshot
`daily_loss_baseline = get_daily_realized_pnl(uid)` at override time and change the gate to compare
`(daily_pnl - daily_loss_baseline)` against the limit, so **only losses booked *after* the override**
count. This re-arms protection intra-day (stricter) but adds a column + baseline-reset-at-midnight
logic. The flag approach is simpler and safer for the reported bug; ship the flag, keep this as a
future tightening.

### 17.8 Files touched — 17.B

| File | Change |
|---|---|
| `migrations/016_entry_bid.sql` | also add `users.risk_override_until timestamptz` (combined migration) |
| `core/db/queries.py` | **+** `set_risk_override_until(user_id, ts)`, `get_risk_override_until(user_id)`; export both |
| `core/db/__init__.py` | re-export the two helpers (import block **and** `__all__` — BP12-A guard) |
| `api/routers/telegram.py` | `unlock_drawdown`: set `risk_override_until = next UTC midnight`; message copy: "принято до 00:00 UTC" |
| `worker/tasks/manage_positions.py` | `_update_hwm_and_check_breakers`: top-of-function hard guard that returns while override is active (covers drawdown **and** daily-loss) |
| `worker/tasks/execute_copy.py` | pre-trade: honor override — skip gate-4 daily-loss block when `risk_override_until` is in the future |

### 17.9 Acceptance criteria — 17.B

1. User hits `paused_daily_loss`, taps "Снять блокировку": copying resumes and **stays** active — no
   re-lock alert on the next `sync_positions` cycle (or any cycle before 00:00 UTC), with no new
   losing trades.
2. `risk_override_until` is set to the next 00:00 UTC; after it passes, normal daily-loss/drawdown
   protection re-arms automatically without code intervention.
3. While the override is active, `check_risk_gates` does not block new entries on gate 4 (daily loss),
   but gates 1–3 (exposure/event/drawdown-from-new-baseline) still apply.
4. The same button correctly clears **both** `paused_drawdown` and `paused_daily_loss` (single handler,
   flag respected by both breaker branches).
5. `python -c "from core.db import set_risk_override_until, get_risk_override_until"` succeeds.

### 17.10 Evidence pass (run before coding)

- **17.A:** `grep "delta_drop_triggered" ~/.pm2/logs/*-out.log` — confirm `entry` vs `best_bid` gap is
  a spread, not a move (cross-check `position_mark` history for the same token; a bid that is hollow
  from t=0 = trap). Confirms Layer 2 is the right primary fix.
- **17.B:** for an affected user, verify `copy_paused_until` was cleared by the override yet a fresh
  `daily_loss_limit_tripped` log line appears seconds later on the next `sync_positions` — that pair is
  the re-lock signature.

### 17.11 Verification result — prod, 2026-07-01 ✅ BOTH HYPOTHESES CONFIRMED

Runtime is Docker (`app-worker-1` = celery worker running `sync_positions`; `app-api-1` = the
`unlock_drawdown` handler), **not** pm2. Evidence pulled with `docker logs app-worker-1` /
`app-api-1`. Note: structlog is emitted at Celery's `WARNING/MainProcess` wrapper level but the inner
`[info]` events (`position_mark`, `delta_drop_triggered`, …) are intact and parseable.

**17.A — every Delta-Drop stop was a single-cycle bid collapse, not a real move.** Three
`delta_drop_stop` closes in the window, **all losses**, total ≈ **−$8.52** on high-probability
(entry 0.88–0.93) positions:

| token | entry | best_bid before (steady, multiple polls) | best_bid @ trigger (one poll) | drop | booked P&L |
|---|---|---|---|---|---|
| `77344318364307` (trade 755) | 0.8899 | **0.88** for ≥6 min | **0.13** | 0.854 | **−$5.03** |
| `10205670933524` (trade 756) | 0.9299 | **0.89–0.90** | **0.65** | 0.301 *(barely over)* | **−$1.77** |
| `47685817448…` (trade 716)   | — | — | — | — | −$1.72 |

**Control case that proves the mechanism:** token `77893912283105` (entry 0.90) dipped to `0.71`
(drop `0.211`, *just under* the 0.30 threshold) at 16:08, was therefore **not** stopped, and then
**fully recovered to `0.999`** over the next ~25 min. The stopped tokens showed the *identical*
transient-collapse shape — their bid simply cratered for a **single 2-min poll**. This is a hollow
top-of-book / liquidity flush, not a fall in win probability.

Consequences for the design priority (reordered vs §17.2):
1. **Layer 4 (persistence/debounce) is now the PRIMARY fix.** Requiring the breach to persist across
   **≥2 consecutive polls** (`delta_drop_confirm_ticks=2`, ~4 min at the observed 2-min cadence)
   would have prevented **all three** false stops — the very next poll showed the bid restored to
   0.88–0.90.
2. **Layer 2 (spread veto) is co-primary.** At trigger, bid `0.13` against a ~`0.90` ask ⇒
   `spread_pct ≈ 1.5`; bid `0.65` vs ~`0.92` ask ⇒ `spread_pct ≈ 0.34`. Both are far above the
   proposed `0.08` cutoff and would be vetoed.
3. **Layer 1 (mid) alone is INSUFFICIENT** for the 0.13 flush if the ask held (`mid ≈ 0.51`,
   `drop ≈ 0.43` still fires). Keep mid, but it must be paired with Layers 2+4. `delta_drop_min_hold_sec`
   was irrelevant here (trades were 20–30 min old) — do not rely on it as the guard.

**17.B — re-lock loop reproduced verbatim.** From `app-worker-1` + `app-api-1`:

```text
17:00:30  daily_loss_limit_tripped  daily_pnl=-11.66  equity=114.75   ← first daily-loss pause
23:21:53  risk_override_manual      new_hwm=116.54 old_hwm=128.71     ← user taps "Снять блокировку"
23:22:30  daily_loss_limit_tripped  daily_pnl=-12.0   equity=116.54   ← RE-LOCK, +37 s
23:22:55  risk_override_manual      new_hwm=116.54 old_hwm=116.54     ← taps again (HWM no-op)
23:24:29  daily_loss_limit_tripped  daily_pnl=-12.0   equity=116.54   ← RE-LOCK again
```

`daily_pnl` is frozen at `-12.0` across both re-locks (no new trades) — a pure "counter/flag never
reset" defect, exactly §17.6. The override moved the HWM (fixing the *drawdown* breaker) but the
daily-loss gate reads `get_daily_realized_pnl` which is untouched, and `-12.0 < -(0.10 × 116.54) =
-11.65` re-trips every cycle. **§17.7's `risk_override_until` flag (respected by the daily-loss
branch) is confirmed as the correct fix.**

**Cross-defect finding (important):** the `-12.0` daily loss was **substantially manufactured by
17.A** — the three phantom spread-trap stops booked ≈ **−$8.52** of it. So **17.A is a root cause
feeding 17.B**: false stops crystallised losses → tripped the daily-loss breaker → the broken
override couldn't clear it → user locked out. Shipping 17.A materially reduces how often 17.B is even
reached; ship both, but 17.A is the higher-leverage fix.

---

## Blueprint 18 — Admin `/user` Dashboard Upgrade ✅ IMPLEMENTED 2026-07-03

> **Fix applied 2026-07-03.** V2 deposit-wallet tracking and paginated trade history shipped in
> commit `feat: upgrade admin /user command with V2 wallet tracking, PnL metrics, and paginated
> transaction history (Blueprint 18)`.
>
> **What was fixed:**
> - `cmd_user` now reads balances via `withdrawable_usdc(db_user)` (deposit-wallet pUSD + EOA USDC)
>   instead of the EOA directly — eliminates the "fake $0" balance display.
> - Open positions count pulled from `copy_trades` DB (`count_open_positions`) instead of the
>   on-chain EOA call that returned `0` for V2 users.
> - New `📈 PnL` block shows Daily / Weekly / All-Time realized PnL via `get_pnl_summary()`.
> - Inline button `📜 Последние 5 сделок` opens paginated settled-trade history (`uh:` callback).
> - `🔙 К пользователю` re-renders the dashboard via reusable `_user_view()` factory (`uc:` callback).
> - Divide-by-zero guard for legacy rows with `shares=NULL` (Blueprint 16 §16.7).
> - New helpers exported: `count_open_positions`, `get_pnl_summary`, `get_user_trade_history`
>   in `core/db/queries.py` and `core/db/__init__.py`.

> **Class of bug:** same *wrong-wallet / read-path* family as Blueprint 12-B and Blueprint 16 — the
> data exists, the admin view reads it from the wrong source. **No user money moves in this blueprint**
> (admin-bot, read-only display). But the numbers it shows drive support decisions, so "fake $0" is a
> trust/operational bug, not cosmetic.

### 18.0 Symptom (prod, admin bot `/user`)

`/user @sto1ner` renders a card where **every on-chain number is zero** even though the user has real
funds and open positions:

```text
Баланс: pUSD $0.00 · USDC.e $0.00 · POL 4.843
Открытых позиций: 0
```

(`POL 4.843` is correct because gas *does* sit on the EOA — which is the tell: only the EOA is being
read.) The user has collateral and live trades; the admin sees nothing.

### 18.1 Root-cause analysis — the admin reads the EOA, not the deposit wallet

`cmd_user` queries `users.wallet_address` (the **EOA**) for **both** balances and positions:

```316:324:api/routers/admin_bot.py
    addr = u.get("wallet_address")
    bal_txt, pos_txt = "—", "—"
    if addr:
        try:
            from core.polymarket import get_positions
            from core.polygon import get_balances
            b = get_balances(addr)
            bal_txt = f"pUSD ${b.get('pusd', 0):.2f} · USDC.e ${b.get('usdc_e', 0):.2f} · POL {b.get('matic', 0):.3f}"
            pos_txt = str(sum(1 for p in get_positions(addr) if p["shares"] > 0))
```

But per **§2.4**, in Polymarket V2 the user trades through a deterministic **deposit wallet**
(`users.deposit_wallet_address`, an ERC-1967 proxy). Collateral is **swept EOA → deposit wallet**, and
orders are POLY_1271-signed with the **deposit wallet as `funder`**. Therefore:

- **Trading pUSD collateral lives on the deposit wallet**, not the EOA → `get_balances(EOA).pusd == 0`.
- **On-chain positions are attributed to the deposit wallet** → `get_positions(EOA)` is empty → `0`.
- Only leftover gas (POL) and un-swept deposits remain on the EOA → that is why `POL` is the one
  non-zero field.

The main bot already knows this: `_trading_wallet()` returns `deposit_wallet_address or wallet_address`
(`api/routers/telegram.py` L835–838), and `withdrawable_usdc()` sums **deposit-wallet pUSD + EOA USDC
variants** (`core/polygon.py` L394–416, Blueprint 12-B). The admin bot was simply never migrated to the
V2 wallet model — it is still reading the pre-deposit-wallet EOA.

**Two independent defects, same cause:**
1. **Balance = fake $0** → must read `withdrawable_usdc(db_user)` (the established single source of
   truth), not `get_balances(EOA)`.
2. **Open positions = fake 0** → the on-chain call is against the wrong wallet *and* is an unnecessary
   Data-API round-trip. Count from **our own `copy_trades` ledger** instead — authoritative, cheap, and
   already the definition the copy-engine uses for the `max_open_positions` guard (§2.2).

### 18.2 Fix Data Fetching (kill the fake zeros)

**A. Balance — use `withdrawable_usdc` (single source of truth).**
Replace the EOA `get_balances` call with the same helper the withdrawal path uses, so the admin sees
exactly the number the user can act on. Keep `POL` (gas) as a separate on-chain read on the EOA (gas
genuinely lives there and admins need it to diagnose stuck withdrawals/redemptions).

```python
from core.polygon import withdrawable_usdc, get_balances

avail = withdrawable_usdc(u)                     # deposit pUSD + EOA (pusd+usdc_e+usdc)
eoa   = u.get("wallet_address")
pol   = get_balances(eoa).get("matic", 0.0) if eoa else 0.0
bal_txt = f"${avail:.2f} доступно · ⛽️ POL {pol:.3f}"
```

> Optional richer breakdown (nice-to-have, not required): show `trading pUSD` (deposit-wallet pUSD) and
> `free EOA USDC` separately by calling `get_balances(dw)` / `get_balances(eoa)` directly. But the
> **headline number MUST be `withdrawable_usdc`** so the admin card, the user's wallet screen, and the
> withdrawal "Доступно" all agree (the consistency goal from BP12-B §"Consistency cleanup").

**B. Open positions — count from `copy_trades`, not on-chain.**
Add a query helper that counts open (unresolved, unredeemed) rows — the same predicate as
`get_open_trades_cost` (queries.py L638) and `get_open_trade_by_token` (L534):

```python
def count_open_positions(user_id: int) -> int:
    """Count of the user's currently-open copy_trades (confirmed/executing, unredeemed).

    Authoritative, DB-sourced position count for the admin dashboard — mirrors the
    predicate the copy-engine uses for the max_open_positions guard (§2.2). Avoids the
    unreliable on-chain Data-API call against the EOA that returned a fake 0.
    """
    sb = get_supabase()
    res = (
        sb.table("copy_trades")
        .select("id", count="exact")
        .eq("user_id", user_id)
        .in_("status", ["confirmed", "executing"])
        .is_("redeemed_at", "null")
        .execute()
    )
    return int(res.count or 0)
```

> **CRITICAL — export it** (BP12-A guard): add `count_open_positions` to **both** the
> `from core.db.queries import (...)` block **and** `__all__` in `core/db/__init__.py`. Same for every
> new helper below. This is the exact drift that caused the BP12 close-handler crash — do not repeat it.

> **Design note — display parity with the user's `/positions`.** The DB count is the source of truth
> for the *number*. If the admin later wants a per-position live view, source it from
> `_trading_wallet(u)` (deposit wallet) exactly like the user bot, **never** the EOA. For this blueprint
> the count is sufficient and avoids a network dependency in the admin card.

### 18.3 PnL Aggregation (Daily / Weekly / All-Time)

**Source of truth:** `copy_trades.realized_pnl`, booked on terminal transition — resolution redeem
(Blueprint 1) or token-sale close (Blueprint 6, `mark_trade_closed` L557). A row counts toward realized
PnL iff `realized_pnl IS NOT NULL AND resolved_at IS NOT NULL` (identical to the existing
`get_daily_realized_pnl`, L515, so the daily-loss breaker and the admin card stay consistent).

**Window semantics (UTC):**
- 📅 **Daily** — settled since **00:00 UTC today** (calendar day; intuitive "today" for an admin).
- 🗓 **Weekly** — settled in the **trailing 7×24 h**.
- 🏆 **All-Time** — every settled row for the user.

> Note the deliberate difference from `get_daily_realized_pnl` (which is a **trailing 24 h** window used
> by the risk breaker). For an *admin display* "PnL за сегодня" reads more naturally as the calendar day.
> If you prefer strict reuse, call `get_daily_realized_pnl(uid)` for the Daily figure and document it as
> trailing-24h — but do **not** silently mix the two definitions.

**Canonical SQL (one round-trip, `FILTER` aggregates):**

```sql
SELECT
  COALESCE(SUM(realized_pnl) FILTER (
      WHERE resolved_at >= date_trunc('day', now() AT TIME ZONE 'utc')), 0) AS pnl_today,
  COALESCE(SUM(realized_pnl) FILTER (
      WHERE resolved_at >= (now() AT TIME ZONE 'utc') - interval '7 days'), 0) AS pnl_week,
  COALESCE(SUM(realized_pnl), 0)                                             AS pnl_all,
  COUNT(*)                                                                   AS settled_trades
FROM copy_trades
WHERE user_id = :uid
  AND realized_pnl IS NOT NULL
  AND resolved_at  IS NOT NULL;
```

**Runtime implementation (supabase client — the actual runtime path, §2.1).** The supabase client does
not do `FILTER` aggregates, so fetch the settled rows once and bucket in Python (one query, small
result set — a user has tens–hundreds of settled trades, not millions):

```python
def get_pnl_summary(user_id: int) -> dict:
    """Realized-PnL rollup for the admin dashboard: today (UTC calendar day),
    trailing 7 days, and all-time — plus the settled-trade count.

    Uses the same 'realized_pnl IS NOT NULL AND resolved_at IS NOT NULL' terminal
    predicate as get_daily_realized_pnl so the risk breaker and the admin card never
    disagree on what 'settled' means.
    """
    from datetime import datetime, timedelta, timezone
    sb = get_supabase()
    res = (
        sb.table("copy_trades")
        .select("realized_pnl, resolved_at")
        .eq("user_id", user_id)
        .not_.is_("realized_pnl", "null")
        .not_.is_("resolved_at", "null")
        .execute()
    )
    now = datetime.now(timezone.utc)
    day0 = now.replace(hour=0, minute=0, second=0, microsecond=0)
    week0 = now - timedelta(days=7)
    today = week = all_time = 0.0
    n = 0
    for r in (res.data or []):
        pnl = float(r.get("realized_pnl") or 0)
        ts = _parse_ts(r.get("resolved_at"))        # tz-aware UTC parse helper
        all_time += pnl
        n += 1
        if ts and ts >= day0:
            today += pnl
        if ts and ts >= week0:
            week += pnl
    return {"today": today, "week": week, "all_time": all_time, "settled": n}
```

> **Optional performance migration (only if needed):** a partial index
> `create index if not exists ix_copy_trades_user_resolved on copy_trades (user_id, resolved_at) where resolved_at is not null;`
> (→ `migrations/017_copy_trades_resolved_idx.sql`). Not required at current row counts; add it if the
> admin bot ever scans large users. **No schema/column change is needed for Blueprint 18** — every field
> already exists (migration 008).

> **Unrealized PnL (open positions) — explicitly out of scope for the card headline.** The three PnL
> metrics above are **realized** only. Live/unrealized PnL of open positions is already visible in the
> user bot's `/positions` (Blueprint 16) and depends on live marks; if an admin wants it later, compute
> it from `_trading_wallet(u)` positions × current price, but keep it off the primary card to avoid a
> network call and a flickering number.

### 18.4 UI Redesign — `/user` card + inline history

**A. Refactor `cmd_user` into a reusable view factory.** The card must be re-renderable from a callback
(the "back" button from the history view returns to it), so extract the body into:

```python
def _user_view(tid: int, u: dict) -> tuple[str, InlineKeyboardMarkup]:
    """Build the admin /user dashboard text + inline keyboard. Pure (no I/O beyond
    the balance/PnL/count reads) so both cmd_user and the callback can call it."""
```

`cmd_user` then does `_resolve(arg)` → `_user_view(tid, u)` → `reply_text(text, reply_markup=kb)`.

**B. New message template** (adds the PnL block; fixes the balance/position lines):

```text
👤 Пользователь

Ник: @sto1ner
ID: 891787021
Подписка: 4 дн (до 2026-07-07)
Копирование: 🟢 вкл
Макс. позиция: $10
Кошелёк зарегистрирован: ✓

💰 Баланс: $42.18 доступно · ⛽️ POL 4.843
📊 Открытых позиций: 3

📈 PnL
📅 Сегодня:   +$3.10
🗓 7 дней:    −$1.45
🏆 За всё:    +$28.90   (147 сделок)

0xa9108131f342e3C749CBbB6fAc4fB609BF831D20
```

Formatting rules: sign every PnL with `+`/`−` and a red/green cue if desired
(`🟢`/`🔴`), `${abs:.2f}`; render `$0.00` when settled==0 (never `—` for PnL — zero is a real answer).
Keep the wallet address on its own line as `<code>` (tap-to-copy) as today.

**C. Inline keyboard under the card:**

```python
kb = InlineKeyboardMarkup([
    [InlineKeyboardButton("📜 Последние 5 сделок", callback_data=f"uh:{tid}:0")],
])
```

`callback_data` is `uh:<telegram_id>:<offset>` — well under Telegram's 64-byte cap (e.g.
`uh:891787021:0`). We encode the target user in the callback because callbacks are stateless (the admin
who tapped ≠ the subject user). Guard: only `is_admin(tg.id)` may use it (the existing `on_callback`
gate already enforces this — L555–558).

### 18.5 Trade-history view (`📜 Последние 5 сделок` + pagination)

**A. New query helper** — most-recent terminal trades, paginated, with the market title joined from
`trade_signals` (title lives on the signal, not on `copy_trades` — see execute_copy L464–466):

```python
def get_user_trade_history(user_id: int, limit: int = 5, offset: int = 0) -> list[dict]:
    """Most-recent settled/closed copy_trades for the admin history view, newest first.

    Embeds the source signal's title/outcome/event via the signal_id FK so the row can
    show a human ticker. Falls back gracefully if the embed is unavailable.
    """
    sb = get_supabase()
    res = (
        sb.table("copy_trades")
        .select(
            "id, entry_price, shares, size_usdc, result, realized_pnl, "
            "outcome_index, resolved_at, created_at, status, "
            "trade_signals(title, outcome, event_slug)"          # FK embed
        )
        .eq("user_id", user_id)
        .not_.is_("resolved_at", "null")                          # terminal only
        .order("resolved_at", desc=True)
        .range(offset, offset + limit - 1)                        # supabase pagination
        .execute()
    )
    return res.data or []
```

> If the `trade_signals(...)` FK embed is not wired in the Supabase schema, fall back to a second
> batched lookup: collect `signal_id`s and `select id, title, outcome from trade_signals in (...)`, then
> map. Keep the embed as the primary path (one round-trip).

**B. Row rendering — Тикер · Исход · Вход · Выход · PnL.** There is **no `exit_price` column** on
`copy_trades` (verified in §6.4). Derive the exit for display:

- `result='win'` → resolution paid **1.00**; `result='lose'`/`'loss'` → **0.00** (binary payout, §1).
- `result='closed'` (token-sale exit, Blueprint 6) → no stored sale price; derive
  `exit ≈ entry_price + realized_pnl / shares` when `shares > 0`, else show `—`. **Guard the divide by
  zero** (legacy rows have `shares=NULL`, see BP16 §16.7).
- Outcome label: `"YES" if outcome_index == 0 else "NO"` (fallback to the embedded
  `trade_signals.outcome` string when present).

```python
def _fmt_history_row(t: dict) -> str:
    sig   = t.get("trade_signals") or {}
    title = (sig.get("title") or "—")[:32]
    oc    = sig.get("outcome") or ("YES" if t.get("outcome_index") == 0 else "NO")
    entry = float(t.get("entry_price") or 0)
    shares = float(t.get("shares") or 0)
    pnl   = float(t.get("realized_pnl") or 0)
    result = (t.get("result") or "").lower()
    if result == "win":
        exit_px = 1.0
    elif result in ("lose", "loss"):
        exit_px = 0.0
    elif shares > 0:
        exit_px = entry + pnl / shares
    else:
        exit_px = None
    icon    = "🟢" if pnl >= 0 else "🔴"
    exit_s  = f"{exit_px:.2f}" if exit_px is not None else "—"
    entry_s = f"{entry:.2f}" if entry > 0 else "—"
    return (f"{icon} <b>{title}</b> · {oc}\n"
            f"   вход {entry_s} → выход {exit_s} · PnL {pnl:+.2f}$")
```

**C. History message + pagination keyboard** (callback `uh:<tid>:<offset>`, page size 5):

```text
📜 История сделок · @sto1ner
(показаны 1–5 из последних)

🟢 Trump wins Iowa · YES
   вход 0.88 → выход 1.00 · PnL +2.40$
🔴 Fed cuts in July · NO
   вход 0.62 → выход 0.00 · PnL −3.10$
...
```

```python
rows = []
nav = []
if offset > 0:
    nav.append(InlineKeyboardButton("◀️", callback_data=f"uh:{tid}:{max(0, offset - 5)}"))
if len(trades) == 5:                       # a full page ⇒ there may be more
    nav.append(InlineKeyboardButton("▶️", callback_data=f"uh:{tid}:{offset + 5}"))
if nav:
    rows.append(nav)
rows.append([InlineKeyboardButton("🔙 К пользователю", callback_data=f"uc:{tid}")])
kb = InlineKeyboardMarkup(rows)
```

**D. Callback wiring** — add two branches to `on_callback` (`admin_bot.py` L559+), mirroring the existing
`tp:`/`mp:` dispatch style, and re-using the message-edit + "not modified" swallow already there:

```python
elif data.startswith("uh:"):
    _, tid_s, off_s = data.split(":", 2)
    text, kb = _history_view(int(tid_s), int(off_s))
elif data.startswith("uc:"):
    tid = int(data[3:])
    u = get_user_by_telegram_id(tid)
    text, kb = _user_view(tid, u) if u else ("Пользователь не найден.", None)
```

`_history_view(tid, offset)` resolves the user (`get_user_by_telegram_id`), calls
`get_user_trade_history(u["id"], 5, offset)`, and renders §18.5-B/C. Empty result → "Нет завершённых
сделок." with only the 🔙 back button.

### 18.6 Files touched (no migration required)

| File | Change |
|---|---|
| `api/routers/admin_bot.py` | Refactor `cmd_user` → `_user_view(tid, u)`; **balance** via `withdrawable_usdc` + EOA `POL` (§18.2-A); **positions** via `count_open_positions` (§18.2-B); add **PnL block** via `get_pnl_summary` (§18.3); attach inline keyboard (§18.4-C); add `_history_view` + `uh:`/`uc:` branches in `on_callback` (§18.5) |
| `core/db/queries.py` | **+** `count_open_positions(user_id)`, `get_pnl_summary(user_id)`, `get_user_trade_history(user_id, limit, offset)` (+ a `_parse_ts` helper if none exists) |
| `core/db/__init__.py` | **+** re-export all three helpers in the import block **and** `__all__` (BP12-A guard) |
| `migrations/017_copy_trades_resolved_idx.sql` | *(optional, perf-only)* partial index `(user_id, resolved_at)` — §18.3 |

No column is added; every field (`realized_pnl`, `resolved_at`, `entry_price`, `shares`, `result`,
`outcome_index`) already exists from migration 008.

### 18.7 Acceptance criteria

1. For a user with $42.18 withdrawable and 3 open trades, `/user` shows **`💰 Баланс: $42.18 доступно`**
   and **`📊 Открытых позиций: 3`** — never `$0.00`/`0` when funds/positions exist. The headline balance
   equals the number shown on the user's own wallet/withdrawal screen (`withdrawable_usdc` parity).
2. `POL` gas continues to display from the EOA (it is not part of `withdrawable_usdc`).
3. The card shows Daily / Weekly / All-Time realized PnL, correctly signed, with `$0.00` (not `—`) when a
   window has no settled trades. All-Time equals the sum of every settled `realized_pnl` for the user.
4. `📜 Последние 5 сделок` opens a list of the 5 most-recent **settled** trades with Ticker, Outcome,
   Entry, derived Exit, and PnL; `▶️`/`◀️` paginate in steps of 5; `🔙 К пользователю` re-renders the card.
5. A `closed` (token-sale) trade with `shares=0`/NULL renders Exit `—` and never raises
   `ZeroDivisionError` (BP16 §16.7 legacy-row guard).
6. `python -c "from core.db import count_open_positions, get_pnl_summary, get_user_trade_history"`
   succeeds (exports wired — BP12-A guard). If the boot self-check name-set exists (`api/main.py` /
   `worker/celery_app.py`), add the three names there too.
7. Only admins can trigger the `uh:`/`uc:` callbacks (existing `on_callback` `is_admin` gate).
8. No new DB column; `/user` makes **at most** the balance reads + 2 small DB queries (count + PnL) and
   **zero** on-chain position calls.

### 18.8 Evidence pass (run before coding — confirm the wrong-wallet hypothesis)

```bash
# For the affected user (telegram_id 891787021 from the screenshot): compare EOA vs deposit wallet.
docker compose exec -T worker python - <<'PY'
from core.db.session import get_supabase
from core.polygon import get_balances, withdrawable_usdc
sb = get_supabase()
u = sb.table("users").select("*").eq("telegram_id", 891787021).maybe_single().execute().data
print("EOA        :", u.get("wallet_address"),        get_balances(u.get("wallet_address")))
print("DepositWlt :", u.get("deposit_wallet_address"), get_balances(u.get("deposit_wallet_address")))
print("withdrawable_usdc:", withdrawable_usdc(u))
open_ct = (sb.table("copy_trades").select("id", count="exact")
           .eq("user_id", u["id"]).in_("status", ["confirmed","executing"])
           .is_("redeemed_at","null").execute().count)
print("open copy_trades :", open_ct)
PY
```

**Expected:** EOA pUSD/USDC ≈ 0 (only POL), deposit-wallet pUSD > 0, `withdrawable_usdc` > 0, and
`open copy_trades` > 0 — confirming §18.1 (the card reads the EOA; the money and positions are on the
deposit wallet / in the ledger). Fix = §18.2 + §18.3 + §18.5; no migration.

---

## Blueprint 19 — Global Stop-Loss Invariant & Fixed-Sizing Leak ✅ IMPLEMENTED (2026-07-03)

> **Class of bug:** a **risk-path** instance of the exact **Blueprint 16 wrong-source** defect. The
> stop-loss monitor reads its cost basis from the Polymarket **Data-API `avg_price`** — the same field
> BP16 proved returns **`0`** for our custodial POLY_1271 proxy wallets. When it is `0`, a `> 0` guard
> **silently skips the entire Delta-Drop stop**, so the position rides to resolution. BP16 fixed this for
> the *display* path but the fix was **never wired into the money-losing risk path.** This is a
> **stop-loss leak that costs real money**, not a cosmetic bug — §5 fail-closed applies.

### 19.0 Symptom (prod, user @sto1ner / id 891787021)

Trade-history rows where the **−30% Delta-Drop stop (Blueprint 17) never fired**:

| Entry | Exit | Drawdown | Should have stopped at |
|---|---|---|---|
| 0.54 | 0.17 | ~68% | ~0.38 (−30%) |
| 0.66 | 0.00 | 100% | ~0.46 (−30%) |
| 0.88 | 0.55 | ~37% | ~0.62 (−30%) |

The admin's own account (`SIZING_MODE=kelly`) stops correctly; this user is on `SIZING_MODE=fixed`,
which produced the **plausible-but-wrong** hypothesis that the monitor filters by sizing mode.

### 19.1 Root-cause analysis — TWO findings

**Finding A — the sizing-mode hypothesis is REFUTED (spurious correlation).**
There is **no `sizing_mode` branch anywhere in the monitor path**:
- `get_active_subscribers()` (`core/db/queries.py` L54–86) filters on `sub_tier`, `sub_expires_at`,
  `copy_paused_until`, and (auto-copy) `copy_active`/`wallet_address` — **never** `sizing_mode`.
- `sync_positions` iterates every returned subscriber identically and the stop block is explicitly
  annotated as sizing-agnostic:

```150:150:worker/tasks/manage_positions.py
            # BP13.3 invariant: stop is sizing-agnostic; never branch on sizing_mode.
```

`sizing_mode` (per-user, migration 011) affects **entry sizing only** (`execute_copy`, §2.3 / BP13.1);
it is invisible to `sync_positions`. Kelly vs Fixed working differently is a **coincidence of indexer
timing** (see Finding B) — not causation.

**Finding B — the real leak: stop-loss uses the Data-API `avg_price` (BP16's known-zero source), and a `> 0` guard skips silently.**
The monitor takes its cost basis straight from the on-chain Data-API position:

```198:199:worker/tasks/manage_positions.py
            # Cost-basis entry price from Data-API avg_price.
            entry_px = float(p.get("avg_price") or 0)
```

The **entire** Delta-Drop evaluation is then gated on that value being non-zero:

```234:235:worker/tasks/manage_positions.py
            if entry_px > 0 and price_ref > 0:
                drop_pct = 1.0 - price_ref / entry_px
```

Per **Blueprint 16 §16.1 (verified in §16.7)**, `avgPrice` from the Data API is **`0` for freshly-opened
positions on POLY_1271 proxy wallets** (indexing lag + proxy attribution). When `entry_px == 0`:
- `if entry_px > 0` is **False** → Delta-Drop is **skipped every poll**, with **no log line** (this is
  the silent leak — `position_mark` at L208 is *also* gated on `entry_px > 0`, so there is literally no
  trace the position was ever evaluated).
- The **only** remaining net is the absolute `hard_stop`, which itself has a guard that leaks:

```280:283:worker/tasks/manage_positions.py
            if best_bid > 0 and best_bid < settings.hard_stop_abs_price:
                log.info("hard_stop_triggered",
                         user_id=uid, token=token_id[:14],
                         cur_price=best_bid, threshold=settings.hard_stop_abs_price)
```

This explains the table exactly:
- **0.54 → 0.17** and **0.88 → 0.55**: mid stayed **above** `hard_stop_abs_price` (0.07), and Delta-Drop
  was dead (`entry_px=0`) → **nothing fired**; the loss only crystallised at resolution/manual close.
- **0.66 → 0.00**: rode all the way down; once the book went **hollow (`best_bid == 0`)**, even
  `hard_stop` is vetoed by its own `best_bid > 0` guard → **no exit possible** → settled at $0.

**Why the admin (Kelly) was protected and this user (Fixed) was not — the real differentiator.** It is
*not* the sizing mode. It is **whether the Data-API had back-filled `avgPrice` by the time the monitor
polled** — a function of indexing lag, market liquidity, and fill timing. The admin's positions happened
to have a non-zero `avgPrice` (guard passed → stop worked); this user's were still `0` at evaluation
time (guard failed → stop skipped). The BP16 evidence pass already proved **18/25** open positions carry
a good `entry_price` in our DB while the on-chain `avgPrice` reads `0` — i.e. **the correct cost basis
was sitting in `copy_trades` the whole time; the monitor just never looked at it.**

**Finding C — the fix ingredient already exists but is unused on the risk path.**
BP16 shipped `get_entry_prices_by_token(user_id)` (`core/db/queries.py` L663–691) and the `/positions`
view uses it (`_db_entry_prices`). `manage_positions.py` does **not** import or use it — the only
`entry_price`/`avg_price` reference in the whole monitor is the raw L199 read above.

### 19.2 Design — stop-loss as a GLOBAL, data-resilient invariant

The stop must be **(1)** independent of sizing mode (already structurally true — keep it that way, never
add a `sizing_mode` branch), and **(2)** resilient to a missing/zero on-chain cost basis via a
deterministic fallback chain, and **(3)** never able to fail *silently* again.

**Fix 1 — Effective-entry resolver with a fallback chain (the core fix).**
Introduce a single cost-basis resolver used by the stop, mirroring BP16 but **DB-first** (the risk path
should trust *our own recorded fill*, not an indexer that is provably zero/late):

```text
effective_entry(uid, token, api_avg_price):
    1. DB copy_trades.entry_price        (get_entry_prices_by_token — our true fill cost)   ← preferred
    2. Data-API avg_price                (only if DB is 0/NULL and api_avg_price > 0)
    3. size_usdc / shares                (derive from the ledger row when both are present)
    4. trade_signals.price               (via signal_id — the VWAP entry the signal carried)
    5. None                              → cannot compute Delta-Drop; log LOUD + rely on Fix 3 floor
```

> **Precedence rationale (differs from BP16 on purpose).** BP16 chose *API-if-nonzero, else DB* for a
> *display* because the API blends partial fills. For a **stop-loss** we want the deterministic,
> tamper-proof number we actually paid — our `entry_price` — so the trigger can never be moved by
> indexer noise. Both are near-identical in practice; DB-first is the safer risk default.

Batch it once per user per cycle (one query, same shape as BP16): call
`get_entry_prices_by_token(uid)` at the top of the per-user loop and look up `token_id` inside the
position loop — do **not** query per position.

**Fix 2 — Never skip silently: LOUD logging on missing cost basis.**
The defining property of this incident is that the leak left **no trace**. Add an explicit branch: when
`effective_entry` is `None`, emit `log.warning("stop_no_cost_basis", user_id, token, api_avg=…, cur=…)`
every poll (throttle via `notify_once`/Redis if noisy). A skipped stop must be **observable** so the next
leak is caught in minutes, not weeks. Also drop the `entry_px > 0` gate on `position_mark` so a position
is marked (with `entry=None`/`source=…`) even when the API avg is 0.

**Fix 3 — Cost-basis-independent catastrophic floor (defense-in-depth).**
`hard_stop` is the only sizing- and entry-independent net; keep it, and harden its two leaks:
- It fires on `best_bid < hard_stop_abs_price` **only while `best_bid > 0`**. That guard is *correct*
  (you cannot market-sell into an empty book), but the **hollow-book → rides-to-$0** case must be made
  **visible**: when `best_bid == 0` on an aged position, log `stop_unsellable_hollow_book` so ops can see
  a position that is un-exitable (its loss is already locked; nothing to do but wait for resolution).
- Consider a second absolute floor keyed on the **mid** (`price_ref < hard_stop_abs_price`) so a
  collapsing-but-not-yet-hollow book is caught even if the exact `best_bid` guard is borderline.

**Fix 4 — Keep the BP17 hardening intact.** All four BP17 layers (mid, spread veto, entry-bid,
persistence/debounce) sit *inside* the `if entry_px > 0` block, so today they never even run when
`entry_px=0`. Once Fix 1 supplies a real entry, BP17 resumes protecting against the spread-trap
false-positive. The two blueprints compose: **BP17 stops false stops; BP19 stops missed stops.** Layer 3
(`entry_bid`) already degrades gracefully to `layer3_ok=True` when `entry_bid` is NULL (L240–248) — no
change needed there.

### 19.3 Config knobs (add to `core/config.py`)

| Setting | Proposed default | Meaning |
|---|---|---|
| `stop_use_db_entry` | `True` | resolve cost basis DB-first (Fix 1); `False` = legacy API-only |
| `stop_mid_floor_enabled` | `True` | also fire `hard_stop` when the **mid** < `hard_stop_abs_price` (Fix 3) |
| `stop_no_cost_basis_alert` | `True` | emit `stop_no_cost_basis` warnings when entry is unresolved |

No new *threshold* is introduced — `delta_drop_stop_pct` (0.30) and `hard_stop_abs_price` (0.07) are
unchanged. The fix is about **feeding the existing math a correct, always-present input.**

### 19.4 Files touched

| File | Change |
|---|---|
| `worker/tasks/manage_positions.py` | Replace the L199 `avg_price`-only read with the `effective_entry` resolver (Fix 1); fetch `get_entry_prices_by_token(uid)` once per user; add `stop_no_cost_basis` + `stop_unsellable_hollow_book` logs (Fix 2/3); ungate `position_mark`; optional mid-floor hard_stop (Fix 3) |
| `core/db/queries.py` | `get_open_trade_by_token` (or a small new helper) to also return `size_usdc`, `shares`, and the signal's `price` for fallback tiers 3–4; **or** a dedicated `get_cost_basis(uid, token)` that returns the resolved entry with a `source` label |
| `core/db/__init__.py` | re-export any new helper (import block **and** `__all__` — BP12-A guard) |
| `core/config.py` | add the three knobs in §19.3 |

**No migration required** — `entry_price` (008), `shares`/`size_usdc` (008), `signal_id`→`trade_signals.price`
all already exist. This is a read-path rewire, not a schema change.

### 19.5 Acceptance criteria

1. A position bought at `0.54` whose **DB `entry_price` is 0.54** but whose Data-API `avg_price` is `0`
   **is stopped** at ~`0.38` (−30%, subject to BP17 spread/persistence layers) — the stop no longer
   depends on the on-chain avg being populated.
2. When cost basis is unresolvable from **all** tiers, the monitor emits `stop_no_cost_basis` **every
   evaluation** (throttled) — a skipped stop is never silent again.
3. A hollow-book (`best_bid == 0`) aged position logs `stop_unsellable_hollow_book` (visibility), and
   `hard_stop` still fires the instant a bid ≥ tick reappears below `0.07`.
4. **No code path branches on `sizing_mode`** in `sync_positions`/`close_position`; Kelly and Fixed users
   are byte-for-byte identical through the stop logic (grep proof in acceptance).
5. BP17's spread veto + persistence still suppress the false-positive spread-trap once a real entry is
   supplied (BP19 does not reintroduce BP17's bug).
6. `python -c "from core.db import get_entry_prices_by_token"` (and any new helper) succeeds.

### 19.6 Evidence pass — bash/SQL to prove the diagnosis on prod

> **Runtime is Docker Compose** (`app-worker-1` runs `sync_positions`; `app-api-1` the bots) — **not
> pm2** (confirmed in BP17 §17.11). Use `docker compose logs`. A pm2 fallback is included last in case a
> host still runs the legacy process manager. Structlog events are emitted under Celery's
> `WARNING/MainProcess` wrapper but the inner `[info]` events (`position_mark`, `delta_drop_triggered`,
> `hard_stop_triggered`, …) are intact and greppable.

**Step 0 — resolve the internal `user_id`, the user's `sizing_mode`, and the offending ledger rows.**
This alone proves Finding B if `entry_price` is populated in the DB while the trade shows a big loss with
no stop.

```bash
docker compose exec -T worker python - <<'PY'
from core.db.session import get_supabase
sb = get_supabase()
u = (sb.table("users")
     .select("id,telegram_id,username,sizing_mode,wallet_address,deposit_wallet_address")
     .eq("telegram_id", 891787021).maybe_single().execute().data)
print("USER:", u)
uid = u["id"]
rows = (sb.table("copy_trades")
        .select("id,token_id,entry_price,entry_bid,shares,size_usdc,status,result,"
                "realized_pnl,resolved_at,created_at,signal_id")
        .eq("user_id", uid).order("created_at", desc=True).limit(80).execute().data or [])
print(f"\nsizing_mode={u.get('sizing_mode')}  |  {len(rows)} recent trades for uid={uid}:")
for r in rows:
    print(f"  id={r['id']:>5} tok={str(r['token_id'])[:14]:<14} "
          f"entry={str(r.get('entry_price')):<7} shares={str(r.get('shares')):<7} "
          f"size=${str(r.get('size_usdc')):<6} status={r['status']:<9} "
          f"result={str(r.get('result')):<7} pnl={str(r.get('realized_pnl')):<8} "
          f"resolved={str(r.get('resolved_at'))[:10]}")
PY
```

*Read it:* if the big-loss rows (entry ≈ 0.54 / 0.66 / 0.88) have **`entry_price` populated** in the DB,
the cost basis was never lost — the monitor simply didn't use it. Note the `token_id` (first 14 chars)
of each offender for Steps 1–2. Confirm `sizing_mode` is `fixed` (context only — not causal).

**Step 1 — did the monitor EVER evaluate these tokens? (the smoking gun).**
`position_mark` and every Delta-Drop log are gated on `entry_px > 0`. **Absence** of any monitor line for
a token whose DB `entry_price` is populated = the silent-skip leak (Finding B).

```bash
# Substitute the 14-char token prefixes from Step 0.
for TOK in <tok14_a> <tok14_b> <tok14_c>; do
  echo "===== token $TOK ====="
  docker compose logs --since 720h worker 2>&1 | grep -F "$TOK" \
    | grep -E "position_mark|delta_drop_confirming|delta_drop_triggered|stop_skipped_wide_spread|hard_stop_triggered" \
    || echo "  NO monitor lines for this token — stop path never ran (entry_px was 0)."
done
```

**Step 2 — any stop/close activity at all for this user? (compare against the admin).**
Use the internal `uid` from Step 0 (logs key on `user_id=<uid>`, not the telegram id).

```bash
UID=<uid_from_step0>
docker compose logs --since 720h worker 2>&1 \
  | grep -E "user_id=$UID\b|user_id=$UID'" \
  | grep -E "delta_drop_triggered|hard_stop_triggered|delta_drop_confirming|stop_skipped_wide_spread|close_position" \
  | tail -60
# Contrast with the admin's uid (Kelly, stops working) to show the difference is
# presence/absence of a usable entry, not the sizing mode:
ADMIN_UID=<admin_uid>
docker compose logs --since 720h worker 2>&1 | grep -E "user_id=$ADMIN_UID\b" \
  | grep -E "position_mark|delta_drop_triggered" | tail -30
```

**Step 3 — LIVE proof of the `avg_price==0` vs `entry_price>0` divergence** (run on any *still-open*
position of the user; this is the single most direct confirmation).

```bash
docker compose exec -T worker python - <<'PY'
from core.db.session import get_supabase
from core.db import get_entry_prices_by_token
from core.polymarket import get_positions
sb = get_supabase()
u = (sb.table("users").select("id,deposit_wallet_address")
     .eq("telegram_id", 891787021).maybe_single().execute().data)
uid, dw = u["id"], u["deposit_wallet_address"]
db_entry = get_entry_prices_by_token(uid)
print("DB entry_price by token:", {k[:14]: v for k, v in db_entry.items()})
for p in get_positions(dw):
    if p["shares"] <= 0:
        continue
    tok = p["token_id"]; api = float(p.get("avg_price") or 0)
    print(f"tok={tok[:14]} API_avg={api:<7} cur={p.get('cur_price')} "
          f"DB_entry={db_entry.get(tok)}  ->  stop entry_px={api} "
          f"{'(ZERO => Delta-Drop SKIPPED)' if api == 0 else ''}")
PY
```

*Expected:* one or more rows with `API_avg=0` while `DB_entry` is a real price → the guard at
`manage_positions.py` L234 was False → Delta-Drop skipped. This is Finding B, live.

**Step 4 (optional) — SQL variant via `psql`** (if a Postgres connection string is available; never
commit it):

```bash
export PGURL='postgresql://postgres.<ref>:<PWD>@aws-0-<region>.pooler.supabase.com:5432/postgres'
psql "$PGURL" -c "
  select ct.id, left(ct.token_id,14) as token, ct.entry_price, ct.shares, ct.size_usdc,
         ct.status, ct.result, ct.realized_pnl, ct.resolved_at, ts.price as signal_price
  from copy_trades ct
  join users u on u.id = ct.user_id
  left join trade_signals ts on ts.id = ct.signal_id
  where u.telegram_id = 891787021
  order by ct.created_at desc
  limit 80;
"
```

**pm2 fallback (legacy hosts only):**

```bash
for TOK in <tok14_a> <tok14_b> <tok14_c>; do
  grep -F "$TOK" ~/.pm2/logs/worker-out.log \
    | grep -E "position_mark|delta_drop|hard_stop" || echo "no monitor lines for $TOK";
done
```

**How this confirms Blueprint 19:** Step 0 shows the DB held a valid `entry_price`; Steps 1–2 show the
monitor produced **zero** stop/mark lines for those tokens (silent skip) while the admin's tokens *were*
marked; Step 3 shows *live* that `avg_price=0` while `entry_price>0` for this custodial wallet. Together
they prove the leak is the **Data-API cost-basis source (Finding B)**, independent of `sizing_mode`
(Finding A) — exactly the fix in §19.2.

---

## Blueprint 20 — Redeem-Hang Self-Healing + Win-Notification UX (outcome/title/Net-PnL) ✅ IMPLEMENTED 2026-07-03

> Four prod defects captured 2026-07-03. **20.A is money-critical** (real winnings stuck on-chain,
> unclaimed for up to 7 days); 20.B/C/D are win-notification UX. BP9's money-safety invariant worked
> (no fake credit), but the claim pipeline **stalls and never self-heals** — §5 fail-closed +
> idempotency apply to the fixes.

### 20.0 Symptoms (prod, PolyMind AI)

1. **Claim hang.** "⏳ Выигрыш определён, зачисление задерживается" (`_emit_win_retry_failed`) stays
   forever; winnings are never credited.
2. **Missing outcome.** Notifications show `🎯 Исход: —` (empty on markets like "Any Other Score").
3. **Truncated titles.** Event names cut mid-word in lists/alerts.
4. **No Net PnL.** The win notice shows only the credited amount, not profit (payout − entry cost).

### 20.1 Root-cause analysis — 20.A (the redeem hang) — CONFIRMED on prod

The claim is **not** failing on-chain (no gas/revert/RPC). A 48h grep for
`redeem_failed|did not confirm|Traceback|retry` returned **nothing**. The redeem simply **never
re-runs**, for two compounding reasons:

**A1 — Stale 7-day dedup key, never cleared on failure/skip.** `notify_once` defaults to a **7-day** TTL:

```29:35:core/cache.py
def notify_once(key: str, ttl: int = 7 * 86400) -> bool:
    """Return True only the first time `key` is seen (Redis SETNX with TTL)."""
    try:
        return bool(_client().set(f"once:{key}", "1", nx=True, ex=ttl))
    except Exception:
        # Fail-open: a dead Redis means the worker is degraded anyway.
        return True
```

Both redeem paths set `once:redeem:{uid}:{cond}` at **dispatch time** and gate re-dispatch on it:

```965:966:worker/tasks/manage_positions.py
                if not notify_once(f"redeem:{uid}:{cond}"):
                    continue  # already dispatched
```

```110:110:worker/tasks/manage_positions.py
                    redeem_claimed = _notify_once(f"redeem:{uid}:{condition_id}")
```

The key is set once and **never deleted when the redeem fails, is skipped, or the tokens are still
held**. So after the *first* attempt, `reconcile_settlements` L965 hits `notify_once(...) == False` →
**silent `continue`** (no log, `processed` never increments) for the full 7 days. This is exactly the
observed `checked=67 processed=0` on every cycle with zero redeem/win/loss log lines.

**A2 — Redeem dispatched WITHOUT `trade_id`, so the ledger can never be marked settled.** The
`sync_positions` redeemable branch omits `trade_id`/`entry_cost`:

```120:126:worker/tasks/manage_positions.py
                    if redeem_claimed:
                        redeem_position.delay(
                            uid, token_id, condition_id,
                            bool(p.get("neg_risk", False)), p.get("outcome"),
                            p.get("title"), p.get("event_slug"),
                            p.get("outcome_index"),
                        )
```

But `mark_trade_settled` inside `redeem_position` is guarded by `if trade_id:`:

```761:769:worker/tasks/manage_positions.py
        if trade_id:
            try:
                from core.db import mark_trade_settled
                gross = shares_bal if shares_bal > 0 else credited
                pnl = gross - float(entry_cost or 0)
                mark_trade_settled(trade_id, result="win",
                                   realized_pnl=pnl, redeem_tx=redeem_tx)
            except Exception:
                log.warning("mark_trade_settled_failed", trade_id=trade_id)
```

So when the redeem is dispatched from `sync_positions`, even a **successful** on-chain redeem (tokens
burned) leaves `copy_trades` at `status=confirmed, redeemed_at=null` → the trade stays "outstanding"
forever, the user gets no "зачислено", and PnL is never booked. (Note: `redeem_winnings`
skip returns — `no_token_balance` / `collateral_unmatched`, `core/relayer.py` L245/262/265 — also just
`log.info("redeem_skipped")` and return, clearing nothing.)

**Prod evidence (user 4 / `@sto1ner`, 15 outstanding):**

| Category | Trades | `resolved` | `payout` | on-chain `shares` | `redeem_key_ttl` | Diagnosis |
|---|---|---|---|---|---|---|
| Open (correct) | 809,808,807,806,805,801 | False | 0 | > 0 | `-2` (no key) | genuinely unresolved — waiting |
| **WON, stuck** | **799,791,777** | True | 1 | **7.35 / 5.26 / 5.26** | ~5.4–6.5 d | **winnings held, redeem blocked by stale key (A1)** |
| WON, ledger desync | 796,795,788,785,783,773 | True | 1 | **0.0** | ~6.2 d | tokens already redeemed on-chain, ledger never settled (A2) |

≈ **17.9 shares (~$17.90)** of confirmed winnings for a single user are sitting unclaimed with ~6 days
left on the blocking key; six more are redeemed-but-unbooked.

### 20.2 Design — 20.A: make the redeem pipeline self-healing & idempotent

**Fix A1 — dedup TTL + failure-clear (short, self-expiring lease, not a 7-day lock).**
Treat the redeem key as an **in-flight lease**, not a permanent "done" marker:
- Set it with a **short TTL** (`redeem_lease_sec`, proposed **900s**) at dispatch — long enough to
  prevent double-dispatch within a cycle, short enough to auto-retry soon after a failure.
- **Clear it** (`_client().delete("once:redeem:{uid}:{cond}")`) in `redeem_position`'s failure and skip
  paths (the `except` before `self.retry`, and every `redeem_skipped` return) so the next
  `reconcile_settlements` cycle re-attempts instead of waiting a week. Add a `clear_once(key)` helper to
  `core/cache.py`.
- The **success** terminal state is `copy_trades.redeemed_at IS NOT NULL` (the ledger), **not** the
  Redis key — so `get_outstanding_copy_trades` (which filters `redeemed_at IS NULL`) is the real dedup
  and the Redis lease only prevents intra-window stampedes.

**Fix A2 — always pass `trade_id` + a real `entry_cost`, and make marking mandatory.**
- `sync_positions` redeemable dispatch (L121) must pass `trade_id` and `entry_cost` — look up the open
  `copy_trades` row for `(uid, condition_id)` (reuse the same lookup `reconcile` uses at L975/L1004) so
  the success path can mark it. Never dispatch a redeem that can't be reconciled.
- Compute `entry_cost` via the **Blueprint 19 cost-basis resolver** (DB `entry_price × shares`, with the
  BP19 fallback chain) rather than the zero-prone Data-API — this also feeds 20.D (Net PnL).

**Fix A3 — reconcile the "already redeemed on-chain" case (shares == 0 winners).**
In `reconcile_settlements`, when a trade is `resolved && won` but the on-chain `ctf_token_balance == 0`
(tokens already gone), do **not** dispatch a redeem (there is nothing to claim). Instead
`mark_trade_settled(result="win", realized_pnl = proceeds − entry_cost)` directly, where `proceeds` is
the pre-redeem `shares` (from `copy_trades.shares`, or `size_usdc/entry_price`), and send the win
notification once. This drains the six ledger-desync rows and books their PnL. Clear the stale key.

**Fix A4 — stop skipping silently.** Every early `continue` in the reconcile win branch and every
`redeem_skipped` return must emit a distinct throttled log (`reconcile_redeem_blocked`,
`redeem_skipped_reason`) so a stuck claim is visible within minutes, not discovered by a user complaint.

**One-time prod cleanup (ops runbook, not code):** delete the stale keys so recovery is immediate rather
than waiting ~6 days: `redis-cli --scan --pattern 'once:redeem:*' | xargs redis-cli del` (safe — the
ledger `redeemed_at` is the real dedup; worst case a redeemed trade re-dispatches and
`redeem_winnings` returns `no_token_balance`, now handled by A3/A4). Run **after** deploying A1–A4.

### 20.3 Root cause & design — 20.B: outcome fallback (`Исход: —`)

Outcome comes straight from the Data-API position and is empty for grouped/scalar markets:

```436:436:core/polymarket.py
                "outcome":      p.get("outcome", ""),
```

**Fix — a central `resolve_outcome_name(...)` helper**, applied in every `_emit_*` notifier, with a
fallback chain: (1) API `outcome`; (2) `trade_signals.outcome` via `signal_id` (we persisted it at
entry — `execute_copy` L496); (3) the market's `outcomes[outcome_index]` from Gamma; (4)
`groupItemTitle` for grouped markets ("Any Other Score" etc.); (5) last-resort binary default
`Yes/No` from `outcome_index`. Only fall to `—` when all fail.

### 20.4 Root cause & design — 20.C: full titles + word-boundary truncation

Two issues: notifiers hard-slice `[:50]`/`[:40]`/`[:48]` (mid-word cut), and the positions Data-API
`title` can be partial. **Fix:** (1) source the **full** title from `trade_signals.title` (the complete
question stored at signal time, `execute_copy` L466) or the Gamma `question`, not the positions feed;
(2) add one `smart_truncate(text, limit)` helper (cut on the last word boundary ≤ limit, append `…`)
and replace the scattered `[:N]` slices in `_notify_closed`, `_emit_win`, `_emit_loss`,
`_emit_win_pending`, `_emit_win_retry_failed`, and `redeem_position`'s notify.

### 20.5 Root cause & design — 20.D: Net PnL in the win notification

The win notice shows only the credited amount:

```771:779:worker/tasks/manage_positions.py
        _notify(
            user["telegram_id"],
            f"💸 <b>Выигрыш зачислен</b>\n\n"
            f"📌 {(title or '—')[:50]}\n"
            f"🎯 Исход: <b>{outcome or '—'}</b>\n"
            f"➕ Зачислено: <b>+${credited:.2f} pUSD</b>\n"
            f"💼 Торговый баланс: <b>${bal_after:.2f} pUSD</b>"
            f"{_event_link(event_slug)}",
        )
```

`entry_cost` is already a parameter but is (a) not passed by `sync_positions` (20.A2) and (b) never
displayed. **Fix:** resolve `entry_cost` via the **Blueprint 19** cost-basis resolver (never the API
avg), compute `net_pnl = gross − entry_cost` (gross = `shares_bal` × $1.00), and add a line:

```text
💸 Выигрыш зачислен
📌 <full event title, word-safe>
🎯 Исход: <resolved outcome>
➕ Выплата: +$12.35
🏆 Net PnL: +$4.60  (выплата $12.35 − вход $7.75)
💼 Торговый баланс: $42.18 pUSD
```

Guard the unknown-cost-basis case (legacy rows, BP16/BP19): if `entry_cost` is unresolved, render
`Net PnL: —` — never a wrong/negative-looking number.

### 20.6 Files touched

| File | Change |
|---|---|
| `core/cache.py` | **+** `clear_once(key)` helper (DELETE `once:{key}`); document the lease vs. terminal-state distinction |
| `worker/tasks/manage_positions.py` | A1: short `redeem_lease_sec` TTL on the redeem key + clear on failure/skip; A2: `sync_positions` passes `trade_id`+`entry_cost` (BP19 resolver); A3: reconcile `shares==0 && won` → `mark_trade_settled` directly (no dispatch); A4: loud `reconcile_redeem_blocked`/`redeem_skipped_reason` logs; 20.B/C/D in the `_emit_*` + `redeem_position` notify |
| `core/polymarket.py` | **+** `resolve_outcome_name(...)` (20.B) and a Gamma title/outcomes fetch by condition/slug; **+** `smart_truncate(text, limit)` (20.C) |
| `core/db/queries.py` | reuse BP19 cost-basis resolver for `entry_cost`; helper to fetch open `(uid, cond)` row (`trade_id`, `shares`, `entry_price`, `signal.title/outcome`) for 20.A2/20.B/20.D; export (BP12-A guard) |
| `core/config.py` | **+** `redeem_lease_sec = 900` |

**No new migration.** Every column used (`entry_price`, `shares`, `size_usdc`, `signal_id`, `result`,
`realized_pnl`, `redeemed_at`) already exists (migration 008); `trade_signals.title/outcome` exist.

### 20.7 Acceptance criteria

1. A resolved win with tokens still held (e.g. trade 799, 7.35 shares) is **redeemed within one
   reconcile cycle** even after a prior failed attempt — the redeem key is a ≤15-min lease, cleared on
   failure, and re-armed automatically.
2. A resolved win already redeemed on-chain (`shares==0`, e.g. trade 796) is **marked settled**
   (`result='win'`, `realized_pnl` booked, `redeemed_at` set) by reconcile **without** dispatching a
   redeem, leaves the outstanding set, and notifies the user once.
3. No redeem is ever dispatched without a `trade_id`; on success `mark_trade_settled` always runs.
4. A stuck/blocked claim emits a throttled `reconcile_redeem_blocked` / `redeem_skipped_reason` log —
   never a silent `continue`.
5. Win/loss/pending notifications show a **resolved outcome** (never `—` when the signal or Gamma has
   it) and a **full, word-boundary-truncated** title (no mid-word cut).
6. The "Выигрыш зачислен" message shows **Net PnL = payout − entry cost** (BP19 cost basis), or `—`
   when the cost basis is genuinely unknown.
7. After the one-time key purge + deploy, `reconcile_settlements` `processed` > 0 while winners drain,
   and the outstanding count falls to only genuinely-unresolved trades.

### 20.8 Evidence pass (already executed — 2026-07-03) ✅ CONFIRMED

- 48h grep: **no** `redeem_failed`/`did not confirm`/`Traceback`/`retry` → not an on-chain failure.
- `redis-cli --scan 'once:redeem:*'`: dozens of keys with **~5–6.9 day** TTLs (7-day default), incl.
  keys for resolved winners still holding tokens.
- Live probe (user 4): 3 resolved winners with `shares>0` blocked by live redeem keys (money stuck) and
  6 resolved winners with `shares==0` still `confirmed/unredeemed` (ledger desync). Directly validates
  §20.1 A1 (stale key) + A2 (dispatch-without-`trade_id`) → fixes §20.2 A1–A4.
